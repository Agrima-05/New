SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
-- Create date: 20180928
-- =============================================
CREATE PROCEDURE [dbo].[usp_name_parser_unifiedV5] @tableName varchar(255)

AS
BEGIN

SET CONCAT_NULL_YIELDS_NULL OFF

declare @sql varchar(max) = ''

--  Step Added to take out AKA, NKA, FKA

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1] = case when [Name1] like ''AKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''AKA'',[Name1]))))) 
	   when [Name1] like ''% AKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''AKA'',[Name1]) -1)))) 
	   when [Name1] like ''FKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''FKA'',[Name1]) -1)))) 
	   when [Name1] like ''% FKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''FKA'',[Name1]) -1)))) 
	   when [Name1] like ''NKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''NKA'',[Name1]) -1)))) 
	   when [Name1] like ''% NKA %'' then  Rtrim(ltrim(substring([Name1],1,(charindex(''NKA'',[Name1]) -1))))
	   else [Name1] end
	   ,[KnownAs] = case when [Name1] like ''AKA %'' then Rtrim(ltrim(substring([Name1],(charindex(''AKA'',[Name1]) +4),40))) 
	   when [Name1] like ''% AKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''AKA'',[Name1]) +4),40))) 
	   when [Name1] like ''FKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''FKA'',[Name1]) +4),40))) 
	   when [Name1] like ''% FKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''FKA'',[Name1]) +4),40))) 
	   when [Name1] like ''NKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''NKA'',[Name1]) +4),40))) 
	   when [Name1] like ''% NKA %'' then  Rtrim(ltrim(substring([Name1],(charindex(''NKA'',[Name1]) +4),40)))
	   else null end
   from [dbo].['+@tableName+']'

   exec(@sql)
     
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2] = case when [Name2] like ''AKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''AKA'',[Name1]))))) 
	   when [Name2] like ''% AKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''AKA'',[Name2]) -1)))) 
	   when [Name2] like ''FKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''FKA'',[Name2]) -1)))) 
	   when [Name2] like ''% FKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''FKA'',[Name2]) -1)))) 
	   when [Name2] like ''NKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''NKA'',[Name2]) -1)))) 
	   when [Name2] like ''% NKA %'' then  Rtrim(ltrim(substring([Name2],1,(charindex(''NKA'',[Name2]) -1))))
	   else [Name2] end
      ,[KnownAs] = case when [Name2] like ''AKA %'' then Rtrim(ltrim(substring([Name2],(charindex(''AKA'',[Name2]) +4),40))) 
	   when [Name2] like ''% AKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''AKA'',[Name2]) +4),40))) 
	   when [Name2] like ''FKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''FKA'',[Name2]) +4),40))) 
	   when [Name2] like ''% FKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''FKA'',[Name2]) +4),40))) 
	   when [Name2] like ''NKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''NKA'',[Name2]) +4),40))) 
	   when [Name2] like ''% NKA %'' then  Rtrim(ltrim(substring([Name2],(charindex(''NKA'',[Name2]) +4),40)))
	   else null end
   from [dbo].['+@tableName+']'

   exec(@sql)

-------- Parse Care of Name  --  addedd BR 20170830  --   Moved up in processing 20180511
   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring([name1],1,(charindex(''c/o'',[name1])-1))))
   ,COName = ltrim(rtrim(substring([name1],(charindex(''c/o'',[name1])+3),80)))
   from [dbo].['+@tableName+']
   where Name1 like ''%c/o%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim(substring([name1],1,(charindex(''c\o'',[name1])-1))))
   ,COName = ltrim(rtrim(substring([name1],(charindex(''c\o'',[name1])+3),80)))
   from [dbo].['+@tableName+']
   where Name1 like ''%c\o%'''
   exec(@sql)

--  Name 2 added 20180511
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],1,(charindex(''c/o'',[name2])-1))))
   ,COName = ltrim(rtrim(substring([name2],(charindex(''c/o'',[name2])+3),80)))
   from [dbo].['+@tableName+']
   where Name2 like ''%c/o%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],1,(charindex(''c\o'',[name2])-1))))
   ,COName = ltrim(rtrim(substring([name2],(charindex(''c\o'',[name2])+3),80)))
   from [dbo].['+@tableName+']
   where Name2 like ''%c\o%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = null
   ,COName = ltrim(rtrim(substring([name2],(charindex(''REM:'',[name2])+4),80)))
   from [dbo].['+@tableName+']
   where Name2 like ''REM:%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = null
   ,COName = ltrim(rtrim(substring([name2],(charindex(''MT:'',[name2])+3),80)))
   from [dbo].['+@tableName+']
   where Name2 like ''MT:%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = null
   ,COName = ltrim(rtrim(substring([name2],(charindex(''M/TO:'',[name2])+5),80)))
   from [dbo].['+@tableName+']
   where Name2 like ''M/TO:%'''
   exec(@sql)

--  Clean Up
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],(charindex('':'',[name2])+1),80)))
   from [dbo].['+@tableName+']
   where Name2 like '':%'''

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim(substring([name2],1,(charindex(''&'',[name2])-2),80)))
   from [dbo].['+@tableName+']
   where Name2 like ''% &'''

-- Step 0 Added a preprocessing step to accomodate Vesting, relationship, and percentage ownership

-- [ParsedTokenName1]
   set @sql = 'update [dbo].['+@tableName+']
   set [ParsedTokenName1] = substring(substring(name1, (CHARINDEX(''('',name1)) + 1,  (CHARINDEX('')'',name1)) - (CHARINDEX(''('',name1)) -1  ),1,40)
   ,Name1 = substring(Replace(name1,substring(Name1, (CHARINDEX(''('',Name1)),  (CHARINDEX('')'',Name1)) - (CHARINDEX(''('',Name1))+1),''''),1,100)
   from [dbo].['+@tableName+']
   where name1 like ''%(%)%'' and name1 not like ''%)%(%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRelationship] = [Relationship]
   ,[OwnerRights] = [Vesting]
   ,[OwnerEtalInd] = [ETAL Ind]
   ,[Name1Percent] = [Percentage]
   from [dbo].['+@tableName+'] t
   Join [dbo].[lkup_ParsedToken] p
   on p.[token] = t.[ParsedTokenName1]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRelationship] = [Relationship]
   from [dbo].['+@tableName+'] t
   Join [dbo].[lkup_VestingSourceCrossRef] p
   on p.[SourceCodeBK] = t.[NameIDCode]
   where [OwnerRelationship] is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRights] = [Ownership]
   from [dbo].['+@tableName+'] t
   Join [dbo].[lkup_VestingSourceCrossRef] p
   on p.[SourceCodeBK] = t.[NameIDCode]
   where [OwnerRights] is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerEtalInd] = [EtalInd]
   from [dbo].['+@tableName+'] t
   Join [dbo].[lkup_VestingSourceCrossRef] p
   on p.[SourceCodeBK] = t.[NameIDCode]
   where [OwnerEtalInd] is null'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [NameIDCode] = COALESCE([OwnerRights],[OwnerRelationship])
   from [dbo].['+@tableName+'] t
   where [NameIDCode] is null and ([OwnerRights] is not null or[OwnerRelationship] is not null)'
   exec(@sql)

-- [ParsedTokenName2]
   set @sql = 'update [dbo].['+@tableName+']
   set [ParsedTokenName2] = substring(substring(name1, (CHARINDEX(''('',name2)) + 1,  (CHARINDEX('')'',name2)) - (CHARINDEX(''('',name2)) -1  ),1,40)
   ,Name2 = substring(Replace(name2,substring(Name2, (CHARINDEX(''('',Name2)),  (CHARINDEX('')'',Name2)) - (CHARINDEX(''('',Name2))+1),''''),1,100)
   from [dbo].['+@tableName+']
   where name2 like ''%(%)%'' and name2 not like ''%)%(%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [OwnerRelationship] = [Relationship]
   ,[OwnerRights] = [Vesting]
   ,[OwnerEtalInd] = [ETAL Ind]
   ,[Name2Percent] = [Percentage]
   from [dbo].['+@tableName+'] t
   Join [dbo].[lkup_ParsedToken] p
   on p.[token] = t.[ParsedTokenName2]'
   exec(@sql)

--Step 1 Corp Processing Name1



--------  Step 0 Per work clean Name1 and Name2  --  Added 20171110

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = ltrim(rtrim([Name1]))
   ,Name2 = ltrim(rtrim([Name2]))
   ,COName = ltrim(rtrim([COName]))
   from [dbo].['+@tableName+']'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = Replace(Replace(ltrim(rtrim([Name1])),'';'','' & ''),''  '','' '')
   from [dbo].['+@tableName+']
   Where Name1 like ''%;%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = Replace(Replace(ltrim(rtrim([Name2])),'';'','' & ''),''  '','' '')
   from [dbo].['+@tableName+']
   Where Name2 like ''%;%'''
   exec(@sql)


--Step 1 Corp Processing Name1
-----------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+']
 	where [Name1] Like ''%See ACCT%'' or [Name1] Like ''%See-ACCT%'''
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   ,[Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+']
 	where [NameIDCode] in (''TR'',''TS'',''RT'',''RL'',''LV'',''LE'',''LT'',''IR'',''IL'',''FL'',''FM'',''FR'',''ES'')'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+']
 	join [dbo].[lkup_Corp_Name] c
	on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name1],1,(charindex('' '',[name1])))
	where [BeginsWith] is not null
	and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Corp_Name] c
	on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name1]),1,(charindex('' '',reverse([name1])))))
	where [EndsWith] is not null
	and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+']
      join [dbo].[lkup_Corp_Name] c
      on [name1] like ''% '' + ltrim(rtrim([EndsWith]))
      where [EndsWith] is not null
      and Name1CorpInd is NULL'
   exec(@sql)


   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Corp_Name] c
	on ltrim(rtrim([Only])) = ltrim(rtrim([Name1]))
	where [Only] is not null
	and Name1CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1CorpInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Corp_Name] c
	on ltrim(rtrim([Name1])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
	where [ContainsIn] is not null and [ContainsIn] not like ''''
	and Name1CorpInd is NULL'
   exec(@sql)

-----------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+']
 	join [dbo].[lkup_Corp_Name] c
	on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name2],1,(charindex('' '',[name2])))
	where [BeginsWith] is not null and ([Name2] is not null and [Name2] not like '''')
	and Name2CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Corp_Name] c
	on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name2]),1,(charindex('' '',reverse([name2])))))
	where [EndsWith] is not null and ([Name2] is not null and [Name2] not like '''')
	 and Name2CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+']
      join [dbo].[lkup_Corp_Name] c
      on [name2] like ''% '' + ltrim(rtrim([EndsWith]))
      where [EndsWith] is not null
      and Name2CorpInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Corp_Name] c
	on ltrim(rtrim([Only])) = ltrim(rtrim([Name2]))
	where [Only] is not null and ([Name2] is not null and [Name2] not like '''')
	 and Name2CorpInd is NULL'
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name2CorpInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Corp_Name] c
	on ltrim(rtrim([Name2])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
	where [ContainsIn] is not null and [ContainsIn] not like ''''
	 and ([Name2] is not null and [Name2] not like '''') and Name2CorpInd is NULL'
   exec(@sql)
-------------------------------------------------------------------------
--Step 2 Trust Processing Name1   --  BR Added 20170927
-----------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+']
 	join [dbo].[lkup_Trust_Name] c
	on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name1],1,(charindex('' '',[name1])))
	where [BeginsWith] is not null
	and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Trust_Name] c
	on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name1]),1,(charindex('' '',reverse([name1])))))
	where [EndsWith] is not null
	and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1TrustInd = ''Y''
   from [dbo].['+@tableName+']
      join [dbo].[lkup_Trust_Name] c
      on [name1] like ''% '' + ltrim(rtrim([EndsWith]))
      where [EndsWith] is not null
      and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Trust_Name] c
	on ltrim(rtrim([Only])) = ltrim(rtrim([Name1]))
	where [Only] is not null
	and Name1TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set [Name1TrustInd] = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Trust_Name] c
	on ltrim(rtrim([Name1])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
	where [ContainsIn] is not null and [ContainsIn] not like ''''
	and Name1TrustInd is NULL'
   exec(@sql)

-----------------------------------------------------------
   set @sql = 'update [dbo].['+@tableName+']
   set [Name2TrustInd] = ''Y''
   from [dbo].['+@tableName+']
 	join [dbo].[lkup_Trust_Name] c
	on ltrim(rtrim([BeginsWith])) + '' '' = substring([Name2],1,(charindex('' '',[name2])))
	where [BeginsWith] is not null and ([Name2] is not null and [Name2] not like '''')
	and Name2TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Trust_Name] c
	on '' '' + ltrim(rtrim([EndsWith])) = reverse(substring(reverse([Name2]),1,(charindex('' '',reverse([name2])))))
	where [EndsWith] is not null and ([Name2] is not null and [Name2] not like '''')
	 and Name2TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+']
      join [dbo].[lkup_Trust_Name] c
      on [name2] like ''% '' + ltrim(rtrim([EndsWith]))
      where [EndsWith] is not null
      and Name2TrustInd is NULL'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Trust_Name] c
	on ltrim(rtrim([Only])) = ltrim(rtrim([Name2]))
	where [Only] is not null and ([Name2] is not null and [Name2] not like '''')
	 and Name2TrustInd is NULL'
   exec(@sql)
   
   set @sql = 'update [dbo].['+@tableName+']
   set Name2TrustInd = ''Y''
   from [dbo].['+@tableName+']
	join [dbo].[lkup_Trust_Name] c
	on ltrim(rtrim([Name2])) LIKE ''% '' + ltrim(rtrim([ContainsIn])) + '' %'' 
	where [ContainsIn] is not null and [ContainsIn] not like ''''
	 and ([Name2] is not null and [Name2] not like '''') and Name2TrustInd is NULL'
   exec(@sql)
-------------------------------------------------------------------------
---------- Parse Care of Name  --  addedd BR 20170830  --   Moved up in processing 20180511
--   set @sql = 'update [dbo].['+@tableName+']
--   set Name1 = ltrim(rtrim(substring([name1],1,(charindex(''c/o'',[name1])-1))))
--   ,COName = ltrim(rtrim(substring([name1],(charindex(''c/o'',[name1])+3),80)))
--   from [dbo].['+@tableName+']
--   where Name1 like ''%c/o%'''
--   exec(@sql)

--   set @sql = 'update [dbo].['+@tableName+']
--   set Name1 = ltrim(rtrim(substring([name1],1,(charindex(''c\o'',[name1])-1))))
--   ,COName = ltrim(rtrim(substring([name1],(charindex(''c\o'',[name1])+3),80)))
--   from [dbo].['+@tableName+']
--   where Name1 like ''%c\o%'''
--   exec(@sql)
----  Name 2 added 20180511
--   set @sql = 'update [dbo].['+@tableName+']
--   set Name2 = ltrim(rtrim(substring([name2],1,(charindex(''c/o'',[name2])-1))))
--   ,COName = ltrim(rtrim(substring([name2],(charindex(''c/o'',[name2])+3),80)))
--   from [dbo].['+@tableName+']
--   where Name1 like ''%c/o%'''
--   exec(@sql)

--   set @sql = 'update [dbo].['+@tableName+']
--   set Name1 = ltrim(rtrim(substring([name2],1,(charindex(''c\o'',[name2])-1))))
--   ,COName = ltrim(rtrim(substring([name2],(charindex(''c\o'',[name2])+3),80)))
--   from [dbo].['+@tableName+']
--   where Name1 like ''%c\o%'''
--   exec(@sql)

--   set @sql = 'update [dbo].['+@tableName+']
--   set Name1 = ltrim(rtrim(substring([name2],1,(charindex(''REM:'',[name2])))))
--   ,COName = ltrim(rtrim(substring([name2],(charindex(''REM:'',[name2])+4),80)))
--   from [dbo].['+@tableName+']
--   where Name1 like ''REM:%'''
--   exec(@sql)

--   set @sql = 'update [dbo].['+@tableName+']
--   set Name1 = ltrim(rtrim(substring([name2],1,(charindex(''MT:'',[name2])))))
--   ,COName = ltrim(rtrim(substring([name2],(charindex(''MT:'',[name2])+3),80)))
--   from [dbo].['+@tableName+']
--   where Name1 like ''MT:%'''
--   exec(@sql)
-------------------------------------------------------------
-----Bill 20161024  --  BR took out 20170831
----- Clean Garbage
   --set @sql = 'update [dbo].['+@tableName+']
   --set NameFormatType = ''2''
   --from [dbo].['+@tableName+']
   --where NameFormatType is null'
   --exec(@sql)

----ADDED 20170928 Same Last Name Twice FIX

		EXEC('update [dbo].['+@tableName+']
			SET [Name1] = CASE WHEN dbo.Before1stCharacter([Name1],'' '') + Replace(dbo.After1stCharacter([Name1],'' ''), dbo.Before1stCharacter([Name1],'' ''), ''&'') like ''%&%&%''
			THEN [dbo].[Before2ndCharacter](dbo.Before1stCharacter([Name1],'' '') + Replace(dbo.After1stCharacter([Name1],'' ''), dbo.Before1stCharacter([Name1],'' ''), ''&''),''&'')
			ELSE dbo.Before1stCharacter([Name1],'' '') + Replace(dbo.After1stCharacter([Name1],'' ''), dbo.Before1stCharacter([Name1],'' ''), ''&'')
			END
		WHERE [Name1] Like ''% %'' and [Name1CorpInd] is null and Name1fmt like ''%,%'' 
                AND SUBSTRING([Name1],CharIndex('' '',[Name1])+1,LEN([Name1])) Like ''% '' + ltrim(rtrim(replace(Substring([Name1],1,CharIndex('' '',[Name1])),'','',''''))) + ''%''
		')



-- Added 20160827
   set @sql = 'update [dbo].['+@tableName+']
   set NameFormatType = ''2''
   from [dbo].['+@tableName+']
   where  Name2CorpInd is null and Name1 like ''%,%'' and NameFormatType = ''1'''
	exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = replace(Name1,''3rd'',''III'')
   ,Name1Generation = ''III''
   from [dbo].['+@tableName+']
   where  Name1CorpInd is null and (Name1 like ''% 3rd''  or (Name1 like ''% 3rd &'') or (Name1 like ''% 3rd %''))'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name1 = substring(ltrim(rtrim([Name1] + '' '' + [Name2])),1,100)
   from [dbo].['+@tableName+']
   where  Name2CorpInd is null and Name1 like ''% &'''
   exec(@sql)

--------------------------------

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''%single'', '''' )
  ,OwnerRelationship = ''SI''
  Where [Name1] like ''%single'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''% Married'', '''' )
  ,OwnerRelationship = ''MA''
  Where [Name1] like ''%Married'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''etal'', '''' )
  ,OwnerETALInd = ''EA''
  where Name1 like ''etal% %'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''etal'', '''' )
  ,OwnerETALInd = ''EA''
  where Name1 like ''% etal%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''etux'', '''' )
  ,OwnerETALInd = ''EU''
  where Name1 like ''etux% %'''
  exec(@sql)

----  Added 20160827 BR  --------
  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''etux'', '''' )
  ,OwnerETALInd = ''EU''
  where Name1 like ''% etux'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''et ux'', '''' )
  ,OwnerETALInd = ''EU''
  where Name1 like ''% et ux'''
  exec(@sql)

  ------   Added BR 20171116

    set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''ETAL'', '''' )
  ,OwnerETALInd = ''EA''
  where Name1 like ''% ETAL'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''et al'', '''' )
  ,OwnerETALInd = ''EA''
  where Name1 like ''% et al'''
  exec(@sql)

------------
  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''25%'', '''' )
  ,[Name1Percent] = ''25%''
  where Name1 like ''%25%'''
  exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''50%'', '''' )
  ,[Name1Percent] = ''50%''
   where Name1 like ''%50%'''
  exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''75%'', '''' )
  ,[Name1Percent] = ''75%''
  where Name1 like ''%75%'''
  exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''100%'', '''' )
  ,[Name1Percent] = ''100%''
  where Name1 like ''%100%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''1/4'', '''' )
  ,[Name1Percent] = ''1/4''
  where Name1 like ''%1/4%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''1/2'', '''' )
  ,[Name1Percent] = ''1/2''
  where Name1 like ''%1/2%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''1/3'', '''' )
  ,[Name1Percent] = ''1/3''
  where Name1 like ''%1/3%'''
  exec(@sql)

  ----  BR Added to clean garbage
  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace(Replace([Name1],''()'',''''),''  '','' ''),''(H)'',''''),''(W)'',''''),''(SOL)'',''''),''(SO)'',''''),''(JT)'',''''),''(TRE)'',''''),''(CPR)'',''''),''(JNT)'',''''),''(CP)'',''''),''(TRE'',''''),''(TIC)'',''''),''(COM)'',''''),''(NOT)'',''''),''(OT-JT)'',''''),''(OT)'',''''),''( TIC)'',''''),''(55%)'',''''),''(45%'',''''),''  '','''')
  where Name1 like ''%(%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''[0-9]/[0-9]'', '''' )
  where Name1 like ''%[0-9]/[0-9]%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''[0-9]/[0-9][0-9]'', '''' )
  where Name1 like ''%[0-9]/[0-9][0-9]%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = ltrim(rtrim(substring(name1,(charindex('')'',name1)+1),50)))
  where name1 like ''(%)%'''
  exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = ltrim(rtrim(substring(Name1,2,50)))
  where name1 like ''(%'''
  exec(@sql)

----  Added toClean Name2 20160827 BBR

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = replace(Name2,''3rd'',''III'')
   from [dbo].['+@tableName+']
   where  Name2CorpInd is null and (Name2 like ''% 3rd''  or (Name2 like ''% 3rd &'') or (Name2 like ''% 3rd &%''))'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim([Name1] + '' '' + [Name2]))
   from [dbo].['+@tableName+']
   where  Name2CorpInd is null and Name1 like ''% &'' and Name2 is not null'
   exec(@sql)

/*  -- Change to above 20170714 by BBR and GM
   set @sql = 'update [dbo].['+@tableName+']
   set Name2 = ltrim(rtrim([Name2] + '' '' + [Name2]))
   from [dbo].['+@tableName+']
   where  Name2CorpInd is null and Name2 like ''% &'''
   exec(@sql)
*/
--------------------------------

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''%single'', '''' )
  ,[OwnerRelationship] = ''SI''
  where Name2 like ''%single %'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''% Married'', '''' )
  ,[OwnerRelationship] = ''MA''
  where Name2 like ''%Married %'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''etal'', '''' )
  ,OwnerETALInd = ''EA''
  where Name2 like ''etal% %'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''etux'', '''' )
  ,OwnerETALInd = ''EU''
  where Name2 like ''etux% %'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''T/E'', '''' )
  ,[OwnerRights] = ''TE''
  where Name2 like ''T/E% %'' or Name2 like ''%T/E'''
   exec(@sql)

----  Added 20160827 BR  --------
  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''etux'', '''' )
  ,OwnerETALInd = ''EU''
  where Name2 like ''% etux'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''1/4'', '''' )
  ,[Name2Percent] = ''1/4''
  where Name2 like ''%1/4%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''1/2'', '''' )
  ,[Name2Percent] = ''1/2''
  where Name2 like ''%1/2%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''1/3'', '''' )
  ,[Name2Percent] = ''1/3''
  where Name2 like ''%1/3%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''[0-9]/[0-9]'', '''' )
  where Name2 like ''%[0-9]/[0-9]%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''[0-9]/[0-9][0-9]'', '''' )
  where Name2 like ''%[0-9]/[0-9][0-9]%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = ltrim(rtrim(substring(Name2,(charindex('')'',Name2)+1),50)))
  where Name2 like ''(%)%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = ltrim(rtrim(substring(Name2,2,50)))
  where Name2 like ''(%'''
   exec(@sql)

----------------------------------------------------
------- Parsing Name1 by Space delimiter into 12 separage fields
SET CONCAT_NULL_YIELDS_NULL ON

		EXEC('DECLARE @delimiter VARCHAR(50)
			SET @delimiter = '' ''

			SELECT CONVERT(bigint, ID) as ID,Name1
					,CAST(''<M>'' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE([Name1],''_'',''''),''>'','' ''),''<'','' ''),''&'','' AND ''),''+'','' AND ''),''.'',''''),''/'',''''),''['',''''),'']'',''''),''  '','' ''),Char(34),''''),Char(9),''''),Char(10),''''),Char(13),''''),Char(39),''''),Char(64),''''), @delimiter , ''</M><M>'') + ''</M>'' AS XML) AS [Name XML]
					--,CAST(''<M>'' + REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Name1,''>'','' ''),''<'','' ''),''&'','' AND ''),''+'','' AND ''),''.'',''''),''/'',''''),''  '','' ''), @delimiter , ''</M><M>'') + ''</M>'' AS XML) AS [Name XML]
				INTO #NameSplit
				FROM  dbo.['+@tableName+']
				WHERE Name1CorpInd is null and Name1 like ''% %''
				order by ID

			UPDATE d 
			SET d.N1 = replace(replace(x.N1,'','',''''),''.'','''')
			,d.N2 = replace(replace(x.N2,'','',''''),''.'','''')
			,d.N3 = replace(replace(x.N3,'','',''''),''.'','''')
			,d.N4 = replace(replace(x.N4,'','',''''),''.'','''')
			,d.N5 = replace(replace(x.N5,'','',''''),''.'','''')
			,d.N6 = replace(replace(x.N6,'','',''''),''.'','''')
			,d.N7 = replace(replace(x.N7,'','',''''),''.'','''')
			,d.N8 = replace(replace(x.N8,'','',''''),''.'','''')
			,d.N9 = replace(replace(x.N9,'','',''''),''.'','''')
			,d.N10 = replace(replace(x.N10,'','',''''),''.'','''')
			,d.N11 = replace(replace(x.N11,'','',''''),''.'','''')
			,d.N12 = replace(replace(x.N12,'','',''''),''.'','''')
			FROM [dbo].['+@tableName+'] d JOIN 
			(
				SELECT ID,Name1
					 ,[Name XML].value(''/M[1]'', ''varchar(50)'') as N1
					 ,[Name XML].value(''/M[2]'', ''varchar(50)'') as N2
					 ,[Name XML].value(''/M[3]'', ''varchar(50)'') as N3
					 ,[Name XML].value(''/M[4]'', ''varchar(50)'') as N4
					 ,[Name XML].value(''/M[5]'', ''varchar(50)'') as N5
					 ,[Name XML].value(''/M[6]'', ''varchar(50)'') as N6
					 ,[Name XML].value(''/M[7]'', ''varchar(50)'') as N7
					 ,[Name XML].value(''/M[8]'', ''varchar(50)'') as N8
					 ,[Name XML].value(''/M[9]'', ''varchar(50)'') as N9
					 ,[Name XML].value(''/M[10]'', ''varchar(50)'') as N10
					 ,[Name XML].value(''/M[11]'', ''varchar(50)'') as N11
					 ,[Name XML].value(''/M[12]'', ''varchar(50)'') as N12
				FROM #NameSplit
			) x 
			on d.ID = x.ID
			
			DROP TABLE #NameSplit
			')

SET CONCAT_NULL_YIELDS_NULL OFF

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N1] = ltrim(rtrim(substring([N1],1,(charindex(''-'',[N1]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N1] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N1_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N1]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N2] = ltrim(rtrim(substring([N2],1,(charindex(''-'',[N2]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N2] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N2_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N2]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N3] = ltrim(rtrim(substring([N3],1,(charindex(''-'',[N3]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N3] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N3_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N3]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N4] = ltrim(rtrim(substring([N4],1,(charindex(''-'',[N4]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N4] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N4_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N4]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N5] = ltrim(rtrim(substring([N5],1,(charindex(''-'',[N5]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N5] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N5_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N5]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N6] = ltrim(rtrim(substring([N6],1,(charindex(''-'',[N6]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N6] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N6_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N6]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N7] = ltrim(rtrim(substring([N7],1,(charindex(''-'',[N7]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N7] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N7_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N7]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N8] = ltrim(rtrim(substring([N8],1,(charindex(''-'',[N8]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N8] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N8_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N8]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N9] = ltrim(rtrim(substring([N9],1,(charindex(''-'',[N9]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N9] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N9_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N9]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N10] = ltrim(rtrim(substring([N10],1,(charindex(''-'',[N10]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N10] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N10_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N10]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N11] = ltrim(rtrim(substring([N11],1,(charindex(''-'',[N11]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N11] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N11_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N11]'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [N12] = ltrim(rtrim(substring([N12],1,(charindex(''-'',[N12]) -1))))
      from [dbo].['+@tableName+'] n
	  where [N12] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [N12_Prob] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[N12]'
   exec(@sql)



	----- Added to split Smith Mike A Paula L to Smith Mike A in Name1 and Smith Paula L in Name 2

		--set @sql = 'UPDATE d 
		--SET d.Name1 = N1 + '' '' + N2 + '' '' + N3
		--,d.Name2 = N1 + '' '' + N4 + '' '' + N5
		--FROM [dbo].['+@tableName+'] d
		--WHERE Name1CorpInd is null and Name1 Like ''% % [a-z] % [a-z]'' and Name1 Not like ''% [a-z] [a-z] [a-z]'''
		--exec(@sql)


   ----------  Added to Calculate Name Formats ---  Bill 20170821
-----  Name 1
   set @sql = 'update [dbo].['+@tableName+']
   set Name1TokenFirst = ltrim(rtrim(replace(substring([Name1],1,(charindex('' '',[Name1]))),'','','''')))
   ,Name1TokenLast = ltrim(rtrim(reverse(substring(reverse([Name1]), 0, charindex('' '',reverse([Name1]))))))
   from [dbo].['+@tableName+']
   where Name1 is not null and Name1CorpInd is null'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [Name1TokenFirst] = ltrim(rtrim(substring([Name1TokenFirst],1,(charindex(''-'',[Name1TokenFirst]) -1))))
      from [dbo].['+@tableName+'] n
	  where [Name1TokenFirst] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [Name1TokenLast] = ltrim(rtrim(substring([Name1TokenLast],1,(charindex(''-'',[Name1TokenLast]) -1))))
      from [dbo].['+@tableName+'] n
	  where [Name1TokenLast] like ''%-%'''
   exec(@sql)
------
   set @sql = 'update [dbo].['+@tableName+']
      SET [Name1Token1SurnameInd] = ''Y''
	  ,Name1Token1SurnameProbabilty = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[Name1TokenFirst]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
      SET [Name1Token2SurnameInd] = ''Y''
	  ,Name1Token2SurnameProbabilty = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[Name1TokenLast]'
   exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
      SET [NameFormatType] = case
        when isnull([Name1Token1SurnameProbabilty],0) > isnull([Name1Token2SurnameProbabilty],0) then 2
        when isnull([Name1Token1SurnameProbabilty],0) < isnull([Name1Token2SurnameProbabilty],0) then 1
        else 2 end
      from [dbo].['+@tableName+']'
   exec(@sql)

--------  Name 2
   set @sql = 'update [dbo].['+@tableName+']
   set Name2TokenFirst = ltrim(rtrim(replace(substring([Name2],1,(charindex('' '',[Name2]))),'','','''')))
   ,Name2TokenLast = ltrim(rtrim(reverse(substring(reverse([Name2]), 0, charindex('' '',reverse([Name2]))))))
   from [dbo].['+@tableName+']
   where Name2 is not null and Name2CorpInd is null'
   exec(@sql)

-----  Added to Clean Hyphenated Last Name  --  20180509  BR
  set @sql = 'update [dbo].['+@tableName+']
      SET [Name2TokenFirst] = ltrim(rtrim(substring([Name2TokenFirst],1,(charindex(''-'',[Name2TokenFirst]) -1))))
      from [dbo].['+@tableName+'] n
	  where [Name2TokenFirst] like ''%-%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
      SET [Name2TokenLast] = ltrim(rtrim(substring([Name2TokenLast],1,(charindex(''-'',[Name2TokenLast]) -1))))
      from [dbo].['+@tableName+'] n
	  where [Name2TokenLast] like ''%-%'''
   exec(@sql)
------

   set @sql = 'update [dbo].['+@tableName+']
      SET [Name2Token1SurnameInd] = ''Y''
	  ,Name2Token1SurnameProbabilty = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[Name2TokenFirst]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
      SET [Name2Token2SurnameInd] = ''Y''
	  ,Name2Token2SurnameProbabilty = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[Name2TokenLast]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
      SET [Name2FormatType] = case
        when isnull([Name2Token1SurnameProbabilty],0) > isnull([Name2Token2SurnameProbabilty],0) then 2
        when isnull([Name2Token1SurnameProbabilty],0) < isnull([Name2Token2SurnameProbabilty],0) then 1
        else 2 end
      from [dbo].['+@tableName+']'
   exec(@sql)

------------------------------
------  Added to make Each County Name Format the same

DECLARE @pct as varchar(5) = '.95'

Set @sql = 'UPDATE n
  SET n.NameFormatType = CASE WHEN pct > ' + @pct + ' THEN z.NameFormatType ELSE n.NameFormatType END
  FROM ['+@tableName+'] n JOIN (
                SELECT FIPS,NameFormatType, CountFmtType,TotalCount,convert(money,convert(money,CountFmtType)/convert(money,TotalCount))  as pct  FROM(   
                                SELECT  t.FIPS,NameFormatType,CountFmtType,TotalCount
                                ,ROW_NUMBER() OVER(PARTITION BY t.FIPS ORDER BY CountFmtType DESC) AS RowNum
                                FROM (Select FIPS,NameFormatType,COUNT(*) as CountFmtType FROM ['+@tableName+']
                                WHERE FIPS is NOT NULL
                                GROUP BY FIPS,NameFormatType) t JOIN (Select Fips,Count(*) as TotalCount from ['+@tableName+'] group by Fips) z
                                on t.Fips = z.fips
                ) CountyFormat
WHERE RowNum = 1) z
on n.FIPS = z.FIPS'
exec(@sql)


----------------------------------------------------
-----Step 1-1 Update NameFormat N

  set @sql = 'update [dbo].['+@tableName+']
set nameformattype =''3''
--, nameformattype2 = ''N''
FROM [dbo].['+@tableName+']
where [Name1] like ''%,%''
and name1corpind is null and nameformattype = ''n'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set nameformattype =''1''
--, nameformattype2 = ''N''
FROM [dbo].['+@tableName+']
where [Name1] not like ''%,%''
and name1corpind is null and nameformattype = ''n'' and fips In (''26163'', ''36047'', ''36119'', ''46013'', ''46117'', ''49045'', ''53009'', ''55019'')'
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set nameformattype =''2''
--, nameformattype2 = ''N''
FROM [dbo].['+@tableName+']
where [Name1] not like ''%,%''
and name1corpind is null and nameformattype = ''n'' and fips In (''16055'', ''22055'', ''28015'', ''29143'', ''39047'', ''46115'', ''55079'')'
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set nameformattype =''2''
--, nameformattype2 = ''N''
FROM [dbo].['+@tableName+']
where [Name1] like ''%&%&%''
and name1corpind is null and nameformattype = ''n'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set nameformattype =''1''
--, nameformattype2 = ''N''
FROM [dbo].['+@tableName+']
where [Name1] is not null
and name1corpind is null and nameformattype = ''n'''
   exec(@sql)

--Step 2 Prepend Name1
  set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex(''('',[Name1],1)),40), [Name1Work] = ltrim(rtrim(Substring([Name1],1,(Charindex(''('',[Name1],1)-1))))
  FROM [dbo].['+@tableName+']
  where [Name1] like ''%(%''
  and name1corpind is null'
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex(''h/w'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex(''h/w'',[Name1],1)-1))
,[OwnerRelationship] = ''HW''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''%h/w%''
  and name1corpind is null'
   exec(@sql)

    set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex(''s/c'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex(''s/c'',[Name1],1)-1))
,[OwnerRelationship] = ''SC''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''%s/c%''
  and name1corpind is null'
   exec(@sql)

    set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex(''r/s'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex(''r/s'',[Name1],1)-1))
, [OwnerRights] = ''RS''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''%r/s%''
  and name1corpind is null'
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex(''t/c'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex(''t/c'',[Name1],1)-1))
, [OwnerRights] = ''TC''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''%t/c%''
  and name1corpind is null'
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex(''r/t'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex(''r/t'',[Name1],1)-1))
, [OwnerRights] = ''RT''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''%r/t%''
  and name1corpind is null'
   exec(@sql)

    set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex(''j/t'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex(''j/t'',[Name1],1)-1))
, [OwnerRights] = ''JT''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''%j/t%''
  and name1corpind is null'
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex('' jt'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex('' jt'',[Name1],1)-1))
, [OwnerRights] = ''JT''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''% jt %''
  and name1corpind is null'
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex('' jt'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex('' jt'',[Name1],1)-1))
, [OwnerRights] = ''JT''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''% jt''
  and name1corpind is null'
   exec(@sql)

        set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex('' lc'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex('' lc'',[Name1],1)-1))
, [OwnerRights] =  ''JT''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''% lc%''
  and name1corpind is null'
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex('' h w'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex('' h w'',[Name1],1)-1))
, [OwnerRelationship] = ''HW''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''% h w %''
  and name1corpind is null'
   exec(@sql)

        set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name1],(Charindex('' h w'',[Name1],1)),40)
, [Name1Work] = Substring([Name1],1,(Charindex('' h w'',[Name1],1)-1))
, [OwnerRelationship] = ''HW''
  FROM [dbo].['+@tableName+']
  where [Name1] like ''% h w''
  and name1corpind is null'
   exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex(''etux'',[Name1],1)-1))
,[NameRealtionship] = Substring([Name1],(Charindex(''etux'',[Name1],1)+4),40)
, OwnerEtalInd = ''EU''
FROM [dbo].['+@tableName+']
where [Name1] like ''% etux %''
and name1corpind is null'
   exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex(''et ux'',[Name1],1)-1))
,[NameRealtionship] = Substring([Name1],(Charindex(''et ux'',[Name1],1)+4),40)
, OwnerEtalInd = ''EU''
FROM [dbo].['+@tableName+']
where [Name1] like ''% et ux''
and name1corpind is null'
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex(''etal'',[Name1],1)-1))
,[NameRealtionship] = Substring([Name1],(Charindex(''etal'',[Name1],1)+4),40)
, OwnerEtalInd = ''EA''
FROM [dbo].['+@tableName+']
where [Name1] like ''% etal %''
and name1corpind is null'
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex(''et al'',[Name1],1)-1))
,[NameRealtionship] = Substring([Name1],(Charindex(''et al'',[Name1],1)+4),40)
 , OwnerEtalInd = ''EA''
FROM [dbo].['+@tableName+']
where [Name1] like ''% et al''
and name1corpind is null'
   exec(@sql)

-----Prepend Name2

  set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex(''('',[Name2],1)),40)
, [Name2Work] = ltrim(rtrim(Substring([Name2],1,(Charindex(''('',[Name2],1)-1))))
  FROM [dbo].['+@tableName+']
  where [Name2] like ''%(%'''
   exec(@sql)

        set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex(''h/w'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex(''h/w'',[Name2],1)-1))
,OwnerRelationship = ''HW''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''%h/w%''
  and name2corpind is null'
   exec(@sql)
 
    set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex(''s/c'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex(''s/c'',[Name2],1)-1))
,OwnerRights = ''SC''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''%s/c%'''
   exec(@sql)

    set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex(''r/s'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex(''r/s'',[Name2],1)-1))
,OwnerRights = ''RS''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''%r/s%'''
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex(''r/t'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex(''r/t'',[Name2],1)-1))
,OwnerRights = ''RT''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''%r/t%'''
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex(''t/c'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex(''t/c'',[Name2],1)-1))
,OwnerRights = ''TC''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''%t/c%'''
   exec(@sql)

    set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex(''j/t'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex(''j/t'',[Name2],1)-1))
,OwnerRights = ''JT''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''%j/t%'''
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex('' jt'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex('' jt'',[Name2],1)-1))
, OwnerRights = ''JT''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''% jt%'''
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex('' jt'',[Name2],1)),40)
, [Name1Work] = Substring([Name2],1,(Charindex('' jt'',[Name2],1)-1))
, OwnerRights = ''JT''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''% jt''
  and name1corpind is null'
   exec(@sql)

        set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex('' lc'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex('' lc'',[Name2],1)-1))
,OwnerRelationship = ''LC''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''% lc%'''
   exec(@sql)

      set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex('' H W'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex('' h w'',[Name2],1)-1))
,OwnerRelationship = ''HW''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''% h w%'''
   exec(@sql)

        set @sql = 'update '+@tableName+'
Set [NameRealtionship] = Substring([Name2],(Charindex('' H W'',[Name2],1)),40)
, [Name2Work] = Substring([Name2],1,(Charindex('' h w'',[Name2],1)-1))
,OwnerRelationship = ''HW''
  FROM [dbo].['+@tableName+']
  where [Name2] like ''% h w'''
   exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = Substring([Name2],1,(Charindex(''etux'',[Name2],1)-1))
,[NameRealtionship] = Substring([Name2],(Charindex(''etux'',[Name2],1)+4),40)
,OwnerEtalInd = ''EU''
FROM [dbo].['+@tableName+']
where [Name2] like ''%etux%'''
   exec(@sql)

    set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = Substring([Name2],1,(Charindex(''et ux'',[Name2],1)-1))
,[NameRealtionship] = Substring([Name2],(Charindex(''et ux'',[Name2],1)+4),40)
,OwnerEtalInd = ''EU''
FROM [dbo].['+@tableName+']
where [Name2] like ''%et ux'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = Substring([Name2],1,(Charindex(''etal'',[Name2],1)-1))
,[NameRealtionship] = Substring([Name2],(Charindex(''etal'',[Name2],1)+4),40)
,OwnerEtalInd = ''EA''
FROM [dbo].['+@tableName+']
where [Name2] like ''%etal%'''
   exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = Substring([Name2],1,(Charindex(''et al'',[Name2],1)-1))
,[NameRealtionship] = Substring([Name2],(Charindex(''et al'',[Name2],1)+4),40)
,OwnerEtalInd = ''EA''
FROM [dbo].['+@tableName+']
where [Name2] like ''%et al'''
   exec(@sql)

--Step 3 Name Format

----Format 1

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''&'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex(''&'',[Name1],1)+2),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%&%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' and '',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('' and '',[Name1],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''% and %''
and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' or '',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('' or '',[Name1],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''% or %''
and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''/'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex(''/'',[Name1],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%/%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('':'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('':'',[Name1],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%:%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('';'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('';'',[Name1],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%;%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--set @sql = 'update [dbo].['+@tableName+']
--set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''.'',[Name1],1)-1)))
--,[Name2Work] = ltrim(Substring([Name1],(Charindex(''.'',[Name1],1)+1),40))
--FROM [dbo].['+@tableName+']
--where [Name1] like ''%.%''
--and name1corpind is null and nameformattype = ''1'' and Name1Work is null'
--exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = [Name1]
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''1'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring(Name1work,1,2) + Substring(name1work,4,45)
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''1''
and (Name1Work like ''mc %'' or Name1Work like ''de %''or Name1Work like ''la %'' or Name1Work like ''di %'')'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring(Name1work,1,3) + Substring(name1work,5,45)
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''1''
and (Name1Work like ''mac %'' or Name1Work like ''von %'' or Name1Work like ''van %'' or Name1Work like ''Del %'')'
exec(@sql)

-------Remove Second Name from Name1Work

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''&'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''&'',[Name1Work],1)+2),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%&%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' and '',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('' and '',[Name1Work],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''% and %''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' or '',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('' or '',[Name1Work],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''% or %''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''/'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''/'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%/%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('':'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('':'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%:%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('';'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('';'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%;%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--set @sql = 'update [dbo].['+@tableName+']
--set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''.'',[Name1Work],1)-1)))
--,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''.'',[Name1Work],1)+1),40))
--FROM [dbo].['+@tableName+']
--where [Name1Work] like ''%.%''
--and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
--exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = [Name1Work]
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''1'' and Name1Work is Not null'
exec(@sql)

------Second Name

set @sql = 'update [dbo].['+@tableName+'] set [Name2Work] = Name2
where name2corpind is null and nameformattype = ''1'' and [Name2Work] is null
and name2 is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+'] set [Name2Work] = null
where name2corpind is null and nameformattype = ''1'' and ([Name2] Like ''aka%'' or [Name2] Like ''fka%'' or [Name2] Like ''DBA%'' or [Name2] Like ''nka%'' )
and name2 is not null'
exec(@sql)

------Remove Additional Names from Name2Work

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''&'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%&%''
and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' and '',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''% and %''
and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' or '',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''% or %''
and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''/'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%/%''
and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('':'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%:%''
and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('';'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%;%''
and Name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--  set @sql = 'update [dbo].['+@tableName+']
--set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''.'',[Name2Work],1)-1)))
--FROM [dbo].['+@tableName+']
--where [Name2Work] like ''%.%''
--and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
--exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = [Name2Work]
FROM [dbo].['+@tableName+']'
exec(@sql)


----Format 2

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex(''&'',[Name1],1)-1))
,[Name2Work] = Substring([Name1],(Charindex(''&'',[Name1],1)+2),40)
FROM [dbo].['+@tableName+']
where [Name1] like ''%&%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex('' and '',[Name1],1)-1))
,[Name2Work] = Substring([Name1],(Charindex('' and '',[Name1],1)+4),40)
FROM [dbo].['+@tableName+']
where [Name1] like ''% and %''
and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex('' or '',[Name1],1)-1))
,[Name2Work] = Substring([Name1],(Charindex('' or '',[Name1],1)+4),40)
FROM [dbo].['+@tableName+']
where [Name1] like ''% or %''
and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex(''/'',[Name1],1)-1))
,[Name2Work] = Substring([Name1],(Charindex(''/'',[Name1],1)+1),40)
FROM [dbo].['+@tableName+']
where [Name1] like ''%/%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex('':'',[Name1],1)-1))
,[Name2Work] = Substring([Name1],(Charindex('':'',[Name1],1)+1),40)
FROM [dbo].['+@tableName+']
where [Name1] like ''%:%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring([Name1],1,(Charindex('';'',[Name1],1)-1))
,[Name2Work] = Substring([Name1],(Charindex('';'',[Name1],1)+1),40)
FROM [dbo].['+@tableName+']
where [Name1] like ''%;%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--set @sql = 'update [dbo].['+@tableName+']
--set [Name1Work] = Substring([Name1],1,(Charindex(''.'',[Name1],1)-1))
--,[Name2Work] = Substring([Name1],(Charindex(''.'',[Name1],1)+1),40)
--FROM [dbo].['+@tableName+']
--where [Name1] like ''%.%''
--and name1corpind is null and nameformattype = ''2'' and Name1Work is null'
--exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] =  substring([Name1],0,80)
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''2'' and Name1Work is null'
exec(@sql)--af 20161202 added substring(80)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring(Name1work,1,2) + Substring(name1work,4,45)
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''2''
and (Name1Work like ''mc %'' or Name1Work like ''de %'' or Name1Work like ''la %'' or Name1Work like ''di %'')'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring(Name1work,1,3) + Substring(name1work,5,45)
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''2''
and (Name1Work like ''mac %'' or Name1Work like ''von %'' or Name1Work like ''van %''or Name1Work like ''del %'')'
exec(@sql)

-------Remove Second Name from Name1Work

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''&'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''&'',[Name1Work],1)+2),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%&%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' and '',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('' and '',[Name1Work],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''% and %''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' or '',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('' or '',[Name1Work],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''% or %''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''/'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''/'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%/%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('':'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('':'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%:%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('';'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('';'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%;%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--set @sql = 'update [dbo].['+@tableName+']
--set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''.'',[Name1Work],1)-1)))
--,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''.'',[Name1Work],1)+1),40))
--FROM [dbo].['+@tableName+']
--where [Name1Work] like ''%.%''
--and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
--exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = [Name1Work]
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''2'' and Name1Work is Not null'
exec(@sql)

------Second Name

set @sql = 'update [dbo].['+@tableName+'] set [Name2Work] = substring(Name2,0,80)
where name2corpind is null and nameformattype = ''2'' and [Name2Work] is null
and name2 is not null'
exec(@sql)--af 20161202 added substring(80)

set @sql = 'update [dbo].['+@tableName+'] set [Name2Work] = null
where name2corpind is null and nameformattype = ''2'' and ([Name2] Like ''aka%''or [Name2] Like ''fka%'' or [Name2] Like ''DBA%'' or [Name2] Like ''nka%'' )
and name2 is not null'
exec(@sql)

------Remove Additional Names from Name2Work

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''&'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%&%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' and '',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''% and %''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' or '',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''% or %''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''/'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%/%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('':'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%:%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('';'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%;%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--  set @sql = 'update [dbo].['+@tableName+']
--set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''.'',[Name2Work],1)-1)))
--FROM [dbo].['+@tableName+']
--where [Name2Work] like ''%.%''
--and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
--exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = [Name2Work]
FROM [dbo].['+@tableName+']'
exec(@sql)
----Format 3


set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''&'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex(''&'',[Name1],1)+2),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%&%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' and '',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('' and '',[Name1],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''% and %''
and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('' or '',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('' or '',[Name1],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''% or %''
and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''/'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex(''/'',[Name1],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%/%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('':'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('':'',[Name1],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%:%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1],1,(Charindex('';'',[Name1],1)-1)))
,[Name2Work] = ltrim(Substring([Name1],(Charindex('';'',[Name1],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1] like ''%;%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--set @sql = 'update [dbo].['+@tableName+']
--set [Name1Work] = rtrim(Substring([Name1],1,(Charindex(''.'',[Name1],1)-1)))
--,[Name2Work] = ltrim(Substring([Name1],(Charindex(''.'',[Name1],1)+1),40))
--FROM [dbo].['+@tableName+']
--where [Name1] like ''%.%''
--and name1corpind is null and nameformattype = ''3'' and Name1Work is null'
--exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = [Name1]
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''3'' and Name1Work is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring(Name1work,1,2) + Substring(name1work,4,45)
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''3''
and (Name1Work like ''mc %'' or Name1Work like ''de %''or Name1Work like ''la %'')'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = Substring(Name1work,1,3) + Substring(name1work,5,45)
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''3''
and (Name1Work like ''mac %'' or Name1Work like ''von %''or Name1Work like ''van %'')'
exec(@sql)

-------Remove Second Name from Name1Work

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''&'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''&'',[Name1Work],1)+2),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%&%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' and '',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('' and '',[Name1Work],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''% and %''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('' or '',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('' or '',[Name1Work],1)+4),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''% or %''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''/'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''/'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%/%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('':'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('':'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%:%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex('';'',[Name1Work],1)-1)))
,[Name2Work] = ltrim(Substring([Name1Work],(Charindex('';'',[Name1Work],1)+1),40))
FROM [dbo].['+@tableName+']
where [Name1Work] like ''%;%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--set @sql = 'update [dbo].['+@tableName+']
--set [Name1Work] = rtrim(Substring([Name1Work],1,(Charindex(''.'',[Name1Work],1)-1)))
--,[Name2Work] = ltrim(Substring([Name1Work],(Charindex(''.'',[Name1Work],1)+1),40))
--FROM [dbo].['+@tableName+']
--where [Name1Work] like ''%.%''
--and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
--exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set [Name1Work] = [Name1Work]
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''3'' and Name1Work is Not null'
exec(@sql)

------Second Name

set @sql = 'update [dbo].['+@tableName+'] set [Name2Work] = Name2
where name2corpind is null and nameformattype = ''3'' and [Name2Work] is null
and name2 is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+'] set [Name2Work] = null
where name2corpind is null and nameformattype = ''3'' and ([Name2] Like ''aka%''or [Name2] Like ''fka%'' or [Name2] Like ''DBA%'' or [Name2] Like ''nka%'' )
and name2 is not null'
exec(@sql)

------Remove Additional Names from Name2Work

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''&'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%&%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' and '',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''% and %''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('' or '',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''% or %''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''/'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%/%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('':'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%:%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex('';'',[Name2Work],1)-1)))
FROM [dbo].['+@tableName+']
where [Name2Work] like ''%;%''
and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
exec(@sql)

----  Modified by Bill 20170821 causing bad results
--  set @sql = 'update [dbo].['+@tableName+']
--set [Name2Work] = rtrim(Substring([Name2Work],1,(Charindex(''.'',[Name2Work],1)-1)))
--FROM [dbo].['+@tableName+']
--where [Name2Work] like ''%.%''
--and Name2corpind is null and nameformattype = ''2'' and Name2Work is not null'
--exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
set [Name2Work] = [Name2Work]
FROM [dbo].['+@tableName+']'
exec(@sql)

--Step 4 Generations

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''SR'',Name1Work = Substring(Name1Work,1,(Charindex('' SR'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% SR'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''SR''
,Name1Work = Substring(Name1Work,1,(Charindex('' SR'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% SR.'''
exec(@sql)

-----  Added 20160423
set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''SR''
,Name1Work = Replace(Name1Work,''SR'','''')
from '+@tableName+'
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% SR.'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''JR''
,Name1Work = Substring(Name1Work,1,(Charindex('' JR'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% JR'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''JR''
,Name1Work = Substring(Name1Work,1,(Charindex('' JR'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% JR.'''
exec(@sql)

----- Added 20160423
set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''JR''
,Name1Work = Replace(Name1Work,''JR'','''')
from '+@tableName+'
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% JR.'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''II''
,Name1Work = Substring(Name1Work,1,(Charindex('' II'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% II'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''IV''
,Name1Work = Substring(Name1Work,1,(Charindex('' IV'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% IV'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''III''
,Name1Work = Substring(Name1Work,1,(Charindex('' III'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% III'''
exec(@sql)
------------  Removed due to issues with Middle Name 20160423
--set @sql = 'update [dbo].['+@tableName+']
--set Name1Generation = ''V''
--,Name1Work = Substring(Name1Work,1,(Charindex('' V'',Name1Work,1)-1))
--from [dbo].['+@tableName+']
--Where name1corpind is null and Name1Work is  not null and
--Name1Work like ''% V'''
--exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''MD''
,Name1Work = Substring(Name1Work,1,(Charindex('' MD'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% MD'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''RET''
,Name1Work = Substring(Name1Work,1,(Charindex('' RET'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% RET'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name1Generation = ''REV''
,Name1Work = Substring(Name1Work,1,(Charindex('' REV'',Name1Work,1)-1))
from [dbo].['+@tableName+']
Where name1corpind is null and Name1Work is  not null and
Name1Work like ''% REV'''
exec(@sql)

----Second Name

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''SR'',Name2Work = Substring(Name2Work,1,(Charindex('' SR'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% SR'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''SR''
,Name2Work = Substring(Name2Work,1,(Charindex('' SR.'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% SR.'''
exec(@sql)

-----  Added 20160423
set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''SR''
,Name2Work = Replace(Name2Work,'' SR.'','''')
from '+@tableName+'
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% SR.'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''JR''
,Name2Work = Substring(Name2Work,1,(Charindex('' JR'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% JR'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''JR''
,Name2Work = Substring(Name2Work,1,(Charindex('' JR.'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% JR.'''
exec(@sql)

---------Added 20160423
set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''JR''
,Name2Work = Replace(Name2Work,''JR.'','''')
from '+@tableName+'
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% JR.'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''II''
,Name2Work = Substring(Name2Work,1,(Charindex('' II'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% II'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''IV''
,Name2Work = Substring(Name2Work,1,(Charindex('' IV'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name1Work is  not null and
Name2Work like ''% IV'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''III''
,Name2Work = Substring(Name2Work,1,(Charindex('' III'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% III'''
exec(@sql)

/*
set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''V''
,Name2Work = Substring(Name2Work,1,(Charindex('' V'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% V'''
exec(@sql)
*/

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''MD''
,Name2Work = Substring(Name2Work,1,(Charindex('' MD'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% MD'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''RET''
,Name2Work = Substring(Name2Work,1,(Charindex('' RET'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% RET'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set Name2Generation = ''REV''
,Name2Work = Substring(Name2Work,1,(Charindex('' REV'',Name2Work,1)-1))
from [dbo].['+@tableName+']
Where name2corpind is null and Name2Work is  not null and
Name2Work like ''% REV'''
exec(@sql)


-- Step 5 Name Breakout

----Format 1

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Substring(Name1Work,1,(Charindex('','',Name1Work,1)-1))
,Name1Work = ltrim(Substring(Name1Work,(Charindex('','',Name1Work,1)+1),40))
FROM [dbo].['+@tableName+']
where Name1Work like ''%,%''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1)),Name1Work = rtrim(ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40)))
FROM [dbo].['+@tableName+']
where Name1Work like ''% %''
and name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Last is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Name1Work, Name1Work = null
FROM [dbo].['+@tableName+'] 
where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Work not like ''% %'' and len(Name1Work) > 1'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Middle = Name1Work, Name1Work = null
FROM [dbo].['+@tableName+'] 
where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and len(Name1Work) = 1'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Middle = REVERSE(RIGHT(REVERSE (Name1Work), len(Name1Work) - NULLIF(charindex('' '', REVERSE(Name1Work)),0)))
FROM [dbo].['+@tableName+'] where name1corpind is null and nameformattype = ''1'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = REVERSE( LEFT( REVERSE(Name1Work), CHARINDEX('' '', REVERSE(Name1Work))-1 ) )
FROM [dbo].['+@tableName+'] where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Work like ''% %'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Name1Work
FROM [dbo].['+@tableName+'] where name1corpind is null and nameformattype = ''1'' and Name1Work is not null and Name1Work not like ''% %'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = REVERSE( LEFT( REVERSE(Name2Work), CHARINDEX('' '', REVERSE(Name2Work))-1 ) )
FROM [dbo].['+@tableName+'] where name2corpind is null and nameformattype = ''1'' and Name2Work is not null and Name2Work like ''% %'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Name2Last
FROM [dbo].['+@tableName+'] where name2corpind is null and nameformattype = ''1'' and (Name1Last is null or Name1Last = '''')'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
set  Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1)), Name2Work = rtrim(ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40)))
FROM [dbo].['+@tableName+']
where Name2Work like ''% %''
and name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2Middle = REVERSE(RIGHT(REVERSE (Name2Work), len(Name2Work) - NULLIF(charindex('' '', REVERSE(Name2Work)),0)))
FROM [dbo].['+@tableName+'] where name2corpind is null and nameformattype = ''1'' and Name2Work is not null'
exec(@sql)

----Format 2

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Substring(Name1Work,1,(Charindex('','',Name1Work,1)-1))
,Name1Work = ltrim(Substring(Name1Work,(Charindex('','',Name1Work,1)+1),40))
FROM [dbo].['+@tableName+']
where Name1Work like ''%,%''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1))
,Name1Work = ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40))
FROM [dbo].['+@tableName+']
where Name1Work like ''% %''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null and Name1Last is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Generation = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1))
,Name1Work = ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40))
FROM [dbo].['+@tableName+']
where Name1Work like ''% %''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null and (Name1Work like ''JR %'' or Name1Work like ''SR %'' or Name1Work like ''III %'' or Name1Work like ''IV %'')'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1))
,Name1Middle = Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40)
FROM [dbo].['+@tableName+']
where Name1Work like ''% %''
and name1corpind is null and nameformattype = ''2'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = [Name1Work]
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''2'' and Name1first is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1))
,Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
FROM [dbo].['+@tableName+']
where name2corpind is null and nameformattype = ''2'' and Name2Work like ''% %'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2Generation = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1))
,Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
FROM [dbo].['+@tableName+']
where Name2Work like ''% %''
and name2corpind is null and nameformattype = ''2'' and Name2Work is not null and (Name2Work like ''JR %'' or Name2Work like ''SR %'' or Name2Work like ''III %'' or Name2Work like ''IV %'')'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1))
,Name2Work = ltrim(stuff(Name2Work,1,charindex('' '',Name2Work),''''))
FROM [dbo].['+@tableName+']
where name2corpind is null and nameformattype = ''2'' and Name2Work like ''% %'''
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2Work, Name2Work = null
FROM [dbo].['+@tableName+']
where name2corpind is null and nameformattype = ''2'' and Name2Work not like ''% %'' and Name2First is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2Middle = Name2Work
FROM [dbo].['+@tableName+']
where name2corpind is null and nameformattype = ''2''and Name2Work is not null'
exec(@sql)


----Format 3

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Substring(Name1Work,1,(Charindex('','',Name1Work,1)-1))
,Name1Work = ltrim(Substring(Name1Work,(Charindex('','',Name1Work,1)+1),40))
FROM [dbo].['+@tableName+']
where Name1Work like ''%,%''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1))
,Name1Work = ltrim(Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40))
FROM [dbo].['+@tableName+']
where Name1Work like ''% %''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null and Name1Last is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Substring(Name1Work,1,(Charindex('' '',Name1Work,1)-1))
,Name1Middle = Substring(Name1Work,(Charindex('' '',Name1Work,1)+1),40)
FROM [dbo].['+@tableName+']
where Name1Work like ''% %''
and name1corpind is null and nameformattype = ''3'' and Name1Work is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = [Name1Work]
FROM [dbo].['+@tableName+']
where name1corpind is null and nameformattype = ''3'' and Name1first is null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1))
,Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
FROM [dbo].['+@tableName+']
where name2corpind is null and nameformattype = ''3'' and Name2Work like ''% %'''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Substring(Name2Work,1,(Charindex('' '',Name2Work,1)-1))
,Name2Work = ltrim(Substring(Name2Work,(Charindex('' '',Name2Work,1)+1),40))
FROM [dbo].['+@tableName+']
where name2corpind is null and nameformattype = ''3'' and Name2Work like ''% %'''
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2Work, Name2Work = null
FROM [dbo].['+@tableName+']
where name2corpind is null and nameformattype = ''3'' and Name2Work not like ''% %'' and Name2First is null'
exec(@sql)

--Update [dbo].[tmp_NameWork_sl]
--Set Name2Middle = Name2Work
--FROM [dbo].[tmp_NameWork_sl]
--where name2corpind is null and nameformattype = '3'and Name2Work is not null

-----  Added 20151115 to null empty strings
set @sql = 'update [dbo].['+@tableName+']
Set Name1First = null
FROM [dbo].['+@tableName+']
where [Name1first] like '''''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Middle = null
FROM [dbo].['+@tableName+']
where [Name1Middle] like '''''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = null
FROM [dbo].['+@tableName+']
where [Name1Last] like '''''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2First = null
FROM [dbo].['+@tableName+']
where [Name2first] like '''''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2Middle = null
FROM [dbo].['+@tableName+']
where [Name2Middle] like '''''
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = null
FROM [dbo].['+@tableName+']
where [Name2Last] like '''''
exec(@sql)

--------- Rearrange Name

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Name1Middle
, Name1Middle = Name1last
, Name1Last =Name1First
FROM [dbo].['+@tableName+']
where Len(Name1last) = 1 and [Name1first] is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2Middle
, Name2Middle = Name2last
, Name2Last =Name2First
FROM [dbo].['+@tableName+']
where Len(Name2last) = 1 and [Name2first] is not null'
exec(@sql)



set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2Last
, Name2Middle = Name2First
, Name2Last = Name2Middle
FROM [dbo].['+@tableName+']
where Len(Name2First) = 1 and [Name2Last] is not null and [Name2Middle] = [Name1Last]'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2Middle = Null
, Name2Last = Name2Middle
FROM [dbo].['+@tableName+']
where Len(Name2First) = 1 and [Name2Last] is not null and [Name2Middle] = [Name2Last]'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2Last
, Name2Middle = Name2First
, Name2Last = Name2Middle
FROM [dbo].['+@tableName+']
where Len(Name2First) = 1 and [Name2Last] is not null and len([Name2Middle]) >3'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2Last
, Name2Middle = Name2First
, Name2Last = Null
FROM [dbo].['+@tableName+']
where Len(Name2First) = 1 and [Name2Last] is not null and [Name2Last] not like ''&'''
exec(@sql)


  set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = Name1Last
FROM [dbo].['+@tableName+']
where (Name2Last is null and len(ltrim(rtrim(Name2First))) > 1) or (Name2Last like '':'' and len(ltrim(rtrim(Name2First))) > 1) or (Name2Last Like '''' and len(ltrim(rtrim(Name2First))) > 1)'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Name1last
, Name1Middle = Name1first
, Name1Last =Name2Last
FROM [dbo].['+@tableName+']
where Nameformattype = ''1'' and Len(Name1last) > 1 and [Name1first] is null and Name2Last is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2last
, Name2Last = Name1Last
FROM [dbo].['+@tableName+']
where Nameformattype = ''1'' and Len(Name1last) > 1 and [Name2first] is null and Name2Last is not null'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Name2last
, Name2Last = Name1Last
FROM [dbo].['+@tableName+']
where Len(Name1last) > 1 and [Name2first] is null and Name2Last is not null'
exec(@sql)

---------------- Added New 20160424
  set @sql = 'update [dbo].['+@tableName+']
Set Name1last = Name2last
FROM [dbo].['+@tableName+']
where (Len(ltrim(rtrim(Name1last))) = 0 or Name1last is null) and Name2Last is not null'
exec(@sql)

---------------- Added New 20160519
  set @sql = 'update [dbo].['+@tableName+']
Set Name2last = Name1last
FROM [dbo].['+@tableName+']
where (Len(ltrim(rtrim(Name1last))) > 0 or Name1last is not null) and (Len(ltrim(rtrim(Name2Last))) = 0 or Name2last is null) and (Len(ltrim(rtrim(Name2first))) > 0 or Len(ltrim(rtrim(Name2middle))) > 0)'
exec(@sql)

---------------- Added New 20160424
  set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Name1last
,Name1Middle = Name1First
,Name1last = Name2last
FROM [dbo].['+@tableName+']
where (Len(ltrim(rtrim(Name1First))) = 1 and Name1last is not null) and Name2Last is not null'
exec(@sql)

--------------  Addedd to correct double last names 20171117

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Ltrim(Rtrim(Name1work))
FROM [dbo].['+@tableName+']
where ltrim(rtrim(Name1First)) = ltrim(rtrim(Name1Last)) and (Name1work is not null and Name1Work not like '''')'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Ltrim(Rtrim(Name2work))
FROM [dbo].['+@tableName+']
where ltrim(rtrim(Name2First)) = ltrim(rtrim(Name2Last)) and (Name2work is not null and Name2Work not like '''')'
exec(@sql)

----Step 6 Cleanup

set @sql = 'update [dbo].['+@tableName+']
set [Name1Last] = [Name1Middle] + [Name1Last]
FROM [dbo].['+@tableName+']
where name1corpind is null
and ([Name1Middle] like ''mc'' or [Name1Middle] like ''de''or [Name1Middle] like ''la'')'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name1Last] = [Name1Middle] + [Name1Last]
FROM [dbo].['+@tableName+']
where name1corpind is null
and ([Name1Middle] like ''mac'' or [Name1Middle] like ''von''or [Name1Middle] like ''van'')'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name2Last] = [Name2Middle] + [Name2Last]
FROM [dbo].['+@tableName+']
where name1corpind is null
and ([Name2Middle] like ''mc'' or [Name2Middle] like ''de''or [Name2Middle] like ''la'')'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name1Last] = [Name1Middle] + [Name1Last]
FROM [dbo].['+@tableName+']
where name1corpind is null
and ([Name1Middle] like ''mac'' or [Name1Middle] like ''von''or [Name1Middle] like ''van'')'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Replace(Name1First,'','','''') where Name1First like ''%,''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name1Middle = Replace(Name1Middle,'','','''') where Name1Middle like ''%,''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name1Last = Replace(Name1last,'','','''') where Name1Last like ''%,''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = Replace(Name2last,'','','''') where Name2Last like ''%,''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name1Middle = Replace(Name1Middle,''.'','''') where Name1Middle like ''%.''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2Middle = Replace(Name2Middle,''.'','''') where Name2Middle like ''%.''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2Middle = Replace(Name2Middle,''&'','''') where Name2Middle like ''&''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = Replace(Name2last,''&'','''') where Name2Last like ''&''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
Set Name2Last = Replace(Name2last,'':'','''') where Name2Last like '':''
and name1corpind is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name2First] = Substring([Name2Middle],1,(Charindex('' '',[Name2Middle],1)-1))
,[Name2Middle] = Substring([Name2Middle],(Charindex('' '',[Name2Middle],1)+4),40)
 where Name2Last = Name2first and Name2Middle like ''% %'''
exec(@sql)


 
set @sql = 'update [dbo].['+@tableName+']
set [Name2First] = [Name2Middle]
,[Name2Middle] = Null
 where Name2Last = Name2first and Name2Middle not like ''% %'''
exec(@sql)


 set @sql = 'update [dbo].['+@tableName+']
 set [Name1Middle] = Null
 Where [Name1Middle] like ''%&%'' or [Name1Middle] like ''&%'''
exec(@sql)


  set @sql = 'update [dbo].['+@tableName+']
 set [Name2Middle] = Null
 Where [Name2Middle] like ''%&%'' or [Name2Middle] like ''&%'''
exec(@sql)


/*
   set @sql = 'update [dbo].['+@tableName+']
  set [Name2Last] = Substring([Name2Last],1,(Len([Name2Last])-1))
  --FROM [dbo].['+@tableName+']
  where [Name2Last] like ''%,'''
exec(@sql)


  set @sql = 'update [dbo].['+@tableName+']
  set [Name2fmt] = null
  --FROM [dbo].['+@tableName+']
  where [Name2fmt] like ''%&%'''
exec(@sql)


  set @sql = 'update [dbo].['+@tableName+']
  set [Name2fmt] = null
  --FROM [dbo].['+@tableName+']
  where [Name2fmt] like ''or%'' or [Name2fmt] like ''and%'' or [Name2fmt] like ''%and%'' or [Name2fmt] like ''%,%'''
exec(@sql)
*/

-------  added 20171116  Probability test for Surname

   set @sql = 'update [dbo].['+@tableName+']
      SET [Name1LastProb] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[Name1Last]'
   exec(@sql)

   set @sql = 'update [dbo].['+@tableName+']
      SET [Name2LastProb] = [SurNameProbability]
      from [dbo].['+@tableName+'] n
      join zSurname_Master s
      on s.SurnameName = n.[Name2Last]'
   exec(@sql)

-------  added 20171116  Probability Fix Name 2 Surname

   set @sql = 'update [dbo].['+@tableName+']
      SET [Name2Last] = [Name1Last]
	  ,[Name2First] = [Name2Last]
	  ,[Name2Middle] = [Name2First]
      from [dbo].['+@tableName+'] n
      Where [Name2LastProb] < .1 and [Name2Last] <> [Name1Last]'
   exec(@sql)

--------------  Addedd to correct double last names 20171117

set @sql = 'update [dbo].['+@tableName+']
Set Name1First = Ltrim(Rtrim(Name1work))
FROM [dbo].['+@tableName+']
where ltrim(rtrim(Name1First)) = ltrim(rtrim(Name1Last)) and (Name1work is not null and Name1Work not like '''')'
exec(@sql)

set @sql = 'update [dbo].['+@tableName+']
Set Name2First = Ltrim(Rtrim(Name2work))
FROM [dbo].['+@tableName+']
where ltrim(rtrim(Name2First)) = ltrim(rtrim(Name2Last)) and (Name2work is not null and Name2Work not like '''')'
exec(@sql)

------- Format Concatenated Names

set @sql = 'update [dbo].['+@tableName+']
set [Name1fmt] = (ltrim(rTrim(([Name1Last] + '' '' + [Name1first] + '' '' + [Name1Middle]))))
where [Name1CorpInd] is null and [Name1Middle] is not null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name1fmt] = (ltrim(rTrim(([Name1Last] + '' '' + [Name1first]))))
where [Name1CorpInd] is null and [Name1Middle] is null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name2fmt] = (ltrim(rtrim((ltrim(rTrim(([Name2Last] + '' '' + [Name2first]))) + '' '' + [Name2Middle]))))
where [Name2CorpInd] is null and [Name2Middle] is not null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name2fmt] = (ltrim(rtrim((ltrim(rTrim(([Name2Last] + '' '' + [Name2first])))))))
where [Name2CorpInd] is null and [Name2Middle] is null'
exec(@sql)


---- ADDED 20160419 this was missing to code to fix nulls in Name1fmt and Name2fmt

set @sql = 'update [dbo].['+@tableName+']
set [Name1fmt] = (ltrim(rTrim(([name1]))))
where [Name1CorpInd] is null and [Name1fmt] is null and [name1] is not null'
exec(@sql)


set @sql = 'update [dbo].['+@tableName+']
set [Name2fmt] = (ltrim(rTrim(([name2]))))
where [Name2CorpInd] is null and [Name2fmt] is null and [name2] is not null'
exec(@sql)


--CleanGarbage

  set @sql = 'update [dbo].['+@tableName+']
  set [Name2fmt] = null
  where [Name2fmt] like ''&%'' or [Name2fmt] like ''%&%'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], '','', '''' )
  where [Name1CorpInd] = ''Y'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace([Name1], ''.'', '''' )
  where [Name1CorpInd] = ''Y'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], '','', '''' )
  where [Name2CorpInd] = ''Y'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''.'', '''' )
  where [Name2CorpInd] = ''Y'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace([Name2], ''.'', '''' )
  where [Name2CorpInd] = ''Y'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2Fmt = Replace([Name2Fmt], ''  '', '' '' )
  where [Name2Fmt] like ''%  %'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name1Fmt = Replace([Name1Fmt], ''  '', '' '' )
  where [Name1Fmt] like ''%  %'''
exec(@sql)

     -----   Addedd to Clean Last Name where empty  --  Addedd 20171206
  set @sql = 'update [dbo].['+@tableName+']
  set Name1Last = Ltrim(rtrim([Name1First]))
  ,[Name1First] = null
  where ([Name1Last] is null or [Name1Last] like '''')
  and ([Name1First] is not null or [Name1First] not like '''')'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2Last = Ltrim(rtrim([Name2First]))
  ,[Name2First] = null
  where ([Name2Last] is null or [Name2Last] like '''')
  and ([Name2First] is not null or [Name2First] not like '''')'
exec(@sql)

--------  Final Clean Up Name 1 and Name 2 ---  Added 20151117

  set @sql = 'update [dbo].['+@tableName+']
  set Name1 = Replace(Replace([Name1], ''  '', '' '' ), ''  '', '' '' )
  where [Name1] like ''%  %'''
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2 = Replace(Replace([Name2], ''  '', '' '' ), ''  '', '' '' )
  where [Name2] like ''%  %'''
exec(@sql)

--------  Final Clean Up formatted Name 1 and Name 2 ---  Added 20180510
  set @sql = 'update [dbo].['+@tableName+']
  set Name1Fmt = Replace(Replace([Name1Fmt], '':'', '''' ), '' ,'', '''' )'
exec(@sql)

  set @sql = 'update [dbo].['+@tableName+']
  set Name2Fmt = Replace(Replace([Name2Fmt], '':'', '''' ), '' ,'', '''' )'
exec(@sql)

SET CONCAT_NULL_YIELDS_NULL ON


END



