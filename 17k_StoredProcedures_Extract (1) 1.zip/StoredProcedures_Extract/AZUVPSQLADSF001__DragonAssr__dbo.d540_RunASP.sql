SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


-- =============================================
-- Create date: 20220401
-- Description:	Address Standardization
-- =============================================

CREATE PROCEDURE [dbo].[d540_RunASP] 
	
AS
BEGIN

	SET NOCOUNT ON;

    EXEC [dbo].[usp_100b_sp_ASP_Cust_to_ASP]

	EXEC [dbo].[usp_100d_ASP_Property_Situs_to_Licensing]



END



