SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE PROCEDURE [dbo].[usp_name_parser_lookup_cleanup] -- @tableName varchar(255)

AS
BEGIN

-------------------------------- sp 
-- select count(*) from [DragonNameTest].[dbo].[lkup_Corp_Name] A with (nolock) where BeginsWith is not null -- 2135
-- select count(*) from [DragonNameTest].[dbo].[lkup_Corp_Name] A with (nolock) where ContainsIn is not null -- 2236 -- highest count is used as the first insert other are updates
-- select count(*) from [DragonNameTest].[dbo].[lkup_Corp_Name] A with (nolock) where EndsWith is not null -- 2098
-- select count(*) from [DragonNameTest].[dbo].[lkup_Corp_Name] A with (nolock) where Only is not null -- 424

DROP TABLE [DragonNameTest].[dbo].[t_lkup_Corp_Name]
CREATE TABLE [DragonNameTest].[dbo].[t_lkup_Corp_Name](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[BeginsWith] [varchar](50) NULL,
	[ContainsIn] [varchar](50) NULL,
	[EndsWith] [varchar](50) NULL,
	[Only] [varchar](50) NULL) 
DROP TABLE [DragonNameTest].[dbo].[t_BeginsWith]
CREATE TABLE [DragonNameTest].[dbo].[t_BeginsWith] ([ID] [int] IDENTITY(1,1) NOT NULL, [BeginsWith] [varchar](50) NULL, CONSTRAINT UC_BeginsWith UNIQUE (BeginsWith) WITH (IGNORE_DUP_KEY = ON)) 
DROP TABLE [DragonNameTest].[dbo].[t_ContainsIn]
CREATE TABLE [DragonNameTest].[dbo].[t_ContainsIn] ([ID] [int] IDENTITY(1,1) NOT NULL, [ContainsIn] [varchar](50) NULL, CONSTRAINT UC_ContainsIn UNIQUE (ContainsIn) WITH (IGNORE_DUP_KEY = ON))
DROP TABLE [DragonNameTest].[dbo].[t_EndsWith]
CREATE TABLE [DragonNameTest].[dbo].[t_EndsWith] ([ID] [int] IDENTITY(1,1) NOT NULL, [EndsWith] [varchar](50) NULL, CONSTRAINT UC_EndsWith UNIQUE (EndsWith) WITH (IGNORE_DUP_KEY = ON))
DROP TABLE [DragonNameTest].[dbo].[t_Only]
CREATE TABLE [DragonNameTest].[dbo].[t_Only] ([ID] [int] IDENTITY(1,1) NOT NULL, [Only] [varchar](50) NULL, CONSTRAINT UC_Only UNIQUE (Only) WITH (IGNORE_DUP_KEY = ON))

-- load t_tables
insert [DragonNameTest].[dbo].[t_BeginsWith] (BeginsWith) select BeginsWith from [DragonNameTest].[dbo].[lkup_Corp_Name] where BeginsWith is not null order by BeginsWith 
insert [DragonNameTest].[dbo].[t_ContainsIn] (ContainsIn) select ContainsIn from [DragonNameTest].[dbo].[lkup_Corp_Name] where ContainsIn is not null order by ContainsIn 
insert [DragonNameTest].[dbo].[t_EndsWith] (EndsWith) select EndsWith from [DragonNameTest].[dbo].[lkup_Corp_Name] where EndsWith is not null order by EndsWith 
insert [DragonNameTest].[dbo].[t_Only] (Only) select Only from [DragonNameTest].[dbo].[lkup_Corp_Name] where Only is not null order by Only
 
-- load highest count of lookup column count (ContainsIn)
insert [DragonNameTest].[dbo].[t_lkup_Corp_Name] (ContainsIn) select ContainsIn from [DragonNameTest].[dbo].[t_ContainsIn]

-- update BeginsWith
set nocount on
declare @t_cnt_b int
set @t_cnt_b = 1
declare @t_BeginWith varchar(50)

declare c_update_b cursor scroll keyset for

select BeginsWith from [DragonNameTest].[dbo].[t_BeginsWith] 

open c_update_b
fetch next from c_update_b into @t_BeginWith

while (@@fetch_status = 0)
Begin
update a set a.BeginsWith = @t_BeginWith 
    from [DragonNameTest].[dbo].[t_lkup_Corp_Name] a
    where a.ID = @t_cnt_b

set @t_cnt_b = @t_cnt_b + 1

fetch next from c_update_b into @t_BeginWith
end

close c_update_b
deallocate c_update_b

-- update EndsWith
set nocount on
declare @t_cnt_e int
set @t_cnt_e = 1
declare @t_EndsWith varchar(50)

declare c_update_e cursor scroll keyset for

select EndsWith from [DragonNameTest].[dbo].[t_EndsWith] 

open c_update_e
fetch next from c_update_e into @t_EndsWith

while (@@fetch_status = 0)
Begin
update a set a.EndsWith = @t_EndsWith 
    from [DragonNameTest].[dbo].[t_lkup_Corp_Name] a
    where a.ID = @t_cnt_e

set @t_cnt_e = @t_cnt_e + 1

fetch next from c_update_e into @t_EndsWith
end

close c_update_e
deallocate c_update_e

-- update Only
set nocount on
declare @t_cnt_o int
set @t_cnt_o = 1
declare @t_Only varchar(50)

declare c_update_o cursor scroll keyset for

select Only from [DragonNameTest].[dbo].[t_Only] 

open c_update_o
fetch next from c_update_o into @t_Only

while (@@fetch_status = 0)
Begin
update a set a.Only = @t_Only 
    from [DragonNameTest].[dbo].[t_lkup_Corp_Name] a
    where a.ID = @t_cnt_o

set @t_cnt_o = @t_cnt_o + 1

fetch next from c_update_o into @t_Only
end

close c_update_o
deallocate c_update_o

-- create indexes
CREATE NONCLUSTERED INDEX [IDX_lkup_Corp_Name_BeginsWith] ON [DragonNameTest].[dbo].[t_lkup_Corp_Name] ([BeginsWith])
CREATE NONCLUSTERED INDEX [IDX_lkup_Corp_Name_ContainsIn] ON [DragonNameTest].[dbo].[t_lkup_Corp_Name] ([ContainsIn])
CREATE NONCLUSTERED INDEX [IDX_lkup_Corp_Name_EndsWith] ON [DragonNameTest].[dbo].[t_lkup_Corp_Name] ([EndsWith])
CREATE NONCLUSTERED INDEX [IDX_lkup_Corp_Name_Only] ON [DragonNameTest].[dbo].[t_lkup_Corp_Name] ([Only])

-- rename tables
select 'Rename tables NOT COMPLETED'
select 'exec sp_rename ''dbo.lkup_Corp_Name'', ''lkup_Corp_Name_old'''
select 'exec sp_rename ''dbo.t_lkup_Corp_Name'', ''lkup_Corp_Name'''

END

