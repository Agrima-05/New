SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

Create Proc [dbo].[usp_GetHouseNumber--]
(
	@HouseNumber varchar(20)
	, @HouseNumber2 varchar(20)
	, @HouseNumberSuffix Varchar(20)
)
AS
Begin
	Select [dbo].[fnGetHouseNumber](@HouseNumber, @HouseNumber2, @HouseNumberSuffix)
End


