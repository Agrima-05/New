SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
-- ===============================================================
-- Description:	Roll up Last and Prior Sale data to Property Table
-- ===============================================================
CREATE PROCEDURE [dbo].[x700_NameParsing_BKDragon]
AS
BEGIN

exec [NameParser].[dbo].[00136_assessee_p_sl_ref_to_namework_BKDragon]
exec [NameParser].[dbo].[usp_name_parser_unified_daily] 'p_sl_ref_assessee_BKDragon', @RowCounts = 'N', @MailingLabel = 'Y'
exec [NameParser].[dbo].[00138_assessee_namework_to_p_sl_ref_BKDragon]


END

