SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE PROCEDURE [dbo].[GetUnparsedNames]
AS
	;WITH AgentNames AS (
		SELECT DISTINCT
			MLS_LISTING_AGENT_NAME_nochar
			,' ' + REPLACE(REPLACE(MLS_LISTING_AGENT_NAME_nochar, '.', ' '), '-', ' ') + ' ' AS FixedName
		FROM MLS_Listing_Agent
		WHERE
			IsNameParsed = 0
			AND MLS_LISTING_AGENT_NAME_nochar > ''
			AND MLS_LISTING_AGENT_NAME_nochar LIKE '%[A-Z]%'
			AND MLS_LISTING_AGENT_NAME_nochar NOT IN (
				SELECT Input
				FROM ParsedNames
		)
	)
	SELECT MLS_LISTING_AGENT_NAME_nochar
	FROM AgentNames
	WHERE
		FixedName NOT LIKE '% The %'
		AND FixedName NOT LIKE '% Team %'
		AND FixedName NOT LIKE '% Group %'
		AND FixedName NOT LIKE '% Hotline %'
		AND FixedName NOT LIKE '% Leasing %'
		AND FixedName NOT LIKE '% Marketing %'
		AND FixedName NOT LIKE '% Sales %'
		AND FixedName NOT LIKE '% Property %'
		AND FixedName NOT LIKE '% Properties %'
		AND FixedName NOT LIKE '% Advisors %'
		AND FixedName NOT LIKE '% Listing %'
		AND FixedName NOT LIKE '% Listings %'
		AND FixedName NOT LIKE '% Development %'
		AND FixedName NOT LIKE '% REO %'
		AND FixedName NOT LIKE '% Professionals %'
		AND FixedName NOT LIKE '% Associates %'
		AND FixedName NOT LIKE '% Management %'
		AND FixedName NOT LIKE '% Investment %'
		AND FixedName NOT LIKE '% Consultants %'
		AND FixedName NOT LIKE '% District %'
		AND FixedName NOT LIKE '% Experts %'
		AND FixedName NOT LIKE '% Company %'
		AND FixedName NOT LIKE '% Companies %'
		AND FixedName NOT LIKE '% Dream Home %'
		AND FixedName NOT LIKE '% Commercial %'
		AND FixedName NOT LIKE '% Recreation %'
		AND FixedName NOT LIKE '% Water/% %'

