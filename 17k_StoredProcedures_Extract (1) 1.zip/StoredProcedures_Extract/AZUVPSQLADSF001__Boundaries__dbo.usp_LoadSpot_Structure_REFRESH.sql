SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

-- =============================================
-- =============================================
CREATE PROCEDURE [dbo].[usp_LoadSpot_Structure_REFRESH]
AS
BEGIN

	SET NOCOUNT ON;

		DROP TABLE IF EXISTS dlvry.Structure_BATCH_REFRESH
		DROP TABLE IF EXISTS dlvry.Structure_BATCH_REFRESH_FIPS
		DECLARE @SQL nvarchar(1000)
		--DECLARE @Date as varchar(10)
		--Select @Date = convert(varchar(10),max([UpdatedDate]),120) from dbo.FASPOT_Structures with(NOLOCK)

		SET @SQL = 'SELECT FIPS INTO dlvry.Structure_BATCH_REFRESH_FIPS 
		FROM OPENQUERY([AZUVPSQLDTDB034],''Select DISTINCT FIPS from [Spot].[dlvry].[Structure];'')
		'
		EXEC (@SQL);

		DECLARE @FipsCode varchar(5)

		Select FIPS INTO #FIPS from [dlvry].[Structure_BATCH_REFRESH_ALL] Group by FIPS

		DECLARE FmtDocPost CURSOR FOR  
			SELECT FIPS 
			FROM dlvry.Structure_BATCH_REFRESH_FIPS
				WHERE FIPs NOT IN(Select FIPS from #FIPS)
			Group by Fips
			order by Fips

		OPEN FmtDocPost   
		FETCH NEXT FROM FmtDocPost INTO @FipsCode

		WHILE @@FETCH_STATUS = 0   
		BEGIN   
  
			PRINT @FipsCode

				DROP TABLE IF EXISTS dlvry.Structure_BATCH_REFRESH
				--DECLARE @SQL nvarchar(1000)
				--Select @Date = convert(varchar(10),GETDATE()+1,20)

				SET @SQL = 'SELECT * INTO [dlvry].[Structure_BATCH_REFRESH] 
				FROM OPENQUERY([AZUVPSQLDTDB034],''Select * from [Spot].[dlvry].[Structure] WHERE [Fips] IN(''''' + @FipsCode + ''''');'')
				'
				EXEC (@SQL);

				EXEC('INSERT INTO [dlvry].[Structure_BATCH_REFRESH_ALL]([Fips]
				  ,[MasterAssrId]
				  ,[RefId]
				  ,[Geom]
				  ,[MasterStructureId]
				  ,[Uuid]
				  ,[Height]
				  ,[ImageDate]
				  ,[UpdatedDate]
				  ,[Geom3857])
				Select [Fips]
					,[MasterAssrId]
					,[RefId]
					,[Geom]
					,[MasterStructureId]
					,[Uuid]
					,[Height]
					,[ImageDate]
					,[UpdatedDate]
					,[Geom3857]
					FROM [dlvry].[Structure_BATCH_REFRESH] 
				')

			FETCH NEXT FROM FmtDocPost INTO @FipsCode   
		END   

		CLOSE FmtDocPost   
		DEALLOCATE FmtDocPost 

		DROP TABLE IF EXISTS #FIPS
END
