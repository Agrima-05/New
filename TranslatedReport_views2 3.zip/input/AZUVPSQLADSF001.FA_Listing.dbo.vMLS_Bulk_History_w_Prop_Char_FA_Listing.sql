SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [FA_Listing].[dbo].[vMLS_Bulk_History_w_Prop_Char_FA_Listing]
AS
SELECT RTRIM(ISNULL(LTRIM(Substring(addr.HouseNumber, 1, LEN(addr.HouseNumber)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Direction, 1, LEN(addr.Direction)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Street_Name, 1, LEN(addr.Street_Name)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Street_Type, 1, LEN(addr.Street_Type)) + ' '), '') + ISNULL(LTRIM(Substring(addr.Unit, 1, LEN(addr.Unit)) + ' '), '')) AS [Property Address]
	,RTRIM(ISNULL(addr.City, '')) AS [Property City]
	,RTRIM(ISNULL(addr.STD_State, '')) AS [Property State]
	,RTRIM(ISNULL(addr.Zip, '')) AS [Property Zip]
	,RTRIM(ISNULL(addr.Plus4, '')) AS [Property Zip + 4]
	,ISNULL(mls.APN, '') /*ISNULL(bkfs.APN, '')*/ AS [Assessor's Parcel Identification Number]
	,RIGHT('00000' + CAST(lh.Fips AS VARCHAR(5)), 5) AS [County FIPS]
	,ISNULL(CAST(lh.REF_ID AS VARCHAR), '') /*ISNULL(CAST(bkfs.BK_PROP_ID AS VARCHAR), '')*/ AS [Internal FA Property Ref ID]
	,ISNULL(lh.PROPERTY_TYPE,'') AS [Property Type]
	,CASE 
		WHEN ISNULL(lh.PROPERTY_TYPE,'') <> ISNULL(lh.PROPERTY_SUB_TYPE,'')
			THEN ISNULL(lh.PROPERTY_SUB_TYPE,'')
		ELSE ''
		END AS [Property Sub-Type]
	,CASE 
		WHEN CAST(ROUND(lh.LOT_SIZE_STD, 0) AS NUMERIC(15, 0)) > 0
			THEN CAST(CAST(ROUND(lh.LOT_SIZE_STD, 0) AS NUMERIC(15, 0)) AS VARCHAR)
		ELSE ''
		END AS [Lot Size (Sq Ft)]
	,CASE 
		WHEN CAST(ROUND(lh.HOME_SIZE_STD, 0) AS NUMERIC(15, 0)) > 0
			THEN CAST(CAST(ROUND(lh.HOME_SIZE_STD, 0) AS NUMERIC(15, 0)) AS VARCHAR)
		ELSE ''
		END AS [Home Size (Sq Ft)]
	,ISNULL(lh.STYLE,'') AS [Home or Building Style]
	,ISNULL(lh.HEATING_FTRS,'') AS [Heating Type]
	,ISNULL(Stuff((
				SELECT ',' + Value
				FROM dbo.ListingSubFeatures lsf WITH (NOLOCK)
				LEFT OUTER JOIN dbo.SubFeatureValues sfv WITH (NOLOCK) ON sfv.id = lsf.SubFeatureValueId
				WHERE sfv.SubFeatureTypeId = 1 --HEAT_FUEL_TYPE
					AND lsf.Listing_ID = lh.Listing_ID
					AND ISNUMERIC(Value) = 0
				FOR XML PATH('')
				), 1, 1, ''), '') AS [Heating Fuel Type]
	,ISNULL(lh.COOLING_FTRS,'') AS [Cooling Type]
	,ISNULL(Stuff((
				SELECT ',' + Value
				FROM dbo.ListingSubFeatures lsf WITH (NOLOCK)
				LEFT OUTER JOIN dbo.SubFeatureValues sfv WITH (NOLOCK) ON sfv.id = lsf.SubFeatureValueId
				WHERE sfv.SubFeatureTypeId = 2 --COOL_FUEL_TYPE
					AND lsf.Listing_ID = lh.Listing_ID
					AND ISNUMERIC(Value) = 0
				FOR XML PATH('')
				), 1, 1, ''), '') AS [Cooling Fuel Type]
	,ISNULL(lh.NBR_STORIES,'') AS [Number of Stories]
	,CASE 
		WHEN CAST(lh.YEAR_BUILT_STD AS VARCHAR) IS NOT NULL
			THEN CAST(lh.YEAR_BUILT_STD AS VARCHAR)
		ELSE ''
		END AS [Year Built]
	,ISNULL(lh.ROOFING,'') AS [Roof Type]
	,ISNULL(lh.EXTERIOR_CONSTRUCTION,'') AS [Exterior Construction]
	,CASE 
		WHEN CAST(lh.NBR_BEDRMS_STD AS VARCHAR) <> '0'
			THEN CAST(lh.NBR_BEDRMS_STD AS VARCHAR)
		ELSE ''
		END AS [Number of Bedrooms]
	,CASE 
		WHEN CAST(lh.NBR_BATH_STD AS VARCHAR) <> '0.00'
			THEN CAST(lh.NBR_BATH_STD AS VARCHAR)
		ELSE ''
		END AS [Number of Bathrooms]
	,CASE 
		WHEN CAST(lh.NBR_GRG_STD AS VARCHAR) <> '0'
			THEN CAST(lh.NBR_GRG_STD AS VARCHAR)
		ELSE ''
		END AS [Number of Garages]
	,ISNULL(lh.PARKING_FTRS,'') AS [Garage Type]
	,ISNULL(lh.POOL_FTRS,'') AS [Pool Features]
	,ISNULL(lh.VIEW_1,'') AS [View Features]
	,CASE 
		WHEN CAST(ROUND(lh.PRICE_PER_SQFT_STD, 0) AS NUMERIC(15, 0)) > 0
			THEN CAST(CAST(ROUND(lh.PRICE_PER_SQFT_STD, 0) AS NUMERIC(15, 0)) AS VARCHAR)
		ELSE ''
		END AS [Price per Square Feet]
	,' ' AS [Porch]
	,' ' AS [Patio]
	,' ' AS [Deck]
	,CASE 
		WHEN CAST(lh.BSMT_FIN_SQFT_STD AS VARCHAR) IS NOT NULL
			THEN 'Yes'
		ELSE ' '
		END AS [Basement]
	,ISNULL(lh.RANGE_AIRCONDITIONERS,'') AS [Air Conditioner]
	,CASE 
		WHEN CAST(lh.NBR_FIREPLACE_STD AS VARCHAR) IS NOT NULL
			THEN CAST(lh.NBR_FIREPLACE_STD AS VARCHAR)
		ELSE ''
		END AS [Number of Fireplaces]
	,ISNULL(FIREPLACE_PRESENT,'') AS [Presence of Fireplace]
	,ISNULL(lh.FIREPLACE_DESC_STD, '') AS [Fireplace Description]
	,ISNULL(lh.INTERIOR_FTRS,'') AS [Interior Features]
	,ISNULL(lh.EXTERIOR_FTRS,'') AS [Exterior Features]
	,ISNULL(lh.EXISTING_STRUCTURES,'') AS [Existing Structures]
	,ISNULL(mls.PROPERTY_DETAILS, '') AS [Property Details]
	,ISNULL(lh.LOT_FTRS,'') AS [Lot Features]
	,ISNULL(lh.ZONING,'') AS [Zoning]
	,ISNULL(lh.NEIGHBORHOOD,'') AS [Neighborhood]
	,ISNULL(lh.SCHOOL_DISTRICT,'') AS [School District]
	,ISNULL(lh.ELEMENTARY_SCHOOL,'') AS [Elementary School]
	,ISNULL(lh.MIDDLE_SCHOOL,'') AS [Middle School]
	,ISNULL(lh.HIGH_SCHOOL,'') AS [High School]
	,ISNULL(lh.APPLIANCES,'') AS [Appliances]
	,ISNULL(mls.APX_LOT_DIMENSIONS, '') AS [Approximate Lot Dimensions]
	,ISNULL(lh.TOPOGRAPHY,'') AS [Topogrophy]
	,ISNULL(lh.WATER_FRONT_FTRS,'') AS [Waterfront Features]
	,ISNULL(lh.WATER,'') AS [Water]
	,ISNULL(lh.WATER_SOURCE,'') AS [Water Source]
	,ISNULL(lh.WATER_AMMENITIES,'') AS [Water Amenities]
	,ISNULL(lh.WATER_ACCESS,'') AS [Water Access]
	,ISNULL(lh.WATER_HEATER,'') AS [Water Heater]
	--,CASE 
	--	WHEN lh.MLS_STATUS_STD = 'SOLD'
	--		OR lh.MLS_LIST_DATE_STD IS NULL
	--		THEN ''
	--	WHEN lh.MLS_LIST_DATE_STD IS NOT NULL
	--		THEN CAST(DATEDIFF(DAY, lh.MLS_LIST_DATE_STD, ISNULL(CASE 
	--							WHEN lh.MLS_STATUS_STD = 'SOLD'
	--								THEN lh.SOLD_DATE_STD
	--							WHEN lh.MLS_STATUS_STD = 'FAIL'
	--								THEN lh.UPDATE_FLAG_DATE_STD
	--							ELSE GETDATE()
	--							END, GETDATE())) AS VARCHAR)
	--	END AS [FA Calculated Days on Market]
	,CASE
		WHEN (select CAST(MLS_DAYS_ON_MARKET_STD AS VARCHAR) from dbo.vListing_DOM where Listing_Id = lh.Listing_Id) <> 0
			THEN (select CAST(MLS_DAYS_ON_MARKET_STD AS VARCHAR) from dbo.vListing_DOM where Listing_Id = lh.Listing_Id)
		ELSE ''
		END AS [FA Calculated Days on Market]
	,CASE 
		WHEN CAST(lh.MLS_LIST_DATE_STD AS VARCHAR) IS NOT NULL
			THEN CAST(lh.MLS_LIST_DATE_STD AS VARCHAR)
		ELSE ''
		END AS [Current Original Listing Date]
	,ISNULL(lh.MLS_Listing_number, '') AS [Listing Number]
	,lh.MLS_STATUS_STD AS [Status]
	,ISNULL(lh.MLS_STATUS_SUB_TYPE_STD, '') AS [Status Sub Type]
	,CASE 
		WHEN l.Rental_Ind = 1
			THEN 'Y'
		ELSE ''
		END AS [Rental Ind]
	,CASE 
		WHEN CAST(lh.MLS_LIST_PRICE_STD AS NUMERIC(15)) > 0
			THEN CAST(CAST(lh.MLS_LIST_PRICE_STD AS NUMERIC(15)) AS VARCHAR)
		ELSE ''
		END AS [Current Listing Price]
	,CASE 
		WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) > 0
			THEN CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) AS VARCHAR)
		ELSE ''
		END AS [Sold Price]
	,CASE 
		WHEN CAST(lh.SOLD_DATE_STD AS VARCHAR) IS NOT NULL
			THEN CAST(lh.SOLD_DATE_STD AS VARCHAR)
		ELSE ''
		END AS [Sold Date]
	,CASE 
		WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) > 1000
			THEN CASE 
					WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) % 1000 = 0
						THEN CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) + 1000 AS VARCHAR)
					ELSE CAST(CAST(ROUND(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)), - 3) AS NUMERIC(15)) AS VARCHAR)
					END
		WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) > 0
			THEN CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) AS VARCHAR)
		ELSE ''
		END AS [FA Adjusted Sold Price]
	,CASE 
		WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) > 199
			THEN CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) - 200 AS VARCHAR) + '-' + CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) + 200 AS VARCHAR)
		WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) > 99
			THEN CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) - 100 AS VARCHAR) + '-' + CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) + 100 AS VARCHAR)
		WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) > 9
			THEN CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) - 010 AS VARCHAR) + '-' + CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) + 010 AS VARCHAR)
		WHEN CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) > 0
			THEN CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) - 001 AS VARCHAR) + '-' + CAST(CAST(lh.SOLD_PRICE_STD AS NUMERIC(15)) + 001 AS VARCHAR)
		ELSE ''
		END AS [FA Sold Price Range]
	,lh.Listing_ID AS [Listing Tracking ID]
	,convert(nvarchar(8),lh.UPDATE_FLAG_DATE_STD,112) + right('00000000000' + cast(lh.Listing_ID AS nvarchar(11)), 11) AS [FA Unique Listing Identifier - Ref ID]
	,lh.UPDATE_FLAG_DATE_STD AS [Update Timestamp]
	,CASE 
		WHEN (lh.UPDATE_FLAG_DATE_STD = (SELECT min(UPDATE_FLAG_DATE_STD) FROM dbo.vListingHistory(NOLOCK) lh_min WHERE lh_min.Listing_Id = lh.Listing_ID))
			THEN 'A'
		ELSE 'C'
		END AS [Add, Change, Delete Indicator]
FROM dbo.vListingFullHistory(NOLOCK) lh
INNER JOIN dbo.Listing(NOLOCK) l ON l.Listing_ID = lh.Listing_ID
LEFT OUTER JOIN FAMLS.dbo.FA_MLS(NOLOCK) mls ON mls.Row_id = l.LastRow_Id
LEFT OUTER JOIN famls.dbo.FA_MLS_Raw_Std_Address(NOLOCK) addr ON addr.Row_Id = l.AddrId AND addr.Addr_type = 'S'
Where lh.Fips > 0 and lh.REF_ID is not null


