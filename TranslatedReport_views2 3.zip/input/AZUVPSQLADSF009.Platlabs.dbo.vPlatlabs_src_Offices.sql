SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Platlabs].[dbo].[vPlatlabs_src_Offices]
AS
		  SELECT NULL as [SrcOfficeID]
				,o.mls_id as [SrcMLSID]
				,o.dp_office_id as [SrcMLSOfficeID]
				,o.full_name as [SrcOfficeName]
				,LEFT(o.address,100) as [Address1]
				,NULL as [Address2]
				,o.city as [City]
				,o.state as [State]
				,NULL as [CountyID]
				,Case when o.zip like '% %' THEN NULL ELSE LEFT(o.zip,5) END as [Zip]
				,o.phone as [Phone]
				,o.email as [Email]
				,o.mls_create_date as [DateCreated]
				,o.last_update_date as [LastModifiedDate]
				,NULL as [DW_TimeStamp]
				,NULL as [Longitude]
				,NULL as [Latitude]
				,NULL as [FASTOfficeAddrBookID]
				,NULL as [OfficeRank]
				,left(o.address,100) as [SourceAddress1]
				,NULL as [SourceAddress2]
				,o.city as [SourceCity]
				,o.[state] as [SourceState]
				,Case when o.zip like '% %' THEN NULL ELSE LEFT(o.zip,5) END as [SourceZip]
				,NULL as [CassCertifiedAddress1]
				,NULL as [CassCertifiedAddress2]
				,NULL as [CassCertifiedCity]
				,NULL as [CassCertifiedState]
				,NULL as [CassCertifiedZip]
				,case when active = 'true' then 1 Else 0 end as [IsActive]
				,o.[uid] as platlabs_uid
				,o.[mls_id] as Platlabs_mls_id
				,GetDate() as LoadDate
		FROM src_PlatLabs.Office.Platlabs_Offices o with(NOLOCK) 
			WHERE o.mls_id in(Select mls_ID from src_platlabs.dbo.platlabs_update_config with(NOLOCK) where active = '1' and code like '%39')



