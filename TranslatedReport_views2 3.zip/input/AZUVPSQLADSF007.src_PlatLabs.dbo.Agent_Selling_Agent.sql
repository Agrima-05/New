SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [src_PlatLabs].[dbo].[Agent_Selling_Agent]
AS

	SELECT * FROM agent.Platlabs_agents WHERE [type] = 'Selling_Agent'




