SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON









CREATE VIEW [Data].[dbo].[vParcelAll]
AS
SELECT 
FADigitalMapMasterId as MapMasterId
,d.FIPS
,p.PropertyID
,CASE WHEN FormattedAPN is NULL THEN PARCELAPN ELSE FormattedAPN END as FormattedAPN
,SitusStdFullStreetAddress 
,SitusStdHouseNbr
,SitusStdHouseNbrSuffix
,SitusStdDirectionLeft
,SitusStdStreet
,SitusStdMode
,SitusStdDirectionRight
,SitusStdUnitType
,SitusStdUnitNbr
,SitusStdCity
,SitusStdState
,SitusStdZIP5
,SitusStdZIP4
,SitusStdCarrierCode
,CASE WHEN FALatitude is NULL THEN d.Latitude ELSE FALatitude END as FALatitude
,CASE WHEN FALongitude is NULL THEN d.Longitude ELSE FALongitude END as FALongitude
,d.FAGeoStatusCode
,d.UCIDFlag as FAUCIDFlag
,d.ParcelGeometry4269 as Geom
,d.GeomWKT
,d.FATimestamp
,P.StdLandUseCode


------Added 20200529 per BR for Convex Labs

,D.[FADigitalMapMasterId]  as FAPropertyBoundaryID


FROM DigitalMap.dbo.vParcelBoundaryAll d with(nolock) LEFT OUTER JOIN [Data].[dbo].[Property] p with(nolock)
  ON p.Fips = d.Fips and p.PropertyId = d.PropertyId 


GRANT SELECT ON [dbo].[vParcelAll] TO [CORP\cbrady] AS [dbo]
