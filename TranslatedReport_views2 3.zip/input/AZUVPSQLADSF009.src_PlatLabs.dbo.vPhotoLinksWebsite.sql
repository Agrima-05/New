SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



 CREATE view [src_PlatLabs].[dbo].[vPhotoLinksWebsite] 
 as
 ---- PHOTO LINKS WITH REF_ID

	 Select b.[FIPS]
	   ,b.[REF_ID]
	   ,a.[uid]
	   ,a.[mls_id]
	   ,a.[mls_listing_id]
	   ,a.[photo_count]
	   ,a.[photo_date]
	   ,a.[sequence_number]
	  ,CASE WHEN a.mls_id in(2714,2806,2863,2782,2860,2757,2665,2897,2762,2825,2764,2719,2760,2715,2717,2724,2899,2916,2852,2954,2707,2834,2837,2794,2723,2722,2708,2721,2960)
		THEN 'https://platlab-img.s3.us-east-1.' + REPLACE(a.[source_url],'https://s3.','')
			ELSE a.[source_url]
				END as source_url
      ,a.[modified_date]
      ,a.[LoadDate] 
	 from [src_PlatLabs].[photos].[RawPhotoLinks] a with(NOLOCK) JOIN listing.ListingsRaw b  with(NOLOCK)
		on a.mls_id = b.mls_id 
		and a.mls_listing_id = b.mls_listing_id
		JOIN Reports.dbo.SentToWEB_Photos s on a.mls_id = s.mls_id
		where b.mls_id in(Select mls_id from platlabs_update_config where code like '%_39' and active = '1')
		and a.LoadDate >= DateSentUpdates
		and b.Platlabs_Listdate >= '2025-01-01'

