SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [MarketShare].[dbo].[Foreclosure_Nation]
AS

SELECT [FclStatus]
      ,[PropertyType]
      ,[RecMonth]
      ,[Count]
  FROM [AZUVPSQLDTDB029.datatree.local].[Fulfillment].[dbo].[Foreclosure_Nation]


