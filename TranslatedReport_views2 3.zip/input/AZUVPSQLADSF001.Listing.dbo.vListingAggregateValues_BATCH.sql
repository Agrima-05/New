SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [Listing].[dbo].[vListingAggregateValues_BATCH]
AS
	SELECT
		lc.Listing_ID
		,MAX(CASE WHEN RowNumByValueAsc = 1 THEN Value END) AS Min_MLS_LIST_PRICE_STD
		,MAX(CASE WHEN RowNumByValueAsc = 1 THEN ValueDate END) AS Min_MLS_LIST_PRICE_STD_Date

		,MAX(CASE WHEN RowNumByValueDesc = 1 THEN Value END) AS Max_MLS_LIST_PRICE_STD
		,MAX(CASE WHEN RowNumByValueDesc = 1 THEN ValueDate END) AS Max_MLS_LIST_PRICE_STD_Date
	FROM (
		SELECT
			*
			,ROW_NUMBER() OVER (PARTITION BY Listing_ID ORDER BY CASE WHEN ISNUMERIC(Value) = 1 THEN CONVERT(NUMERIC(20, 2), Value) END, Value, ValueDate) AS RowNumByValueAsc
			,ROW_NUMBER() OVER (PARTITION BY Listing_ID ORDER BY CASE WHEN ISNUMERIC(Value) = 1 THEN CONVERT(NUMERIC(20, 2), Value) END DESC, Value DESC, ValueDate) AS RowNumByValueDesc
		FROM (
			SELECT
				c.Listing_ID
				,FieldId
				,Value
				,case when ValueDate>='2000-01-01' then ValueDate else Original_UPDATE_FLAG_DATE_STD end as ValueDate
			FROM FA_LIsting.dbo.ListingChange_BATCH c WITH (NOLOCK) inner join 
			FA_Listing.dbo.ListingHistory_BATCH lh on lh.Listing_ID=c.Listing_ID and lh.UpdateSeq=c.UpdateSeq
			WHERE FieldId = 2
			UNION ALL
			SELECT
				Listing_ID
				,2
				,MLS_LIST_PRICE_STD
				,ISNULL(MaxChangeDate, case when Created>='2000-01-01' then Created else Original_UPDATE_FLAG_DATE_STD end)
			FROM FA_LIsting.dbo.Listing_BATCH l WITH (NOLOCK)
			OUTER APPLY (
				SELECT MAX(case when ChangeDate>='2000-01-01' then ChangeDate else Original_UPDATE_FLAG_DATE_STD end) AS MaxChangeDate
				FROM FA_LIsting.dbo.ListingChange_BATCH lc WITH (NOLOCK) 
				inner join FA_Listing.dbo.ListingHistory_BATCH lh on lh.Listing_ID=lc.Listing_ID and lh.UpdateSeq=lc.UpdateSeq
				WHERE lc.Listing_ID = l.Listing_ID AND lc.FieldId = 2
			) lc
		) lc
	) lc
	WHERE lc.RowNumByValueAsc = 1 OR lc.RowNumByValueDesc = 1
	GROUP BY lc.Listing_ID

