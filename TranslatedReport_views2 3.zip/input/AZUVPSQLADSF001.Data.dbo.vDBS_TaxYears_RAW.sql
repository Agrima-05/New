SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Data].[dbo].[vDBS_TaxYears_RAW]
AS

SELECT  * FROM  [DBS_Tax_Lic].[dbo].[TaxYears]  with(NOLOCK)
	


GRANT SELECT ON [dbo].[vDBS_TaxYears_RAW] TO [CORP\cbrady] AS [dbo]
