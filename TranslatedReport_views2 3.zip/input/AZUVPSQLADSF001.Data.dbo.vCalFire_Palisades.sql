SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [Data].[dbo].[vCalFire_Palisades]
AS

Select b.FIPS
      ,b.PropertyID
      ,a.[GLOBALID]
      ,[DAMAGE]
      ,[StructureType]
      ,[RefId]
      ,a.[FormattedApn]
      ,[AddressLine]
      ,[City]
      ,[Latitude]
      ,[Longitude]
      ,[GEOM]
      ,a.[FATimeStamp]
      ,[UCID] 
	from [Boundaries].[dbo].[CalFire_Palisades_Eaton3_Output] a with(NOLOCK) JOIN data.dbo.property b with(NOLOCK)
	on a.REFID = b.DTDB_REF_ID 
	WHERE b.FIPS in(Select FIPS from AVM WHERE REF_ID in(Select REFID from [Boundaries].[dbo].[CalFire_Palisades_Eaton3_Output] with(NOLOCK)))


