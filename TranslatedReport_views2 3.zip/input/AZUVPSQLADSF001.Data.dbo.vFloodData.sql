SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vFloodData]
AS
		SELECT p.FIPS
			, p.PropertyID
			, p.FormattedAPN
			, p.SitusStdHouseNbr
			, p.SitusStdDirectionLeft
			, p.SitusStdStreet
			, p.SitusStdMode
			, p.SitusStdDirectionRight
			, p.SitusStdUnitNbr
			, p.SitusStdCity
			, p.SitusStdState
			, p.SitusStdZIP5
			, p.SitusStdZIP4
			, p.SitusStdCarrierCode
			, p.SitusCensusTract
			, f.CommunityName
			, f.CommunityNumber
			, f.FemaFloodZone
			, f.FemaMapDate
			, f.FemaMapNumber
			, f.InsideSFHA
			, f.FIRMID
			, f.PanelNumber
			, f.LicTimestamp as FATimestamp
			, p.APNSeqNbr
			, p.OldAPN
			, p.TaxAccountNumber
			, NULL AS FloodZoneInd
			, p.SitusStdFullStreetAddress
			, p.DTDB_Formatted_APN
			, p.DTDB_Unformatted_APN
				
			-------Added 20210825 per BR----
			, F.[C_S_FLD_HAZ_AR_fld_ar_id]
			, F.[C_S_POL_AR_pol_ar_id]
			, F.[C_S_FIRM_PAN_firm_id]
			, F.[ZoneSubtype]
			, F.UCID as FAUCIDFlag

			-----Added 20220721 for Costar
			,P.CS_FORMATTED_APN
			,P.CS_UNFORMATTED_APN


	FROM  dbo.Property AS p WITH(Nolock) INNER JOIN
        FEMA.dbo.LicFlood AS f WITH(Nolock) ON
			f.PropertyID = p.PropertyID




GRANT SELECT ON [dbo].[vFloodData] TO [CORP\cbrady] AS [dbo]
