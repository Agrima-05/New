SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

 Create view [src_PlatLabs].[dbo].[vAgent_ListData] 
 as
 ---- ListAgent data with List and sold dates

Select l.Platlabs_Listdate,l.sold_date,l.close_date,l.[status],a.* from agent.ListAgents a with(NOLOCK)
	JOIN listing.listingFull l with(NOLOCK)
	ON a.mls_id = l.mls_id
	and a.mls_listing_id = l.mls_listing_id
	 WHERE l.mls_id in(Select mls_id from platlabs_update_config where code like '%_39' and active = '1')



