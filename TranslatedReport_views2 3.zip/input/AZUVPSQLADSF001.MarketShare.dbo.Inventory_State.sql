SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [MarketShare].[dbo].[Inventory_State]
AS

SELECT *
  FROM [AZUVPSQLDTDB029.datatree.local].[MiNelson].[Stats].[Inventory_State]


