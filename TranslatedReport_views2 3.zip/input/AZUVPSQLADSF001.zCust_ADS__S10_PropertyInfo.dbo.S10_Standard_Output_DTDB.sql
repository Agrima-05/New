SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [zCust_ADS__S10_PropertyInfo].[dbo].[S10_Standard_Output_DTDB]
AS
SELECT dbo.S10_Output_DTDB.*
FROM     dbo.S10_Output_DTDB with(NOLOCK)



