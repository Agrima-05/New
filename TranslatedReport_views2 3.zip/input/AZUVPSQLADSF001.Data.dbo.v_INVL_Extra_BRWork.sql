SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON







CREATE VIEW [Data].[dbo].[v_INVL_Extra_BRWork]
AS


Select 
 TransactionID as TransactionID
,A.Fips as Fips
,State as State
,County as County
,DocumentYear as DocumentYear
,Recordingdt as Recordingdt
,DocumentDt as DocumentDt
,doc_filing_date as doc_filing_date
,DocNbrSrce as DocNbrSrce
,BookSrce as BookSrce
,PaceSrce as PaceSrce
,Doc_Category as Doc_Category
,DocTypeID as DocTypeID
,DocType as DocType
,DocumentTitle as DocumentTitle
,case_number as case_number
,case_book as case_book
,case_page as case_page
,date_of_death as date_of_death
,account_number as account_number
,amendment_number as amendment_number
,attorney_bar_number as attorney_bar_number
,bond_number as bond_number
,lot_line_adjustment_number as lot_line_adjustment_number
,certificate_number as certificate_number
,claim_number as claim_number
,contract_number as contract_number
,corporation_number as corporation_number
,excise_tax_number as excise_tax_number
,federal_tax_lien_area as federal_tax_lien_area
,federal_tax_lien_area_phone as federal_tax_lien_area_phone
,tax_last_day_for_refiling as tax_last_day_for_refiling
,tax_period_begin_date as tax_period_begin_date
,tax_period_end_date as tax_period_end_date
,tax_amount as tax_amount
,tax_interest_amount as tax_interest_amount
,tax_penalty_amount as tax_penalty_amount
,judgment_amount as judgment_amount
,judgment_grand_total as judgment_grand_total
,judgment_court_fees as judgment_court_fees
,judgment_attorney_fees as judgment_attorney_fees
,judgment_principal_fees as judgment_principal_fees
,judgment_interest_fees as judgment_interest_fees
,judgment_filing_fees as judgment_filing_fees
,judgment_per_diem_fees as judgment_per_diem_fees
,judgment_late_fees as judgment_late_fees
,judgment_tax_fees as judgment_tax_fees
,judgment_insurance_fees as judgment_insurance_fees
,judgment_other_fees as judgment_other_fees
,installment_judgment as installment_judgment
,license_number as license_number
,lien_number as lien_number
,map_plat_id as map_plat_id
,mechanics_lien_number as mechanics_lien_number
,ordinance_number as ordinance_number
,patent_number as patent_number
,permit_number as permit_number
,resolution_number as resolution_number
,tax_account_serial_warrant_number as tax_account_serial_warrant_number
,tax_type as tax_type
,trustees_sale_number as trustees_sale_number
,ucc_number as ucc_number
,undersigned_same_as_borrower as undersigned_same_as_borrower
,amount_due as amount_due
,amount_of_default as amount_of_default
,bond_amount as bond_amount
,cash_down_amount as cash_down_amount
,contract_amount as contract_amount
,collection_costs as collection_costs
,unpaid_balance as unpaid_balance
,unpaid_balance_as_of_modification_date as unpaid_balance_as_of_modification_date
,unpaid_prinicipal_amount_due as unpaid_prinicipal_amount
,date_of_divorce as date_of_divorce
,support_arrears_amount as support_arrears_amount
,support_payment_amount as support_payment_amount
,support_total_amount as support_total_amount
,date_amount_due as date_amount_due
,date_stay_ordered as date_stay_ordered
,bankruptcy_case_number as bankruptcy_case_number
,bankruptcy_chapter as bankruptcy_chapter
,bankruptcy_type as bankruptcy_type
,bankruptcy_location as bankruptcy_location
,case_filed_in_county as case_filed_in_county
,case_court_type as case_court_type
,case_original_number as case_original_number
,case_original_court_type as case_original_court_type
,case_status as case_status
,date_bankruptcy_closed as date_bankruptcy_closed
,date_bankruptcy_case_filed as date_bankruptcy_case_filed
,date_bankruptcy_conversion as date_bankruptcy_conversion
,date_bankruptcy_discharged as date_bankruptcy_discharged
,date_bankruptcy_dismissed as date_bankruptcy_dismissed
,date_bankruptcy_341_meeting as date_bankruptcy_341_meeting
,bankruptcy_341_meeting_time as bankruptcy_341_meeting_time
,requested_prepared_by_attorney_name_identifier as requested_prepared_by_attorney_name_identifier
,requested_prepared_by_attorney_last_company_name as requested_prepared_by_attorney_last_company_name
,requested_prepared_by_attorney_first_name as requested_prepared_by_attorney_first_name
,requested_prepared_by_attorney_middle_initial as requested_prepared_by_attorney_middle_initial
,requested_prepared_by_attorney_suffix as requested_prepared_by_attorney_suffix
,requested_prepared_by_attorney_address as requested_prepared_by_attorney_address
,requested_prepared_by_attorney_address_city as requested_prepared_by_attorney_address_city
,requested_prepared_by_attorney_address_state as requested_prepared_by_attorney_address_state
,requested_prepared_by_attorney_address_zip as requested_prepared_by_attorney_address_zip
,requested_prepared_by_attorney_phone as requested_prepared_by_attorney_phone
,Party1_Name1_FullName as Party1_Name1_FullName
,Party1_Name1_last_Company_Name as Party1_Name1_last_Company_Name
,Party1_Name1_First_Name as Party1_Name1_First_Name
,Party1_Name1_Middle_Name as Party1_Name1_Middle_Name
,Party1_Name1_Suffix as Party1_Name1_Suffix
,Party1_Name1_Roll_Type as Party1_Name1_Role_Type
,Party1_Name1_taxpayer_id_ssn_fein as Party1_Name1_taxpayer_id_ssn_fein
,Party1_Name1_Account_Nbr as Party1_Name1_Account_Nbr
,Party1_Name1_SSN_Nbr as Party1_Name1_SSN_Nbr
,Party1_Name1_MailPropertyID as Party1_Name1_MailPropertyID
,Party1_Name1_Address as Party1_Name1_Address
,Party1_Name1_PreDir as Party1_Name1_PreDir
,Party1_Name1_StreetNumber as Party1_Name1_StreetNumber
,Party1_Name1_StreetName as Party1_Name1_StreetName
,Party1_Name1_PostDir as Party1_Name1_PostDir
,Party1_Name1_StreetType as Party1_Name1_StreetType
,Party1_Name1_SuiteType as Party1_Name1_SuiteType
,Party1_Name1_Suite as Party1_Name1_Suite
,Party1_Name1_City as Party1_Name1_City
,Party1_Name1_State as Party1_Name1_State
,Party1_Name1_Zip as Party1_Name1_Zip
,Party1_Name1_ZipPlus4 as Party1_Name1_ZipPlus4
,Party1_Name2_FullName as Party1_Name2_FullName
,Party1_Name2_last_Company_Name as Party1_Name2_last_Company_Name
,Party1_Name2_First_Name as Party1_Name2_First_Name
,Party1_Name2_Middle_Name as Party1_Name2_Middle_Name
,Party1_Name2_Suffix as Party1_Name2_Suffix
,Party1_Name2_Roll_Type as Party1_Name2_Role_Type
,Party1_Name2_taxpayer_id_ssn_fein as Party1_Name2_taxpayer_id_ssn_fein
,Party1_Name2_Account_Nbr as Party1_Name2_Account_Nbr
,Party1_Name2_SSN_Nbr as Party1_Name2_SSN_Nbr
,Party1_Name2_MailPropertyID as Party1_Name2_MailPropertyID
,Party1_Name2_Address as Party1_Name2_Address
,Party1_Name2_PreDir as Party1_Name2_PreDir
,Party1_Name2_StreetNumber as Party1_Name2_StreetNumber
,Party1_Name2_StreetName as Party1_Name2_StreetName
,Party1_Name2_PostDir as Party1_Name2_PostDir
,Party1_Name2_StreetType as Party1_Name2_StreetType
,Party1_Name2_SuiteType as Party1_Name2_SuiteType
,Party1_Name2_Suite as Party1_Name2_Suite
,Party1_Name2_City as Party1_Name2_City
,Party1_Name2_State as Party1_Name2_State
,Party1_Name2_Zip as Party1_Name2_Zip
,Party1_Name2_ZipPlus4 as Party1_Name2_ZipPlus4
,Party1_Name3_FullName as Party1_Name3_FullName
,Party1_Name3_last_Company_Name as Party1_Name3_last_Company_Name
,Party1_Name3_First_Name as Party1_Name3_First_Name
,Party1_Name3_Middle_Name as Party1_Name3_Middle_Name
,Party1_Name3_Suffix as Party1_Name3_Suffix
,Party1_Name3_Roll_Type as Party1_Name3_Role_Type
,Party1_Name3_taxpayer_id_ssn_fein as Party1_Name3_taxpayer_id_ssn_fein
,null as Party1_Name3_Account_Nbr
,Party1_Name3_SSN_Nbr as Party1_Name3_SSN_Nbr
,Party1_Name3_MailPropertyID as Party1_Name3_MailPropertyID
,Party1_Name3_Address as Party1_Name3_Address
,Party1_Name3_PreDir as Party1_Name3_PreDir
,Party1_Name3_StreetNumber as Party1_Name3_StreetNumber
,Party1_Name3_StreetName as Party1_Name3_StreetName
,Party1_Name3_PostDir as Party1_Name3_PostDir
,Party1_Name3_StreetType as Party1_Name3_StreetType
,Party1_Name3_SuiteType as Party1_Name3_SuiteType
,Party1_Name3_Suite as Party1_Name3_Suite
,Party1_Name3_City as Party1_Name3_City
,Party1_Name3_State as Party1_Name3_State
,Party1_Name3_Zip as Party1_Name3_Zip
,Party1_Name3_ZipPlus4 as Party1_Name3_ZipPlus4
,Party1_Name4_FullName as Party1_Name4_FullName
,Party1_Name4_last_Company_Name as Party1_Name4_last_Company_Name
,Party1_Name4_First_Name as Party1_Name4_First_Name
,Party1_Name4_Middle_Name as Party1_Name4_Middle_Name
,Party1_Name4_Suffix as Party1_Name4_Suffix
,Party1_Name4_Roll_Type as Party1_Name4_Role_Type
,Party1_Name4_taxpayer_id_ssn_fein as Party1_Name4_taxpayer_id_ssn_fein
,Party1_Name4_Account_Nbr as Party1_Name4_Account_Nbr
,Party1_Name4_SSN_Nbr as Party1_Name4_SSN_Nbr
,Party1_Name4_MailPropertyID as Party1_Name4_MailPropertyID
,Party1_Name4_Address as Party1_Name4_Address
,Party1_Name4_PreDir as Party1_Name4_PreDir
,Party1_Name4_StreetNumber as Party1_Name4_StreetNumber
,Party1_Name4_StreetName as Party1_Name4_StreetName
,Party1_Name4_PostDir as Party1_Name4_PostDir
,Party1_Name4_StreetType as Party1_Name4_StreetType
,Party1_Name4_SuiteType as Party1_Name4_SuiteType
,Party1_Name4_Suite as Party1_Name4_Suite
,Party1_Name4_City as Party1_Name4_City
,Party1_Name4_State as Party1_Name4_State
,Party1_Name4_Zip as Party1_Name4_Zip
,Party1_Name4_ZipPlus4 as Party1_Name4_ZipPlus4
,Party2_Name1_FullName as Party2_Name1_FullName
,Party2_Name1_last_Company_Name as Party2_Name1_last_Company_Name
,Party2_Name1_First_Name as Party2_Name1_First_Name
,Party2_Name1_Middle_Name as Party2_Name1_Middle_Name
,Party2_Name1_Suffix as Party2_Name1_Suffix
,Party2_Name1_Roll_Type as Party2_Name1_Role_Type
,Party2_Name1_taxpayer_id_ssn_fein as Party2_Name1_taxpayer_id_ssn_fein
,Party2_Name1_Account_Nbr as Party2_Name1_Account_Nbr
,Party2_Name1_SSN_Nbr as Party2_Name1_SSN_Nbr
,Party2_Name1_MailPropertyID as Party2_Name1_MailPropertyID
,Party2_Name1_Address as Party2_Name1_Address
,Party2_Name1_PreDir as Party2_Name1_PreDir
,Party2_Name1_StreetNumber as Party2_Name1_StreetNumber
,Party2_Name1_StreetName as Party2_Name1_StreetName
,Party2_Name1_PostDir as Party2_Name1_PostDir
,Party2_Name1_StreetType as Party2_Name1_StreetType
,Party2_Name1_SuiteType as Party2_Name1_SuiteType
,Party2_Name1_Suite as Party2_Name1_Suite
,Party2_Name1_City as Party2_Name1_City
,Party2_Name1_State as Party2_Name1_State
,Party2_Name1_Zip as Party2_Name1_Zip
,Party2_Name1_ZipPlus4 as Party2_Name1_ZipPlus4
,Party2_Name2_FullName as Party2_Name2_FullName
,Party2_Name2_last_Company_Name as Party2_Name2_last_Company_Name
,Party2_Name2_First_Name as Party2_Name2_First_Name
,Party2_Name2_Middle_Name as Party2_Name2_Middle_Name
,Party2_Name2_Suffix as Party2_Name2_Suffix
,Party2_Name2_Roll_Type as Party2_Name2_Role_Type
,Party2_Name2_taxpayer_id_ssn_fein as Party2_Name2_taxpayer_id_ssn_fein
,Party2_Name2_Account_Nbr as Party2_Name2_Account_Nbr
,Party2_Name2_SSN_Nbr as Party2_Name2_SSN_Nbr
,Party2_Name2_MailPropertyID as Party2_Name2_MailPropertyID
,Party2_Name2_Address as Party2_Name2_Address
,Party2_Name2_PreDir as Party2_Name2_PreDir
,Party2_Name2_StreetNumber as Party2_Name2_StreetNumber
,Party2_Name2_StreetName as Party2_Name2_StreetName
,Party2_Name2_PostDir as Party2_Name2_PostDir
,Party2_Name2_StreetType as Party2_Name2_StreetType
,Party2_Name2_SuiteType as Party2_Name2_SuiteType
,Party2_Name2_Suite as Party2_Name2_Suite
,Party2_Name2_City as Party2_Name2_City
,Party2_Name2_State as Party2_Name2_State
,Party2_Name2_Zip as Party2_Name2_Zip
,Party2_Name2_ZipPlus4 as Party2_Name2_ZipPlus4
,Party2_Name3_FullName as Party2_Name3_FullName
,Party2_Name3_last_Company_Name as Party2_Name3_last_Company_Name
,Party2_Name3_First_Name as Party2_Name3_First_Name
,Party2_Name3_Middle_Name as Party2_Name3_Middle_Name
,Party2_Name3_Suffix as Party2_Name3_Suffix
,Party2_Name3_Roll_Type as Party2_Name3_Role_Type
,Party2_Name3_taxpayer_id_ssn_fein as Party2_Name3_taxpayer_id_ssn_fein
,Party2_Name3_Account_Nbr as Party2_Name3_Account_Nbr
,Party2_Name3_SSN_Nbr as Party2_Name3_SSN_Nbr
,Party2_Name3_MailPropertyID as Party2_Name3_MailPropertyID
,Party2_Name3_Address as Party2_Name3_Address
,Party2_Name3_PreDir as Party2_Name3_PreDir
,Party2_Name3_StreetNumber as Party2_Name3_StreetNumber
,Party2_Name3_StreetName as Party2_Name3_StreetName
,Party2_Name3_PostDir as Party2_Name3_PostDir
,Party2_Name3_StreetType as Party2_Name3_StreetType
,Party2_Name3_SuiteType as Party2_Name3_SuiteType
,Party2_Name3_Suite as Party2_Name3_Suite
,Party2_Name3_City as Party2_Name3_City
,Party2_Name3_State as Party2_Name3_State
,Party2_Name3_Zip as Party2_Name3_Zip
,Party2_Name3_ZipPlus4 as Party2_Name3_ZipPlus4
,Party2_Name4_FullName as Party2_Name4_FullName
,Party2_Name4_last_Company_Name as Party2_Name4_last_Company_Name
,Party2_Name4_First_Name as Party2_Name4_First_Name
,Party2_Name4_Middle_Name as Party2_Name4_Middle_Name
,Party2_Name4_Suffix as Party2_Name4_Suffix
,Party2_Name4_Roll_Type as Party2_Name4_Role_Type
,Party2_Name4_taxpayer_id_ssn_fein as Party2_Name4_taxpayer_id_ssn_fein
,Party2_Name4_Account_Nbr as Party2_Name4_Account_Nbr
,Party2_Name4_SSN_Nbr as Party2_Name4_SSN_Nbr
,Party2_Name4_MailPropertyID as Party2_Name4_MailPropertyID
,Party2_Name4_Address as Party2_Name4_Address
,Party2_Name4_PreDir as Party2_Name4_PreDir
,Party2_Name4_StreetNumber as Party2_Name4_StreetNumber
,Party2_Name4_StreetName as Party2_Name4_StreetName
,Party2_Name4_PostDir as Party2_Name4_PostDir
,Party2_Name4_StreetType as Party2_Name4_StreetType
,Party2_Name4_SuiteType as Party2_Name4_SuiteType
,Party2_Name4_Suite as Party2_Name4_Suite
,Party2_Name4_City as Party2_Name4_City
,Party2_Name4_State as Party2_Name4_State
,Party2_Name4_Zip as Party2_Name4_Zip
,Party2_Name4_ZipPlus4 as Party2_Name4_ZipPlus4
,Party3_Name1_FullName as Party3_Name1_FullName
,Party3_Name1_last_Company_Name as Party3_Name1_last_Company_Name
,Party3_Name1_First_Name as Party3_Name1_First_Name
,Party3_Name1_Middle_Name as Party3_Name1_Middle_Name
,Party3_Name1_Suffix as Party3_Name1_Suffix
,Party3_Name1_Roll_Type as Party3_Name1_Role_Type
,Party3_Name1_taxpayer_id_ssn_fein as Party3_Name1_taxpayer_id_ssn_fein
,Party3_Name1_Account_Nbr as Party3_Name1_Account_Nbr
,Party3_Name1_SSN_Nbr as Party3_Name1_SSN_Nbr
,Party3_Name1_MailPropertyID as Party3_Name1_MailPropertyID
,Party3_Name1_Address as Party3_Name1_Address
,Party3_Name1_PreDir as Party3_Name1_PreDir
,Party3_Name1_StreetNumber as Party3_Name1_StreetNumber
,Party3_Name1_StreetName as Party3_Name1_StreetName
,Party3_Name1_PostDir as Party3_Name1_PostDir
,Party3_Name1_StreetType as Party3_Name1_StreetType
,Party3_Name1_SuiteType as Party3_Name1_SuiteType
,Party3_Name1_Suite as Party3_Name1_Suite
,Party3_Name1_City as Party3_Name1_City
,Party3_Name1_State as Party3_Name1_State
,Party3_Name1_Zip as Party3_Name1_Zip
,Party3_Name1_ZipPlus4 as Party3_Name1_ZipPlus4
,Party3_Name2_FullName as Party3_Name2_FullName
,Party3_Name2_last_Company_Name as Party3_Name2_last_Company_Name
,Party3_Name2_First_Name as Party3_Name2_First_Name
,Party3_Name2_Middle_Name as Party3_Name2_Middle_Name
,Party3_Name2_Suffix as Party3_Name2_Suffix
,Party3_Name2_Roll_Type as Party3_Name2_Role_Type
,Party3_Name2_taxpayer_id_ssn_fein as Party3_Name2_taxpayer_id_ssn_fein
,Party3_Name2_Account_Nbr as Party3_Name2_Account_Nbr
,Party3_Name2_SSN_Nbr as Party3_Name2_SSN_Nbr
,Party3_Name2_MailPropertyID as Party3_Name2_MailPropertyID
,Party3_Name2_Address as Party3_Name2_Address
,Party3_Name2_PreDir as Party3_Name2_PreDir
,Party3_Name2_StreetNumber as Party3_Name2_StreetNumber
,Party3_Name2_StreetName as Party3_Name2_StreetName
,Party3_Name2_PostDir as Party3_Name2_PostDir
,Party3_Name2_StreetType as Party3_Name2_StreetType
,Party3_Name2_SuiteType as Party3_Name2_SuiteType
,Party3_Name2_Suite as Party3_Name2_Suite
,Party3_Name2_City as Party3_Name2_City
,Party3_Name2_State as Party3_Name2_State
,Party3_Name2_Zip as Party3_Name2_Zip
,Party3_Name2_ZipPlus4 as Party3_Name2_ZipPlus4
,Party3_Name3_FullName as Party3_Name3_FullName
,Party3_Name3_last_Company_Name as Party3_Name3_last_Company_Name
,Party3_Name3_First_Name as Party3_Name3_First_Name
,Party3_Name3_Middle_Name as Party3_Name3_Middle_Name
,Party3_Name3_Suffix as Party3_Name3_Suffix
,Party3_Name3_Roll_Type as Party3_Name3_Role_Type
,Party3_Name3_taxpayer_id_ssn_fein as Party3_Name3_taxpayer_id_ssn_fein
,Party3_Name3_Account_Nbr as Party3_Name3_Account_Nbr
,Party3_Name3_SSN_Nbr as Party3_Name3_SSN_Nbr
,Party3_Name3_MailPropertyID as Party3_Name3_MailPropertyID
,Party3_Name3_Address as Party3_Name3_Address
,Party3_Name3_PreDir as Party3_Name3_PreDir
,Party3_Name3_StreetNumber as Party3_Name3_StreetNumber
,Party3_Name3_StreetName as Party3_Name3_StreetName
,Party3_Name3_PostDir as Party3_Name3_PostDir
,Party3_Name3_StreetType as Party3_Name3_StreetType
,Party3_Name3_SuiteType as Party3_Name3_SuiteType
,Party3_Name3_Suite as Party3_Name3_Suite
,Party3_Name3_City as Party3_Name3_City
,Party3_Name3_State as Party3_Name3_State
,Party3_Name3_Zip as Party3_Name3_Zip
,Party3_Name3_ZipPlus4 as Party3_Name3_ZipPlus4
,Party3_Name4_FullName as Party3_Name4_FullName
,Party3_Name4_last_Company_Name as Party3_Name4_last_Company_Name
,Party3_Name4_First_Name as Party3_Name4_First_Name
,Party3_Name4_Middle_Name as Party3_Name4_Middle_Name
,Party3_Name4_Suffix as Party3_Name4_Suffix
,Party3_Name4_Roll_Type as Party3_Name4_Role_Type
,Party3_Name4_taxpayer_id_ssn_fein as Party3_Name4_taxpayer_id_ssn_fein
,Party3_Name4_Account_Nbr as Party3_Name4_Account_Nbr
,Party3_Name4_SSN_Nbr as Party3_Name4_SSN_Nbr
,Party3_Name4_MailPropertyID as Party3_Name4_MailPropertyID
,Party3_Name4_Address as Party3_Name4_Address
,Party3_Name4_PreDir as Party3_Name4_PreDir
,Party3_Name4_StreetNumber as Party3_Name4_StreetNumber
,Party3_Name4_StreetName as Party3_Name4_StreetName
,Party3_Name4_PostDir as Party3_Name4_PostDir
,Party3_Name4_StreetType as Party3_Name4_StreetType
,Party3_Name4_SuiteType as Party3_Name4_SuiteType
,Party3_Name4_Suite as Party3_Name4_Suite
,Party3_Name4_City as Party3_Name4_City
,Party3_Name4_State as Party3_Name4_State
,Party3_Name4_Zip as Party3_Name4_Zip
,Party3_Name4_ZipPlus4 as Party3_Name4_ZipPlus4
,Party4_Name1_FullName as Party4_Name1_FullName
,Party4_Name1_last_Company_Name as Party4_Name1_last_Company_Name
,Party4_Name1_First_Name as Party4_Name1_First_Name
,Party4_Name1_Middle_Name as Party4_Name1_Middle_Name
,Party4_Name1_Suffix as Party4_Name1_Suffix
,Party4_Name1_Roll_Type as Party4_Name1_Role_Type
,Party4_Name1_taxpayer_id_ssn_fein as Party4_Name1_taxpayer_id_ssn_fein
,Party4_Name1_Account_Nbr as Party4_Name1_Account_Nbr
,Party4_Name1_SSN_Nbr as Party4_Name1_SSN_Nbr
,Party4_Name1_MailPropertyID as Party4_Name1_MailPropertyID
,Party4_Name1_Address as Party4_Name1_Address
,Party4_Name1_PreDir as Party4_Name1_PreDir
,Party4_Name1_StreetNumber as Party4_Name1_StreetNumber
,Party4_Name1_StreetName as Party4_Name1_StreetName
,Party4_Name1_PostDir as Party4_Name1_PostDir
,Party4_Name1_StreetType as Party4_Name1_StreetType
,Party4_Name1_SuiteType as Party4_Name1_SuiteType
,Party4_Name1_Suite as Party4_Name1_Suite
,Party4_Name1_City as Party4_Name1_City
,Party4_Name1_State as Party4_Name1_State
,Party4_Name1_Zip as Party4_Name1_Zip
,Party4_Name1_ZipPlus4 as Party4_Name1_ZipPlus4
,Party4_Name2_FullName as Party4_Name2_FullName
,Party4_Name2_last_Company_Name as Party4_Name2_last_Company_Name
,Party4_Name2_First_Name as Party4_Name2_First_Name
,Party4_Name2_Middle_Name as Party4_Name2_Middle_Name
,Party4_Name2_Suffix as Party4_Name2_Suffix
,Party4_Name2_Roll_Type as Party4_Name2_Role_Type
,Party4_Name2_taxpayer_id_ssn_fein as Party4_Name2_taxpayer_id_ssn_fein
,Party4_Name2_Account_Nbr as Party4_Name2_Account_Nbr
,Party4_Name2_SSN_Nbr as Party4_Name2_SSN_Nbr
,Party4_Name2_MailPropertyID as Party4_Name2_MailPropertyID
,Party4_Name2_Address as Party4_Name2_Address
,Party4_Name2_PreDir as Party4_Name2_PreDir
,Party4_Name2_StreetNumber as Party4_Name2_StreetNumber
,Party4_Name2_StreetName as Party4_Name2_StreetName
,Party4_Name2_PostDir as Party4_Name2_PostDir
,Party4_Name2_StreetType as Party4_Name2_StreetType
,Party4_Name2_SuiteType as Party4_Name2_SuiteType
,Party4_Name2_Suite as Party4_Name2_Suite
,Party4_Name2_City as Party4_Name2_City
,Party4_Name2_State as Party4_Name2_State
,Party4_Name2_Zip as Party4_Name2_Zip
,Party4_Name2_ZipPlus4 as Party4_Name2_ZipPlus4
,Party4_Name3_FullName as Party4_Name3_FullName
,Party4_Name3_last_Company_Name as Party4_Name3_last_Company_Name
,Party4_Name3_First_Name as Party4_Name3_First_Name
,Party4_Name3_Middle_Name as Party4_Name3_Middle_Name
,Party4_Name3_Suffix as Party4_Name3_Suffix
,Party4_Name3_Roll_Type as Party4_Name3_Role_Type
,Party4_Name3_taxpayer_id_ssn_fein as Party4_Name3_taxpayer_id_ssn_fein
,Party4_Name3_Account_Nbr as Party4_Name3_Account_Nbr
,Party4_Name3_SSN_Nbr as Party4_Name3_SSN_Nbr
,Party4_Name3_MailPropertyID as Party4_Name3_MailPropertyID
,Party4_Name3_Address as Party4_Name3_Address
,Party4_Name3_PreDir as Party4_Name3_PreDir
,Party4_Name3_StreetNumber as Party4_Name3_StreetNumber
,Party4_Name3_StreetName as Party4_Name3_StreetName
,Party4_Name3_PostDir as Party4_Name3_PostDir
,Party4_Name3_StreetType as Party4_Name3_StreetType
,Party4_Name3_SuiteType as Party4_Name3_SuiteType
,Party4_Name3_Suite as Party4_Name3_Suite
,Party4_Name3_City as Party4_Name3_City
,Party4_Name3_State as Party4_Name3_State
,Party4_Name3_Zip as Party4_Name3_Zip
,Party4_Name3_ZipPlus4 as Party4_Name3_ZipPlus4
,Party4_Name4_FullName as Party4_Name4_FullName
,Party4_Name4_last_Company_Name as Party4_Name4_last_Company_Name
,Party4_Name4_First_Name as Party4_Name4_First_Name
,Party4_Name4_Middle_Name as Party4_Name4_Middle_Name
,Party4_Name4_Suffix as Party4_Name4_Suffix
,Party4_Name4_Roll_Type as Party4_Name4_Role_Type
,Party4_Name4_taxpayer_id_ssn_fein as Party4_Name4_taxpayer_id_ssn_fein
,Party4_Name4_Account_Nbr as Party4_Name4_Account_Nbr
,Party4_Name4_SSN_Nbr as Party4_Name4_SSN_Nbr
,Party4_Name4_MailPropertyID as Party4_Name4_MailPropertyID
,Party4_Name4_Address as Party4_Name4_Address
,Party4_Name4_PreDir as Party4_Name4_PreDir
,Party4_Name4_StreetNumber as Party4_Name4_StreetNumber
,Party4_Name4_StreetName as Party4_Name4_StreetName
,Party4_Name4_PostDir as Party4_Name4_PostDir
,Party4_Name4_StreetType as Party4_Name4_StreetType
,Party4_Name4_SuiteType as Party4_Name4_SuiteType
,Party4_Name4_Suite as Party4_Name4_Suite
,Party4_Name4_City as Party4_Name4_City
,Party4_Name4_State as Party4_Name4_State
,Party4_Name4_Zip as Party4_Name4_Zip
,Party4_Name4_ZipPlus4 as Party4_Name4_ZipPlus4
,A.PropertyID as PropertyID
,AddressLine as AddressLine
,PreDir as PreDir
,StreetNumber as StreetNumber
,StreetName as StreetName
,PostDir as PostDir
,StreetType as StreetType
,SuiteType as SuiteType
,Suite as Suite
,City as City
,PropState as PropState
,Zip as Zip
,Plus4 as Plus4
,property_id_sequence_number as property_id_sequence_number
,legal_desc_apn_portion as legal_desc_apn_portion
,legal_desc_apn as legal_desc_apn
,legal_desc_apn_arb as legal_desc_apn_arb
,legal_desc_map_portion as legal_desc_map_portion
,legal_desc_map_unit_low as legal_desc_map_unit_low
,legal_desc_map_unit_high as legal_desc_map_unit_high
,legal_desc_map_lot_type as legal_desc_map_lot_type
,legal_desc_map_lot_type_low as legal_desc_map_lot_type_low
,legal_desc_map_lot_type_high as legal_desc_map_lot_type_high
,legal_desc_map_lot_low as legal_desc_map_lot_low
,legal_desc_map_lot_high as legal_desc_map_lot_high
,legal_desc_map_block as legal_desc_map_block
,legal_desc_map_building as legal_desc_map_building
,legal_desc_map_sublot as legal_desc_map_sublot
,legal_desc_map_plat_subcode as legal_desc_map_plat_subcode
,legal_desc_map_plat_name as legal_desc_map_plat_name
,legal_desc_map_plat_number as legal_desc_map_plat_number
,legal_desc_map_plat_condo_id as legal_desc_map_plat_condo_id
,legal_desc_map_plat_type_indicator as legal_desc_map_plat_type_indicator
,legal_desc_map_plat_book as legal_desc_map_plat_book
,legal_desc_map_plat_page as legal_desc_map_plat_page
,legal_desc_str_portion as legal_desc_str_portion
,legal_desc_str_government_lot as legal_desc_str_government_lot
,legal_desc_str_quarter as legal_desc_str_quarter
,legal_desc_str_section as legal_desc_str_section
,legal_desc_str_township as legal_desc_str_township
,legal_desc_str_range as legal_desc_str_range
,legal_desc_tct as legal_desc_tct
,legal_desc_district as legal_desc_district
,legal_desc_municipality as legal_desc_municipality
,legal_desc_swiss_code as legal_desc_swiss_code
,legal_desc_easement_flag as legal_desc_easement_flag
,legal_desc_easement_type as legal_desc_easement_type
,legal_type as legal_type
,legal_type_sequence as legal_type_sequence
,property_sequence as property_sequence
,legal_desc_qualifier as legal_desc_qualifier
,legal_desc_map_city_block as legal_desc_map_city_block
,legal_desc_application_number as legal_desc_application_number
,legal_desc_tax_assessor_portion as legal_desc_tax_assessor_portion
,legal_desc_tax_assessor_lot as legal_desc_tax_assessor_lot
,legal_desc_tax_assessor_block as legal_desc_tax_assessor_block
,legal_desc_tax_assessor_section as legal_desc_tax_assessor_section
,A.FATimestamp as FATimeStamp
,A.FAUCIDFLAG as FARecordType

----20201017 - Added per BR
,B.FormattedAPN as FAFormattedAPN

----20201023 - Added for Built Technologies
,A.[InActiveFlag]

-----Added 20211001--
,B.StdLandUseCode

------Added 20220707 for Doc Images--
,A.cmt_docnumber	
,A.cmt_id

----Added 20221011
,B.PropertyClassID
,B.OwnerStd1CorpInd

------Added 20230124
,B.DTDB_Ref_ID

----Added 20231016
,A.REFERENCE_id
,A.reference_recording_year
,A.reference_recording_date
,A.reference_doc_number
,A.reference_book
,A.reference_page
,A.Fmt_Reference_Doc_Number
,A.Fmt_Reference_BookPAge

-----Added 20250121 per BR - these field require approval
,A.date_physician_signed_death_certifate
,A.date_death_certificate_filed
,A.date_of_birth_of_deceased

,A.Party1_Name1_Date_of_Birth
,A.Party1_Name1_Driver_License_State
,A.Party1_Name1_Driver_License_Nbr

,A.Party1_Name2_Date_of_Birth
,A.Party1_Name2_Driver_License_State
,A.Party1_Name2_Driver_License_Nbr

,A.Party1_Name3_Date_of_Birth
,A.Party1_Name3_Driver_License_State
,A.Party1_Name3_Driver_License_Nbr

,A.Party1_Name4_Date_of_Birth
,A.Party1_Name4_Driver_License_State
,A.Party1_Name4_Driver_License_Nbr

,A.Party2_Name1_Date_of_Birth
,A.Party2_Name1_Driver_License_State
,A.Party2_Name1_Driver_License_Nbr

,A.Party2_Name2_Date_of_Birth
,A.Party2_Name2_Driver_License_State
,A.Party2_Name2_Driver_License_Nbr

,A.Party2_Name3_Date_of_Birth
,A.Party2_Name3_Driver_License_State
,A.Party2_Name3_Driver_License_Nbr

,A.Party2_Name4_Date_of_Birth
,A.Party2_Name4_Driver_License_State
,A.Party2_Name4_Driver_License_Nbr

,A.alt_cmt_docnumber
,A.alt_cmt_id
,A.FMT_CMT_ID
,A.FMT_CMT_ID_Book_Page


From [Data].[dbo].[InvoluntaryLien] as A with (nolock)
left outer join data.dbo.Property as B with(NOLOCK) 
on A.FIPS = B.FIPS
and A.PropertyID = B.PropertyID

Union All

Select 
 TransactionID as TransactionID
,A.Fips as Fips
,State as State
,County as County
,DocumentYear as DocumentYear
,Recordingdt as Recordingdt
,DocumentDt as DocumentDt
,doc_filing_date as doc_filing_date
,DocNbrSrce as DocNbrSrce
,BookSrce as BookSrce
,PaceSrce as PaceSrce
,Doc_Category as Doc_Category
,DocTypeID as DocTypeID
,DocType as DocType
,DocumentTitle as DocumentTitle
,case_number as case_number
,case_book as case_book
,case_page as case_page
,date_of_death as date_of_death
,account_number as account_number
,amendment_number as amendment_number
,attorney_bar_number as attorney_bar_number
,bond_number as bond_number
,lot_line_adjustment_number as lot_line_adjustment_number
,certificate_number as certificate_number
,claim_number as claim_number
,contract_number as contract_number
,corporation_number as corporation_number
,excise_tax_number as excise_tax_number
,federal_tax_lien_area as federal_tax_lien_area
,federal_tax_lien_area_phone as federal_tax_lien_area_phone
,tax_last_day_for_refiling as tax_last_day_for_refiling
,tax_period_begin_date as tax_period_begin_date
,tax_period_end_date as tax_period_end_date
,tax_amount as tax_amount
,tax_interest_amount as tax_interest_amount
,tax_penalty_amount as tax_penalty_amount
,judgment_amount as judgment_amount
,judgment_grand_total as judgment_grand_total
,judgment_court_fees as judgment_court_fees
,judgment_attorney_fees as judgment_attorney_fees
,judgment_principal_fees as judgment_principal_fees
,judgment_interest_fees as judgment_interest_fees
,judgment_filing_fees as judgment_filing_fees
,judgment_per_diem_fees as judgment_per_diem_fees
,judgment_late_fees as judgment_late_fees
,judgment_tax_fees as judgment_tax_fees
,judgment_insurance_fees as judgment_insurance_fees
,judgment_other_fees as judgment_other_fees
,installment_judgment as installment_judgment
,license_number as license_number
,lien_number as lien_number
,map_plat_id as map_plat_id
,mechanics_lien_number as mechanics_lien_number
,ordinance_number as ordinance_number
,patent_number as patent_number
,permit_number as permit_number
,resolution_number as resolution_number
,tax_account_serial_warrant_number as tax_account_serial_warrant_number
,tax_type as tax_type
,trustees_sale_number as trustees_sale_number
,ucc_number as ucc_number
,undersigned_same_as_borrower as undersigned_same_as_borrower
,amount_due as amount_due
,amount_of_default as amount_of_default
,bond_amount as bond_amount
,cash_down_amount as cash_down_amount
,contract_amount as contract_amount
,collection_costs as collection_costs
,unpaid_balance as unpaid_balance
,unpaid_balance_as_of_modification_date as unpaid_balance_as_of_modification_date
,unpaid_prinicipal_amount_due as unpaid_prinicipal_amount
,date_of_divorce as date_of_divorce
,support_arrears_amount as support_arrears_amount
,support_payment_amount as support_payment_amount
,support_total_amount as support_total_amount
,date_amount_due as date_amount_due
,date_stay_ordered as date_stay_ordered
,bankruptcy_case_number as bankruptcy_case_number
,bankruptcy_chapter as bankruptcy_chapter
,bankruptcy_type as bankruptcy_type
,bankruptcy_location as bankruptcy_location
,case_filed_in_county as case_filed_in_county
,case_court_type as case_court_type
,case_original_number as case_original_number
,case_original_court_type as case_original_court_type
,case_status as case_status
,date_bankruptcy_closed as date_bankruptcy_closed
,date_bankruptcy_case_filed as date_bankruptcy_case_filed
,date_bankruptcy_conversion as date_bankruptcy_conversion
,date_bankruptcy_discharged as date_bankruptcy_discharged
,date_bankruptcy_dismissed as date_bankruptcy_dismissed
,date_bankruptcy_341_meeting as date_bankruptcy_341_meeting
,bankruptcy_341_meeting_time as bankruptcy_341_meeting_time
,requested_prepared_by_attorney_name_identifier as requested_prepared_by_attorney_name_identifier
,requested_prepared_by_attorney_last_company_name as requested_prepared_by_attorney_last_company_name
,requested_prepared_by_attorney_first_name as requested_prepared_by_attorney_first_name
,requested_prepared_by_attorney_middle_initial as requested_prepared_by_attorney_middle_initial
,requested_prepared_by_attorney_suffix as requested_prepared_by_attorney_suffix
,requested_prepared_by_attorney_address as requested_prepared_by_attorney_address
,requested_prepared_by_attorney_address_city as requested_prepared_by_attorney_address_city
,requested_prepared_by_attorney_address_state as requested_prepared_by_attorney_address_state
,requested_prepared_by_attorney_address_zip as requested_prepared_by_attorney_address_zip
,requested_prepared_by_attorney_phone as requested_prepared_by_attorney_phone
,Party1_Name1_FullName as Party1_Name1_FullName
,Party1_Name1_last_Company_Name as Party1_Name1_last_Company_Name
,Party1_Name1_First_Name as Party1_Name1_First_Name
,Party1_Name1_Middle_Name as Party1_Name1_Middle_Name
,Party1_Name1_Suffix as Party1_Name1_Suffix
,Party1_Name1_Roll_Type as Party1_Name1_Role_Type
,Party1_Name1_taxpayer_id_ssn_fein as Party1_Name1_taxpayer_id_ssn_fein
,Party1_Name1_Account_Nbr as Party1_Name1_Account_Nbr
,Party1_Name1_SSN_Nbr as Party1_Name1_SSN_Nbr
,Party1_Name1_MailPropertyID as Party1_Name1_MailPropertyID
,Party1_Name1_Address as Party1_Name1_Address
,Party1_Name1_PreDir as Party1_Name1_PreDir
,Party1_Name1_StreetNumber as Party1_Name1_StreetNumber
,Party1_Name1_StreetName as Party1_Name1_StreetName
,Party1_Name1_PostDir as Party1_Name1_PostDir
,Party1_Name1_StreetType as Party1_Name1_StreetType
,Party1_Name1_SuiteType as Party1_Name1_SuiteType
,Party1_Name1_Suite as Party1_Name1_Suite
,Party1_Name1_City as Party1_Name1_City
,Party1_Name1_State as Party1_Name1_State
,Party1_Name1_Zip as Party1_Name1_Zip
,Party1_Name1_ZipPlus4 as Party1_Name1_ZipPlus4
,Party1_Name2_FullName as Party1_Name2_FullName
,Party1_Name2_last_Company_Name as Party1_Name2_last_Company_Name
,Party1_Name2_First_Name as Party1_Name2_First_Name
,Party1_Name2_Middle_Name as Party1_Name2_Middle_Name
,Party1_Name2_Suffix as Party1_Name2_Suffix
,Party1_Name2_Roll_Type as Party1_Name2_Role_Type
,Party1_Name2_taxpayer_id_ssn_fein as Party1_Name2_taxpayer_id_ssn_fein
,Party1_Name2_Account_Nbr as Party1_Name2_Account_Nbr
,Party1_Name2_SSN_Nbr as Party1_Name2_SSN_Nbr
,Party1_Name2_MailPropertyID as Party1_Name2_MailPropertyID
,Party1_Name2_Address as Party1_Name2_Address
,Party1_Name2_PreDir as Party1_Name2_PreDir
,Party1_Name2_StreetNumber as Party1_Name2_StreetNumber
,Party1_Name2_StreetName as Party1_Name2_StreetName
,Party1_Name2_PostDir as Party1_Name2_PostDir
,Party1_Name2_StreetType as Party1_Name2_StreetType
,Party1_Name2_SuiteType as Party1_Name2_SuiteType
,Party1_Name2_Suite as Party1_Name2_Suite
,Party1_Name2_City as Party1_Name2_City
,Party1_Name2_State as Party1_Name2_State
,Party1_Name2_Zip as Party1_Name2_Zip
,Party1_Name2_ZipPlus4 as Party1_Name2_ZipPlus4
,Party1_Name3_FullName as Party1_Name3_FullName
,Party1_Name3_last_Company_Name as Party1_Name3_last_Company_Name
,Party1_Name3_First_Name as Party1_Name3_First_Name
,Party1_Name3_Middle_Name as Party1_Name3_Middle_Name
,Party1_Name3_Suffix as Party1_Name3_Suffix
,Party1_Name3_Roll_Type as Party1_Name3_Role_Type
,Party1_Name3_taxpayer_id_ssn_fein as Party1_Name3_taxpayer_id_ssn_fein
,null as Party1_Name3_Account_Nbr
,Party1_Name3_SSN_Nbr as Party1_Name3_SSN_Nbr
,Party1_Name3_MailPropertyID as Party1_Name3_MailPropertyID
,Party1_Name3_Address as Party1_Name3_Address
,Party1_Name3_PreDir as Party1_Name3_PreDir
,Party1_Name3_StreetNumber as Party1_Name3_StreetNumber
,Party1_Name3_StreetName as Party1_Name3_StreetName
,Party1_Name3_PostDir as Party1_Name3_PostDir
,Party1_Name3_StreetType as Party1_Name3_StreetType
,Party1_Name3_SuiteType as Party1_Name3_SuiteType
,Party1_Name3_Suite as Party1_Name3_Suite
,Party1_Name3_City as Party1_Name3_City
,Party1_Name3_State as Party1_Name3_State
,Party1_Name3_Zip as Party1_Name3_Zip
,Party1_Name3_ZipPlus4 as Party1_Name3_ZipPlus4
,Party1_Name4_FullName as Party1_Name4_FullName
,Party1_Name4_last_Company_Name as Party1_Name4_last_Company_Name
,Party1_Name4_First_Name as Party1_Name4_First_Name
,Party1_Name4_Middle_Name as Party1_Name4_Middle_Name
,Party1_Name4_Suffix as Party1_Name4_Suffix
,Party1_Name4_Roll_Type as Party1_Name4_Role_Type
,Party1_Name4_taxpayer_id_ssn_fein as Party1_Name4_taxpayer_id_ssn_fein
,Party1_Name4_Account_Nbr as Party1_Name4_Account_Nbr
,Party1_Name4_SSN_Nbr as Party1_Name4_SSN_Nbr
,Party1_Name4_MailPropertyID as Party1_Name4_MailPropertyID
,Party1_Name4_Address as Party1_Name4_Address
,Party1_Name4_PreDir as Party1_Name4_PreDir
,Party1_Name4_StreetNumber as Party1_Name4_StreetNumber
,Party1_Name4_StreetName as Party1_Name4_StreetName
,Party1_Name4_PostDir as Party1_Name4_PostDir
,Party1_Name4_StreetType as Party1_Name4_StreetType
,Party1_Name4_SuiteType as Party1_Name4_SuiteType
,Party1_Name4_Suite as Party1_Name4_Suite
,Party1_Name4_City as Party1_Name4_City
,Party1_Name4_State as Party1_Name4_State
,Party1_Name4_Zip as Party1_Name4_Zip
,Party1_Name4_ZipPlus4 as Party1_Name4_ZipPlus4
,Party2_Name1_FullName as Party2_Name1_FullName
,Party2_Name1_last_Company_Name as Party2_Name1_last_Company_Name
,Party2_Name1_First_Name as Party2_Name1_First_Name
,Party2_Name1_Middle_Name as Party2_Name1_Middle_Name
,Party2_Name1_Suffix as Party2_Name1_Suffix
,Party2_Name1_Roll_Type as Party2_Name1_Role_Type
,Party2_Name1_taxpayer_id_ssn_fein as Party2_Name1_taxpayer_id_ssn_fein
,Party2_Name1_Account_Nbr as Party2_Name1_Account_Nbr
,Party2_Name1_SSN_Nbr as Party2_Name1_SSN_Nbr
,Party2_Name1_MailPropertyID as Party2_Name1_MailPropertyID
,Party2_Name1_Address as Party2_Name1_Address
,Party2_Name1_PreDir as Party2_Name1_PreDir
,Party2_Name1_StreetNumber as Party2_Name1_StreetNumber
,Party2_Name1_StreetName as Party2_Name1_StreetName
,Party2_Name1_PostDir as Party2_Name1_PostDir
,Party2_Name1_StreetType as Party2_Name1_StreetType
,Party2_Name1_SuiteType as Party2_Name1_SuiteType
,Party2_Name1_Suite as Party2_Name1_Suite
,Party2_Name1_City as Party2_Name1_City
,Party2_Name1_State as Party2_Name1_State
,Party2_Name1_Zip as Party2_Name1_Zip
,Party2_Name1_ZipPlus4 as Party2_Name1_ZipPlus4
,Party2_Name2_FullName as Party2_Name2_FullName
,Party2_Name2_last_Company_Name as Party2_Name2_last_Company_Name
,Party2_Name2_First_Name as Party2_Name2_First_Name
,Party2_Name2_Middle_Name as Party2_Name2_Middle_Name
,Party2_Name2_Suffix as Party2_Name2_Suffix
,Party2_Name2_Roll_Type as Party2_Name2_Role_Type
,Party2_Name2_taxpayer_id_ssn_fein as Party2_Name2_taxpayer_id_ssn_fein
,Party2_Name2_Account_Nbr as Party2_Name2_Account_Nbr
,Party2_Name2_SSN_Nbr as Party2_Name2_SSN_Nbr
,Party2_Name2_MailPropertyID as Party2_Name2_MailPropertyID
,Party2_Name2_Address as Party2_Name2_Address
,Party2_Name2_PreDir as Party2_Name2_PreDir
,Party2_Name2_StreetNumber as Party2_Name2_StreetNumber
,Party2_Name2_StreetName as Party2_Name2_StreetName
,Party2_Name2_PostDir as Party2_Name2_PostDir
,Party2_Name2_StreetType as Party2_Name2_StreetType
,Party2_Name2_SuiteType as Party2_Name2_SuiteType
,Party2_Name2_Suite as Party2_Name2_Suite
,Party2_Name2_City as Party2_Name2_City
,Party2_Name2_State as Party2_Name2_State
,Party2_Name2_Zip as Party2_Name2_Zip
,Party2_Name2_ZipPlus4 as Party2_Name2_ZipPlus4
,Party2_Name3_FullName as Party2_Name3_FullName
,Party2_Name3_last_Company_Name as Party2_Name3_last_Company_Name
,Party2_Name3_First_Name as Party2_Name3_First_Name
,Party2_Name3_Middle_Name as Party2_Name3_Middle_Name
,Party2_Name3_Suffix as Party2_Name3_Suffix
,Party2_Name3_Roll_Type as Party2_Name3_Role_Type
,Party2_Name3_taxpayer_id_ssn_fein as Party2_Name3_taxpayer_id_ssn_fein
,Party2_Name3_Account_Nbr as Party2_Name3_Account_Nbr
,Party2_Name3_SSN_Nbr as Party2_Name3_SSN_Nbr
,Party2_Name3_MailPropertyID as Party2_Name3_MailPropertyID
,Party2_Name3_Address as Party2_Name3_Address
,Party2_Name3_PreDir as Party2_Name3_PreDir
,Party2_Name3_StreetNumber as Party2_Name3_StreetNumber
,Party2_Name3_StreetName as Party2_Name3_StreetName
,Party2_Name3_PostDir as Party2_Name3_PostDir
,Party2_Name3_StreetType as Party2_Name3_StreetType
,Party2_Name3_SuiteType as Party2_Name3_SuiteType
,Party2_Name3_Suite as Party2_Name3_Suite
,Party2_Name3_City as Party2_Name3_City
,Party2_Name3_State as Party2_Name3_State
,Party2_Name3_Zip as Party2_Name3_Zip
,Party2_Name3_ZipPlus4 as Party2_Name3_ZipPlus4
,Party2_Name4_FullName as Party2_Name4_FullName
,Party2_Name4_last_Company_Name as Party2_Name4_last_Company_Name
,Party2_Name4_First_Name as Party2_Name4_First_Name
,Party2_Name4_Middle_Name as Party2_Name4_Middle_Name
,Party2_Name4_Suffix as Party2_Name4_Suffix
,Party2_Name4_Roll_Type as Party2_Name4_Role_Type
,Party2_Name4_taxpayer_id_ssn_fein as Party2_Name4_taxpayer_id_ssn_fein
,Party2_Name4_Account_Nbr as Party2_Name4_Account_Nbr
,Party2_Name4_SSN_Nbr as Party2_Name4_SSN_Nbr
,Party2_Name4_MailPropertyID as Party2_Name4_MailPropertyID
,Party2_Name4_Address as Party2_Name4_Address
,Party2_Name4_PreDir as Party2_Name4_PreDir
,Party2_Name4_StreetNumber as Party2_Name4_StreetNumber
,Party2_Name4_StreetName as Party2_Name4_StreetName
,Party2_Name4_PostDir as Party2_Name4_PostDir
,Party2_Name4_StreetType as Party2_Name4_StreetType
,Party2_Name4_SuiteType as Party2_Name4_SuiteType
,Party2_Name4_Suite as Party2_Name4_Suite
,Party2_Name4_City as Party2_Name4_City
,Party2_Name4_State as Party2_Name4_State
,Party2_Name4_Zip as Party2_Name4_Zip
,Party2_Name4_ZipPlus4 as Party2_Name4_ZipPlus4
,Party3_Name1_FullName as Party3_Name1_FullName
,Party3_Name1_last_Company_Name as Party3_Name1_last_Company_Name
,Party3_Name1_First_Name as Party3_Name1_First_Name
,Party3_Name1_Middle_Name as Party3_Name1_Middle_Name
,Party3_Name1_Suffix as Party3_Name1_Suffix
,Party3_Name1_Roll_Type as Party3_Name1_Role_Type
,Party3_Name1_taxpayer_id_ssn_fein as Party3_Name1_taxpayer_id_ssn_fein
,Party3_Name1_Account_Nbr as Party3_Name1_Account_Nbr
,Party3_Name1_SSN_Nbr as Party3_Name1_SSN_Nbr
,Party3_Name1_MailPropertyID as Party3_Name1_MailPropertyID
,Party3_Name1_Address as Party3_Name1_Address
,Party3_Name1_PreDir as Party3_Name1_PreDir
,Party3_Name1_StreetNumber as Party3_Name1_StreetNumber
,Party3_Name1_StreetName as Party3_Name1_StreetName
,Party3_Name1_PostDir as Party3_Name1_PostDir
,Party3_Name1_StreetType as Party3_Name1_StreetType
,Party3_Name1_SuiteType as Party3_Name1_SuiteType
,Party3_Name1_Suite as Party3_Name1_Suite
,Party3_Name1_City as Party3_Name1_City
,Party3_Name1_State as Party3_Name1_State
,Party3_Name1_Zip as Party3_Name1_Zip
,Party3_Name1_ZipPlus4 as Party3_Name1_ZipPlus4
,Party3_Name2_FullName as Party3_Name2_FullName
,Party3_Name2_last_Company_Name as Party3_Name2_last_Company_Name
,Party3_Name2_First_Name as Party3_Name2_First_Name
,Party3_Name2_Middle_Name as Party3_Name2_Middle_Name
,Party3_Name2_Suffix as Party3_Name2_Suffix
,Party3_Name2_Roll_Type as Party3_Name2_Role_Type
,Party3_Name2_taxpayer_id_ssn_fein as Party3_Name2_taxpayer_id_ssn_fein
,Party3_Name2_Account_Nbr as Party3_Name2_Account_Nbr
,Party3_Name2_SSN_Nbr as Party3_Name2_SSN_Nbr
,Party3_Name2_MailPropertyID as Party3_Name2_MailPropertyID
,Party3_Name2_Address as Party3_Name2_Address
,Party3_Name2_PreDir as Party3_Name2_PreDir
,Party3_Name2_StreetNumber as Party3_Name2_StreetNumber
,Party3_Name2_StreetName as Party3_Name2_StreetName
,Party3_Name2_PostDir as Party3_Name2_PostDir
,Party3_Name2_StreetType as Party3_Name2_StreetType
,Party3_Name2_SuiteType as Party3_Name2_SuiteType
,Party3_Name2_Suite as Party3_Name2_Suite
,Party3_Name2_City as Party3_Name2_City
,Party3_Name2_State as Party3_Name2_State
,Party3_Name2_Zip as Party3_Name2_Zip
,Party3_Name2_ZipPlus4 as Party3_Name2_ZipPlus4
,Party3_Name3_FullName as Party3_Name3_FullName
,Party3_Name3_last_Company_Name as Party3_Name3_last_Company_Name
,Party3_Name3_First_Name as Party3_Name3_First_Name
,Party3_Name3_Middle_Name as Party3_Name3_Middle_Name
,Party3_Name3_Suffix as Party3_Name3_Suffix
,Party3_Name3_Roll_Type as Party3_Name3_Role_Type
,Party3_Name3_taxpayer_id_ssn_fein as Party3_Name3_taxpayer_id_ssn_fein
,Party3_Name3_Account_Nbr as Party3_Name3_Account_Nbr
,Party3_Name3_SSN_Nbr as Party3_Name3_SSN_Nbr
,Party3_Name3_MailPropertyID as Party3_Name3_MailPropertyID
,Party3_Name3_Address as Party3_Name3_Address
,Party3_Name3_PreDir as Party3_Name3_PreDir
,Party3_Name3_StreetNumber as Party3_Name3_StreetNumber
,Party3_Name3_StreetName as Party3_Name3_StreetName
,Party3_Name3_PostDir as Party3_Name3_PostDir
,Party3_Name3_StreetType as Party3_Name3_StreetType
,Party3_Name3_SuiteType as Party3_Name3_SuiteType
,Party3_Name3_Suite as Party3_Name3_Suite
,Party3_Name3_City as Party3_Name3_City
,Party3_Name3_State as Party3_Name3_State
,Party3_Name3_Zip as Party3_Name3_Zip
,Party3_Name3_ZipPlus4 as Party3_Name3_ZipPlus4
,Party3_Name4_FullName as Party3_Name4_FullName
,Party3_Name4_last_Company_Name as Party3_Name4_last_Company_Name
,Party3_Name4_First_Name as Party3_Name4_First_Name
,Party3_Name4_Middle_Name as Party3_Name4_Middle_Name
,Party3_Name4_Suffix as Party3_Name4_Suffix
,Party3_Name4_Roll_Type as Party3_Name4_Role_Type
,Party3_Name4_taxpayer_id_ssn_fein as Party3_Name4_taxpayer_id_ssn_fein
,Party3_Name4_Account_Nbr as Party3_Name4_Account_Nbr
,Party3_Name4_SSN_Nbr as Party3_Name4_SSN_Nbr
,Party3_Name4_MailPropertyID as Party3_Name4_MailPropertyID
,Party3_Name4_Address as Party3_Name4_Address
,Party3_Name4_PreDir as Party3_Name4_PreDir
,Party3_Name4_StreetNumber as Party3_Name4_StreetNumber
,Party3_Name4_StreetName as Party3_Name4_StreetName
,Party3_Name4_PostDir as Party3_Name4_PostDir
,Party3_Name4_StreetType as Party3_Name4_StreetType
,Party3_Name4_SuiteType as Party3_Name4_SuiteType
,Party3_Name4_Suite as Party3_Name4_Suite
,Party3_Name4_City as Party3_Name4_City
,Party3_Name4_State as Party3_Name4_State
,Party3_Name4_Zip as Party3_Name4_Zip
,Party3_Name4_ZipPlus4 as Party3_Name4_ZipPlus4
,Party4_Name1_FullName as Party4_Name1_FullName
,Party4_Name1_last_Company_Name as Party4_Name1_last_Company_Name
,Party4_Name1_First_Name as Party4_Name1_First_Name
,Party4_Name1_Middle_Name as Party4_Name1_Middle_Name
,Party4_Name1_Suffix as Party4_Name1_Suffix
,Party4_Name1_Roll_Type as Party4_Name1_Role_Type
,Party4_Name1_taxpayer_id_ssn_fein as Party4_Name1_taxpayer_id_ssn_fein
,Party4_Name1_Account_Nbr as Party4_Name1_Account_Nbr
,Party4_Name1_SSN_Nbr as Party4_Name1_SSN_Nbr
,Party4_Name1_MailPropertyID as Party4_Name1_MailPropertyID
,Party4_Name1_Address as Party4_Name1_Address
,Party4_Name1_PreDir as Party4_Name1_PreDir
,Party4_Name1_StreetNumber as Party4_Name1_StreetNumber
,Party4_Name1_StreetName as Party4_Name1_StreetName
,Party4_Name1_PostDir as Party4_Name1_PostDir
,Party4_Name1_StreetType as Party4_Name1_StreetType
,Party4_Name1_SuiteType as Party4_Name1_SuiteType
,Party4_Name1_Suite as Party4_Name1_Suite
,Party4_Name1_City as Party4_Name1_City
,Party4_Name1_State as Party4_Name1_State
,Party4_Name1_Zip as Party4_Name1_Zip
,Party4_Name1_ZipPlus4 as Party4_Name1_ZipPlus4
,Party4_Name2_FullName as Party4_Name2_FullName
,Party4_Name2_last_Company_Name as Party4_Name2_last_Company_Name
,Party4_Name2_First_Name as Party4_Name2_First_Name
,Party4_Name2_Middle_Name as Party4_Name2_Middle_Name
,Party4_Name2_Suffix as Party4_Name2_Suffix
,Party4_Name2_Roll_Type as Party4_Name2_Role_Type
,Party4_Name2_taxpayer_id_ssn_fein as Party4_Name2_taxpayer_id_ssn_fein
,Party4_Name2_Account_Nbr as Party4_Name2_Account_Nbr
,Party4_Name2_SSN_Nbr as Party4_Name2_SSN_Nbr
,Party4_Name2_MailPropertyID as Party4_Name2_MailPropertyID
,Party4_Name2_Address as Party4_Name2_Address
,Party4_Name2_PreDir as Party4_Name2_PreDir
,Party4_Name2_StreetNumber as Party4_Name2_StreetNumber
,Party4_Name2_StreetName as Party4_Name2_StreetName
,Party4_Name2_PostDir as Party4_Name2_PostDir
,Party4_Name2_StreetType as Party4_Name2_StreetType
,Party4_Name2_SuiteType as Party4_Name2_SuiteType
,Party4_Name2_Suite as Party4_Name2_Suite
,Party4_Name2_City as Party4_Name2_City
,Party4_Name2_State as Party4_Name2_State
,Party4_Name2_Zip as Party4_Name2_Zip
,Party4_Name2_ZipPlus4 as Party4_Name2_ZipPlus4
,Party4_Name3_FullName as Party4_Name3_FullName
,Party4_Name3_last_Company_Name as Party4_Name3_last_Company_Name
,Party4_Name3_First_Name as Party4_Name3_First_Name
,Party4_Name3_Middle_Name as Party4_Name3_Middle_Name
,Party4_Name3_Suffix as Party4_Name3_Suffix
,Party4_Name3_Roll_Type as Party4_Name3_Role_Type
,Party4_Name3_taxpayer_id_ssn_fein as Party4_Name3_taxpayer_id_ssn_fein
,Party4_Name3_Account_Nbr as Party4_Name3_Account_Nbr
,Party4_Name3_SSN_Nbr as Party4_Name3_SSN_Nbr
,Party4_Name3_MailPropertyID as Party4_Name3_MailPropertyID
,Party4_Name3_Address as Party4_Name3_Address
,Party4_Name3_PreDir as Party4_Name3_PreDir
,Party4_Name3_StreetNumber as Party4_Name3_StreetNumber
,Party4_Name3_StreetName as Party4_Name3_StreetName
,Party4_Name3_PostDir as Party4_Name3_PostDir
,Party4_Name3_StreetType as Party4_Name3_StreetType
,Party4_Name3_SuiteType as Party4_Name3_SuiteType
,Party4_Name3_Suite as Party4_Name3_Suite
,Party4_Name3_City as Party4_Name3_City
,Party4_Name3_State as Party4_Name3_State
,Party4_Name3_Zip as Party4_Name3_Zip
,Party4_Name3_ZipPlus4 as Party4_Name3_ZipPlus4
,Party4_Name4_FullName as Party4_Name4_FullName
,Party4_Name4_last_Company_Name as Party4_Name4_last_Company_Name
,Party4_Name4_First_Name as Party4_Name4_First_Name
,Party4_Name4_Middle_Name as Party4_Name4_Middle_Name
,Party4_Name4_Suffix as Party4_Name4_Suffix
,Party4_Name4_Roll_Type as Party4_Name4_Role_Type
,Party4_Name4_taxpayer_id_ssn_fein as Party4_Name4_taxpayer_id_ssn_fein
,Party4_Name4_Account_Nbr as Party4_Name4_Account_Nbr
,Party4_Name4_SSN_Nbr as Party4_Name4_SSN_Nbr
,Party4_Name4_MailPropertyID as Party4_Name4_MailPropertyID
,Party4_Name4_Address as Party4_Name4_Address
,Party4_Name4_PreDir as Party4_Name4_PreDir
,Party4_Name4_StreetNumber as Party4_Name4_StreetNumber
,Party4_Name4_StreetName as Party4_Name4_StreetName
,Party4_Name4_PostDir as Party4_Name4_PostDir
,Party4_Name4_StreetType as Party4_Name4_StreetType
,Party4_Name4_SuiteType as Party4_Name4_SuiteType
,Party4_Name4_Suite as Party4_Name4_Suite
,Party4_Name4_City as Party4_Name4_City
,Party4_Name4_State as Party4_Name4_State
,Party4_Name4_Zip as Party4_Name4_Zip
,Party4_Name4_ZipPlus4 as Party4_Name4_ZipPlus4
,A.PropertyID as PropertyID
,AddressLine as AddressLine
,PreDir as PreDir
,StreetNumber as StreetNumber
,StreetName as StreetName
,PostDir as PostDir
,StreetType as StreetType
,SuiteType as SuiteType
,Suite as Suite
,City as City
,PropState as PropState
,Zip as Zip
,Plus4 as Plus4
,property_id_sequence_number as property_id_sequence_number
,legal_desc_apn_portion as legal_desc_apn_portion
,legal_desc_apn as legal_desc_apn
,legal_desc_apn_arb as legal_desc_apn_arb
,legal_desc_map_portion as legal_desc_map_portion
,legal_desc_map_unit_low as legal_desc_map_unit_low
,legal_desc_map_unit_high as legal_desc_map_unit_high
,legal_desc_map_lot_type as legal_desc_map_lot_type
,legal_desc_map_lot_type_low as legal_desc_map_lot_type_low
,legal_desc_map_lot_type_high as legal_desc_map_lot_type_high
,legal_desc_map_lot_low as legal_desc_map_lot_low
,legal_desc_map_lot_high as legal_desc_map_lot_high
,legal_desc_map_block as legal_desc_map_block
,legal_desc_map_building as legal_desc_map_building
,legal_desc_map_sublot as legal_desc_map_sublot
,legal_desc_map_plat_subcode as legal_desc_map_plat_subcode
,legal_desc_map_plat_name as legal_desc_map_plat_name
,legal_desc_map_plat_number as legal_desc_map_plat_number
,legal_desc_map_plat_condo_id as legal_desc_map_plat_condo_id
,legal_desc_map_plat_type_indicator as legal_desc_map_plat_type_indicator
,legal_desc_map_plat_book as legal_desc_map_plat_book
,legal_desc_map_plat_page as legal_desc_map_plat_page
,legal_desc_str_portion as legal_desc_str_portion
,legal_desc_str_government_lot as legal_desc_str_government_lot
,legal_desc_str_quarter as legal_desc_str_quarter
,legal_desc_str_section as legal_desc_str_section
,legal_desc_str_township as legal_desc_str_township
,legal_desc_str_range as legal_desc_str_range
,legal_desc_tct as legal_desc_tct
,legal_desc_district as legal_desc_district
,legal_desc_municipality as legal_desc_municipality
,legal_desc_swiss_code as legal_desc_swiss_code
,legal_desc_easement_flag as legal_desc_easement_flag
,legal_desc_easement_type as legal_desc_easement_type
,legal_type as legal_type
,legal_type_sequence as legal_type_sequence
,property_sequence as property_sequence
,legal_desc_qualifier as legal_desc_qualifier
,legal_desc_map_city_block as legal_desc_map_city_block
,legal_desc_application_number as legal_desc_application_number
,legal_desc_tax_assessor_portion as legal_desc_tax_assessor_portion
,legal_desc_tax_assessor_lot as legal_desc_tax_assessor_lot
,legal_desc_tax_assessor_block as legal_desc_tax_assessor_block
,legal_desc_tax_assessor_section as legal_desc_tax_assessor_section
,A.FATimestamp as FATimeStamp
,A.FAUCIDFLAG as FARecordType

----20201017 - Added per BR
,B.FormattedAPN as FAFormattedAPN

----20201023 - Added for Built Technologies
,A.[InActiveFlag]

-----Added 20211001--
,B.StdLandUseCode

------Added 20220707 for Doc Images--
,A.cmt_docnumber	
,A.cmt_id

----Added 20221011
,B.PropertyClassID
,B.OwnerStd1CorpInd

------Added 20230124
,B.DTDB_Ref_ID

----Added 20231016
,A.REFERENCE_id
,A.reference_recording_year
,A.reference_recording_date
,A.reference_doc_number
,A.reference_book
,A.reference_page
,A.Fmt_Reference_Doc_Number
,A.Fmt_Reference_BookPAge

-----Added 20250121 per BR - these field require approval
,A.date_physician_signed_death_certifate
,A.date_death_certificate_filed
,A.date_of_birth_of_deceased

,A.Party1_Name1_Date_of_Birth
,A.Party1_Name1_Driver_License_State
,A.Party1_Name1_Driver_License_Nbr

,A.Party1_Name2_Date_of_Birth
,A.Party1_Name2_Driver_License_State
,A.Party1_Name2_Driver_License_Nbr

,A.Party1_Name3_Date_of_Birth
,A.Party1_Name3_Driver_License_State
,A.Party1_Name3_Driver_License_Nbr

,A.Party1_Name4_Date_of_Birth
,A.Party1_Name4_Driver_License_State
,A.Party1_Name4_Driver_License_Nbr

,A.Party2_Name1_Date_of_Birth
,A.Party2_Name1_Driver_License_State
,A.Party2_Name1_Driver_License_Nbr

,A.Party2_Name2_Date_of_Birth
,A.Party2_Name2_Driver_License_State
,A.Party2_Name2_Driver_License_Nbr

,A.Party2_Name3_Date_of_Birth
,A.Party2_Name3_Driver_License_State
,A.Party2_Name3_Driver_License_Nbr

,A.Party2_Name4_Date_of_Birth
,A.Party2_Name4_Driver_License_State
,A.Party2_Name4_Driver_License_Nbr

,A.alt_cmt_docnumber
,A.alt_cmt_id
,A.FMT_CMT_ID
,A.FMT_CMT_ID_Book_Page


From [Data].[dbo].[InvoluntaryLien_Extra] as A with (nolock)
left outer join data.dbo.Property as B with(NOLOCK) 
on A.FIPS = B.FIPS
and A.PropertyID = B.PropertyID




GRANT SELECT ON [dbo].[v_INVL_Extra_BRWork] TO [CORP\cbrady] AS [dbo]
