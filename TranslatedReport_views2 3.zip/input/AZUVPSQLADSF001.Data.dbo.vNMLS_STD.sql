SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Data].[dbo].[vNMLS_STD]
AS
	SELECT a.[FipsCode] as [FIPS]
		, c.[County Name] as [CountyName]
		, b.[PropertyID]
		, b.[FormattedAPN] as [ParcelNumber]
		, b.[SitusStdFullStreetAddress] as [Address]
		, b.[SitusStdCity] as [City]
		, c.[State] as [State]
		, b.[SitusStdZIP5] as [Zipcode]
		, a.[TransactionID] AS [FATransactionID]
		, convert(varchar(8),a.[RECORDING_DATE],112) as [RecordingDate]
		, a.[documentnumber] AS [MtgDocNbr]
		, a.[FMT_MTG_BKPG] AS [MtgBookPage]
		, [NMLSAgentID]
		, [NMLSAgentName]
		, [NMLSLenderID]
		, [NMLSLenderName]
		, [NMLSBrokerID]
		, [NMLSBrokerName]
		, a.[FATimeStamp]
		, a.[FAUCIDFlag] as [RecordType]

		-----Added 20230526---
		,B.PropertyClassID

		----Added 20231009---
		,B.StdLandUseCode

		----Added 20261030 for research---
		,a.DeedID
		,a.REF_ID
	FROM Marketshare.[dbo].[NMLS_Data] a with(NOLOCK) LEFT OUTER JOIN  DATA.dbo.Property b with(NOLOCK)
	ON a.PropertyID = b.PropertyID
	JOIN Global.dbo.County c on a.fips = c.FIPSCode
	WHERE TransactionID is not null



