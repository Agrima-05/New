SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
create view [Data].[dbo].[zipxrefproperty] as
select p.FIPS,p.PropertyID,p.FormattedAPN,m.Ref_id,m.zip,m.parelgeom from OPENQUERY(AZUVPSQLDTDB034, 'select * from [NG911].[dbo].[Zip_intersection_result]') m inner join dbo.property p
on p.UnformattedAPN = m.Apn where p.FIPS = '06037'
