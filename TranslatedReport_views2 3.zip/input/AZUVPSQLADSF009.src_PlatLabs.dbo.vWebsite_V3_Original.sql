SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [src_PlatLabs].[dbo].[vWebsite_V3_Original]
AS

	SELECT cast(l.mls_id as varchar) + '-' + l.mls_listing_id as [id]
		,appliances as [appliances]
		,style as [architectural_style]
		,hoa_fee as [association_fee]
		,hoa_frequency as [association_fee_frequency]
		,NULL as [association_type]
		,Case when (parking_description like '%Attached Garage%' or parking_description like '%Garage attached%') Then 'Y' Else 'N' End as [attached_garage_yn]
		,Case when has_basement = 'true' Then 'Y' Else 'N' End as [basement_yn]
		,bathrooms_full as [bathrooms_full]
		,bathrooms_half as [bathrooms_half]
		,bathrooms as [bathrooms_total_integer]
		,l.bedrooms as [bedrooms_total]
		,FinancialBuyersAgentCompensation as [buyer_agency_compensation]
		,NULL as [buyer_agency_compensation_type]
		,l.city as [city]
		,hoa_amenities as [community_features]
		,construction_materials as [construction_materials]
		,air_conditioning as [cooling]
		,country as [country]
		,county as [county_or_parish]
		,NULL as [covered_spaces]
		,cumulative_days_on_market as [cumulative_days_on_market]
		,days_on_market as [days_on_market]
		,directions as [directions]
		,elementary_school as [elementary_school_name]
		,exclusions as [exclusions]
		,exterior_features as [exterior_features]
		,fence_description as [fencing]
		,fireplace_description as [fireplace_features]
		,fireplaces as [fireplaces_total]
		,flooring_information as [flooring]
		,NULL as [foundation_details]
		,garage_spaces as [garage_spaces]
		,CASE WHEN (garage_spaces is not null and garage_spaces not like '0') then 'Y' Else 'N' End as [garage_yn]
		,NULL as [hoamanagement_company]
		,hoa_phone as [hoamanagement_company_phone]
		,heat_type as [heating]
		,high_school as [high_school_name]
		,interior_features as [interior_features]
		,middle_school as [intermediate_school_name]
		,junior_high_school as [junior_high_school_name]
		,CASE WHEN z.FALatitude is null then l.latitude ELSE z.FALatitude END as [latitude]
		,laundry_room_description as [laundry_features]
		,NULL as [levels]
		,listing_agent_phone as [list_agent_direct_phone]
		,listing_agent_email as [list_agent_email]
		,listing_agent_name as [list_agent_full_name]
		,a.[mlskey] as [list_agent_key_numeric]
		,a.[primary_association] as [list_agent_mls_provider]
		,a.[mls_id] as [list_agent_mls_id]
		,NULL as [list_agent_texting_allowed_yn]
		,CASE WHEN l.[originating_system_name] is NULL THEN l.[market_name] ELSE l.[originating_system_name] END as [list_mls_provider]
		,NULL as [list_office_key_numeric]
		,NULL as [list_office_manager]
		,NULL as [list_office_manager_key_numeric]
		,NULL as [list_office_manager_license]
		,NULL as [list_office_manager_mls_id]
		,NULL as [list_office_manager_phone]
		,[listing_office_id] as [list_office_mls_id]
		,listing_office_name as [list_office_name]
		,listing_office_phone as [list_office_phone]
		,price as [list_price]
		,list_date as [listing_contract_date]
		,l.mls_listing_id as [listing_id]
		,NULL as [listing_key_numeric]
		,square_feet as [living_area]
		,case when z.FAlongitude is null then l.longitude Else z.FALongitude END as [longitude]
		,lot_description as [lot_number]
		,CASE WHEN [lot_size] = [lot_size_square_feet] THEN cast([lot_size] as money)/43560 ELSE [lot_size] END as [lot_size_acres]
		,[lot_size] as [lot_size_area]
		,CASE WHEN [lot_size_square_feet] is NULL THEN CAST(ROUND(cast(Lot_size as money)*43560,0) as bigint) ELSE [lot_size_square_feet] END as [lot_size_square_feet]
		,CASE WHEN [lot_size_units] is NULL THEN CASE WHEN [lot_size] = [lot_size_square_feet] THEN 'SQFT' WHEN [lot_size] is NULL THEN NULL ELSE 'Acres' END ELSE [lot_size_units] END  as [lot_size_units]
		,middle_school as [middle_school_name]
		,l.[status] as [mls_status]
		,l.[mls_update_date] as [modification_timestamp]
		,dining_room_description as [number_of_dining_areas]
		,living_room_description as [number_of_living_areas]
		,original_listing_price as [original_list_price]
		,NULL as [owner_name]
		,CASE WHEN parcel_number is NULL THEN parcel_number_public_record ELSE parcel_number END as [parcel_number]
		,parking_description as [parking_features]
		,patio_and_porch_features as [patio_and_porch_features]
		,l.photo_date as [photos_change_timestamp]
		,CASE WHEN has_pool = 'true' THEN 'Y' ELSE 'N' END as [pool_yn]
		,case when s.[zip] is null then l.[zip] Else s.[Zip] end as [postal_code]
		,NULL as [postal_code_plus4]
		,NULL as [previous_list_price]
		,NULL as [previous_status]
		,price_change_timestamp as [price_change_timestamp]
		,elementary_school as [primary_school_name]
		,CASE WHEN [allow_comments] = 'N' THEN NULL ELSE [confidential_description] END as [private_remarks]
		,NULL as [property_key]
		,mls_property_sub_type as [property_sub_type]
		,mls_property_type as [property_type]
		,[description] as [public_remarks]
		,roofing as [roof]
		,school_district as [school_district]
		,high_school as [senior_high_school_name]
		,NULL as [showing_contact_phone]
		,NULL as [showing_instructions]
		,NULL as [showing_requirements]
		,mls_status as [standard_status]
		,l.[state] as [state_or_province]
		,status_change_date as [status_change_timestamp]
		,stories_description as [stories]
		,CASE WHEN stories_total is NULL THEN CASE WHEN stories_description = 'one' THEN '1' WHEN stories_description = 'two' THEN '1' WHEN stories_description = 'one and one half' THEN '1.5' WHEN stories_description = 'Three' THEN '3' ELSE NULL END ELSE stories_total END  as [stories_total]
		,s.LeftDirection as [street_dir_prefix]
		,s.RightDirection as [street_dir_suffix]
		,s.Street as [street_name]
		,s.HouseNbr as [street_number]
		,s.HouseNbr as [street_number_numeric]
		,s.Mode as [street_suffix]
		,structure_type as [structural_style]
		,NULL as [sub_agency_compensation]
		,NULL as [sub_agency_compensation_type]
		,subdivision as [subdivision_name]
		,NULL as [tax_block]
		,tax_legal_description as [tax_legal_description]
		,NULL as [us_property_mui]
		,NULL as [unexempt_taxes]
		,utilities as [utilities]
		,virtual_tour_branded as [virtual_toururlunbranded]
		,water_frontage as [waterfront_yn]
		,windows_description as [window_features]
		,year_built as [year_built]
		,year_built_source as [year_built_details]
		,NULL as [year_of_purchase]
		,NULL as [year_built_effective]
		,NULL as [special_listing_conditions]
		,o.[nrds_id] as [office_key_numeric]
		,o.[phone] as [office_phone]
		,o.[zip] as [office_postal_code]
		,o.[license_number] as [license_number]
		,NULL as [office_corporate_license]
		,o.[state] as [office_state_or_province]
		,o.[city] as [office_mail_city]
		,o.[address] as [office_mail_address]
		,[listing_agent_id] as [member_mls_id]
		,[listing_agent_phone] as [member_phone]
		,a.email as [member_email]
		,[listing_agent_name] as [member_full_name]
		,[parent_org_id] as [office_broker_mls_id]
		,CASE WHEN s.[FullStreetAddress] IS NULL THEN l.[address] ELSE s.[FullStreetAddress] END as [Fulladdress]
		,CASE WHEN s.[City] IS NULL THEN l.[City] ELSE s.[City] END as [FullCity]
		,CASE WHEN s.[State] IS NULL THEN l.[State] ELSE s.[State] END as [Region]
		,CASE WHEN s.[Zip] IS NULL THEN l.[Zip] ELSE s.[Zip] END as [FullPostal_code]
		,replace(code,'_39','') as MLSCode 
		,cast(PhotoLinks as varchar(8000)) as PhotoLinks
		,[price_display] as price_display
		,allow_avm as allow_avm
		,l.LoadDate 
		,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE DIRECT_FINAL_VALUE END as AVMValue
		,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE DIRECT_HIGH_VALUE END as HighValue
		,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE DIRECT_LOW_VALUE END as LowValue
		,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE DIRECT_CONFIDENCE_SCORE END as ConfidenceScore
		,CASE WHEN l.allow_avm = 'false' THEN NULL ELSE DIRECT_FORECAST_STANDARD_DEVIATION END as ForecastStandardDeviation
		,l.[attribution_contact]
	  FROM listing.listingFull l with(NOLOCK)
		JOIN src_platlabs.dbo.platlabs_update_config w with(NOLOCK) on l.mls_id = w.mls_id
		Left outer join (Select * FROM agent.Platlabs_agents with(NOLOCK) WHERE mls_id in(Select mls_id from dbo.platlabs_update_config  with(NOLOCK) where active = '1' and code like '%_39')) a
			on l.mls_id = a.mls_id
				and l.[listing_agent_uid] = a.[uid]
		Left outer join (Select * from Office.Platlabs_Offices with(NOLOCK) WHERE mls_id in(Select mls_id from dbo.platlabs_update_config  with(NOLOCK) where active = '1' and code like '%_39')) o
			on l.mls_id = a.mls_id
				and l.[listing_office_uid] = o.[uid]
		left outer join photos.RawPhotoLinks_25 p
			on l.mls_id = p.mls_id
				and l.mls_listing_id = p.mls_listing_id
		left outer join zCust_ADS__00_SharedProcs.dbo.Holocron v
			on l.PropertyID = v.PropertyID
		left outer join addr.StandardizedAddress s with(NOLOCK) 
			on l.uid = s.RAW_ID
		left outer join zCust_ADS__00_SharedProcs.dbo.Property z with(NOLOCK) 
			on l.PropertyID = z.propertyid
	Where  l.mls_id in(Select mls_id from dbo.platlabs_update_config  with(NOLOCK) where active = '1' and code like '%_39') 
	--and l.LoadDate > w.DateSentUpdates
	and l.[status] in('Active','Backup','Contingent','Pending')



