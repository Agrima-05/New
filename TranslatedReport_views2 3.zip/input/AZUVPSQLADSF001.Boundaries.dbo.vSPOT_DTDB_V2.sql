SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Boundaries].[dbo].[vSPOT_DTDB_V2]
AS
		SELECT d.RefId as PropertyID
			,d.FIPS
			,cast(d.EstLotSizeSqFt as float) as LotSqFt
			,cast(CASE WHEN d.RefId is NULL THEN 1 ELSE 0 END as bit) as Shell
			,cast(CASE WHEN b.RefId IS NOT NULL THEN 1 ELSE 0 END as bit) as Multi
			,d.ParcelGeometry3857 as Parcel 
			,d.CentroidLatitude as Latitude
			,d.CentroidLongitude as Longitude
			,CASE WHEN (d.[CentroidPointGeom] is NULL and d.CentroidLatitude is null) then NULL WHEN d.[CentroidPointGeom] is NULL then Geography::Point(d.[CentroidLatitude], d.[CentroidLongitude], 4269) ELSE [CentroidPointGeom] END as Point 
			,8 as SourceID
			,CASE WHEN g.[SourceGeoCodeId] is NULL THEN 5 ELSE g.[SourceGeoCodeId] END as SourceGeocodeID
			,CASE WHEN g.[FAGeoCodeId] is NULL THEN 1 ELSE g.[FAGeoCodeId] END as FAGeocodeID
			,FATimestamp as ProcessDate
			,a.[CompletedDate] as CurrencyDate
			,cast(CASE WHEN c.Latitude IS NOT NULL THEN 1 ELSE 0 END as bit) as Stacked
			,Cast(FATimestamp as varbinary) RowRevision
			,[LoadDate] as CREATED
			,[Precision]
		FROM dbo.[FASpot] d With(NOLOCK)
			LEFT JOIN [dbo].[SpotTracking] a With(NOLOCK)
				ON d.FIPS = a.FIPS
			LEFT OUTER JOIN (Select * from delivery.GeoCodeMapping With(NOLOCK) where SourceId = 8) g
				ON d.[GeoAccuracy] = g.[SourceGeoCodeId]					
			LEFT OUTER JOIN dbo.FASpotStacked c  With(NOLOCK)
				ON d.Latitude = c.Latitude
					and d.Longitude = c.Longitude
			LEFT OUTER JOIN dbo.FASpotMulti b With(NOLOCK)
				ON d.RefId = b.RefId
		--WHERE d.UCIDFlag != 'D'


		--UNION ALL

		--SELECT d.RefId as PropertyID
		--	,d.FIPS
		--	,cast(EstLotSizeSqFt as float) as LotSqFt
		--	,cast(CASE WHEN d.RefId is NULL THEN 1 ELSE 0 END as bit) as Shell
		--	,cast(CASE WHEN b.RefId IS NOT NULL THEN 1 ELSE 0 END as bit) as Multi
		--	,d.ParcelGeometry3857 as Parcel 
			--,d.CentroidLatitude as Latitude
			--,d.CentroidLongitude as Longitude
			--,CASE WHEN (d.[CentroidPointGeom] is NULL and d.CentroidLatitude is null) then NULL WHEN d.[CentroidPointGeom] is NULL then Geography::Point(d.[CentroidLatitude], d.[CentroidLongitude], 4269) ELSE [CentroidPointGeom] END as Point 
		--	,8 as SourceID
		--	,CASE WHEN g.[SourceGeoCodeId] is NULL THEN 5 ELSE g.[SourceGeoCodeId] END as SourceGeocodeID
		--	,CASE WHEN g.[FAGeoCodeId] is NULL THEN 1 ELSE g.[FAGeoCodeId] END as FAGeocodeID
		--	,FATimestamp as ProcessDate
		--	,a.[CompletedDate] as CurrencyDate
		--	,cast(CASE WHEN c.Latitude IS NOT NULL THEN 1 ELSE 0 END as bit) as Stacked
		--	,Cast(FATimestamp as varbinary) RowRevision
		--	,LoadDate as CREATED
		--	,[Precision]
		--FROM [dbo].[FASpot_Generated]  d With(NOLOCK)
		--	LEFT JOIN [dbo].[SpotTracking] a With(NOLOCK)
		--		ON d.FIPS = a.FIPS
		--	LEFT OUTER JOIN (Select * from delivery.GeoCodeMapping With(NOLOCK) where SourceId = 8) g
		--		ON d.[GeoAccuracy] = g.[SourceGeoCodeId]
		--	LEFT OUTER JOIN dbo.FASpotStacked c  With(NOLOCK)
		--		ON d.Latitude = c.Latitude
		--			and d.Longitude = c.Longitude
		--	LEFT OUTER JOIN dbo.FASpotMulti b With(NOLOCK)
		--		ON d.RefId = b.RefId
		--WHERE d.UCIDFlag != 'D'

		UNION ALL

		SELECT d.RefId as PropertyID
			,d.FIPS
			,cast(EstLotSizeSqFt as float) as LotSqFt
			,cast(CASE WHEN d.RefId is NULL THEN 1 ELSE 0 END as bit) as Shell
			,cast(CASE WHEN b.RefId IS NOT NULL THEN 1 ELSE 0 END as bit) as Multi
			,d.ParcelGeometry3857 as Parcel 
			,d.CentroidLatitude as Latitude
			,d.CentroidLongitude as Longitude
			,CASE WHEN (d.[CentroidPointGeom] is NULL and d.CentroidLatitude is null) then NULL WHEN d.[CentroidPointGeom] is NULL then Geography::Point(d.[CentroidLatitude], d.[CentroidLongitude], 4269) ELSE [CentroidPointGeom] END as Point 
			,8 as SourceID
			,CASE WHEN g.[SourceGeoCodeId] is NULL THEN 5 ELSE g.[SourceGeoCodeId] END as SourceGeocodeID
			,CASE WHEN g.[FAGeoCodeId] is NULL THEN 1 ELSE g.[FAGeoCodeId] END as FAGeocodeID
			,FATimestamp as ProcessDate
			,a.[CompletedDate] as CurrencyDate
			,cast(CASE WHEN c.Latitude IS NOT NULL THEN 1 ELSE 0 END as bit) as Stacked
			,Cast(FATimestamp as varbinary) RowRevision
			,LoadDate as CREATED
			,[Precision]
		FROM dbo.[FASpot_a]  d With(NOLOCK)
			LEFT JOIN [dbo].[SpotTracking] a With(NOLOCK)
				ON d.FIPS = a.FIPS
			LEFT OUTER JOIN (Select * from delivery.GeoCodeMapping With(NOLOCK) where SourceId = 8) g
				ON d.[GeoAccuracy] = g.[SourceGeoCodeId]
			LEFT OUTER JOIN dbo.FASpotStacked c With(NOLOCK)
				ON d.Latitude = c.Latitude
					and d.Longitude = c.Longitude
			LEFT OUTER JOIN dbo.FASpotMulti b With(NOLOCK)
				ON d.RefId = b.RefId
		--WHERE d.UCIDFlag != 'D'

		--UNION ALL

		--SELECT d.RefId as PropertyID
		--	,d.FIPS
		--	,cast(EstLotSizeSqFt as float) as LotSqFt
		--	,cast(CASE WHEN d.RefId is NULL THEN 1 ELSE 0 END as bit) as Shell
		--	,cast(CASE WHEN b.RefId IS NOT NULL THEN 1 ELSE 0 END as bit) as Multi
		--	,d.ParcelGeometry3857 as Parcel 
			--,d.CentroidLatitude as Latitude
			--,d.CentroidLongitude as Longitude
			--,CASE WHEN (d.[CentroidPointGeom] is NULL and d.CentroidLatitude is null) then NULL WHEN d.[CentroidPointGeom] is NULL then Geography::Point(d.[CentroidLatitude], d.[CentroidLongitude], 4269) ELSE [CentroidPointGeom] END as Point 
		--	,8 as SourceID
		--	,CASE WHEN g.[SourceGeoCodeId] is NULL THEN 5 ELSE g.[SourceGeoCodeId] END as SourceGeocodeID
		--	,CASE WHEN g.[FAGeoCodeId] is NULL THEN 1 ELSE g.[FAGeoCodeId] END as FAGeocodeID
		--	,FATimestamp as ProcessDate
		--	,a.[CompletedDate] as CurrencyDate
		--	,cast(CASE WHEN c.Latitude IS NOT NULL THEN 1 ELSE 0 END as bit) as Stacked
		--	,Cast(FATimestamp as varbinary) RowRevision
		--	,LoadDate as CREATED
		--	,[Precision]
		--FROM [dbo].[FASpot_Generated_a]  d With(NOLOCK)
		--	LEFT JOIN [dbo].[SpotTracking] a With(NOLOCK)
		--		ON d.FIPS = a.FIPS
		--	LEFT OUTER JOIN (Select * from delivery.GeoCodeMapping With(NOLOCK) where SourceId = 8) g
		--		ON d.[GeoAccuracy] = g.[SourceGeoCodeId]
		--	LEFT OUTER JOIN dbo.FASpotStacked c With(NOLOCK) 
		--		ON d.Latitude = c.Latitude
		--			and d.Longitude = c.Longitude
		--	LEFT OUTER JOIN dbo.FASpotMulti b With(NOLOCK)
		--		ON d.RefId = b.RefId
		--WHERE d.UCIDFlag != 'D'


