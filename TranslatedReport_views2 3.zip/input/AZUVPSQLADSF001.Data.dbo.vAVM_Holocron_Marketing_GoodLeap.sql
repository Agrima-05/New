SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Data].[dbo].[vAVM_Holocron_Marketing_GoodLeap]
AS

SELECT b.[Fips],
b.[PropertyID],
b.[FormattedAPN] as [APN],
b.[SitusStdFullStreetAddress] as [SitusFullStreetAddress],
b.[SitusStdHouseNbr] as [SitusHouseNbr],
b.[SitusStdHouseNbrSuffix] as [SitusHouseNbrSuffix],
b.[SitusStdDirectionLeft] as [SitusDirectionLeft],
b.[SitusStdStreet] as [SitusStreet],
b.[SitusStdMode] as [SitusMode],
b.[SitusStdDirectionRight] as [SitusDirectionRight],
b.[SitusStdUnitType] as [SitusUnitType],
b.[SitusStdUnitNbr] as [SitusUnitNbr],
b.[SitusStdCity] as [SitusCity],
b.[SitusStdState] as [SitusState],
b.[SitusStdZIP5] as [SitusZIP5],
b.[SitusStdZIP4] as [SitusZIP4],
b.[SitusStdCarrierCode] as [SitusCarrierCode],
a.[DIRECT_FINAL_VALUE],
a.[DIRECT_HIGH_VALUE],
a.[DIRECT_LOW_VALUE],
c.[DIRECT_CONFIDENCE_SCORE] as [DIRECT_CONFIDENCE_SCORE],
a.[DIRECT_FORECAST_STANDARD_DEVIATION],
convert(varchar(8),convert(date,a.[VALUE_AS_OF]),112) as [ValuationDate],
b.[StdLandUseCode],
b.PropertyClassID,
B.DTDB_Ref_ID,
B.DTDB_UNFORMATTED_APN,
B.DTDB_FORMATTED_APN,

----Added 20221021 for Costar
B.[CS_FORMATTED_APN],
B.[CS_UNFORMATTED_APN],

--Added 20251224
A.[Comp1] as Comp1PropertyID,
A.[Comp2] as Comp2PropertyID,
A.[Comp3] as Comp3PropertyID,
A.[Comp4] as Comp4PropertyID,
A.[Comp5] as Comp5PropertyID,
A.[Comp6] as Comp6PropertyID,
A.[Comp7] as Comp7PropertyID

FROM [Holocron].[dbo].[Holocron] a with(NOLOCK) JOIN [Data].[dbo].[Property] b with(NOLOCK)
ON a.FIPSCode = b.FIPS and a.REF_ID = b.DTDB_REF_ID
join [Holocron].[dbo].[DirectConfPreCommonConf07182026] c with (nolock)
on c.refid = a.fipscode
where a.[DIRECT_FINAL_VALUE] > 0













