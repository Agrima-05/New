SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



 CREATE view [Extracts].[dbo].[HW_AgentMove_Refresh] 
 as
		SELECT [MLSID]
			  ,[MoveDate]
			  ,[MLSAgentID]
			  ,[FirstName]
			  ,[LastName]
			  ,[CurrentOfficeId]
			  ,[CurrentOffice]
			  ,[CurrentOfficeAddress]
			  ,[CurrentCity]
			  ,[CurrentState]
			  ,[CurrentZip]
			  ,[MLS_FormerOfficeId]
			  ,[FormerOffice]
			  ,[FormerOfficeAddress]
			  ,[FormerCity]
			  ,[FormerState]
			  ,[FormerZip]
			  ,[SrcAgentID]
			  ,[SrcOfficeID]
			  ,[FormerOfficeID]
			  ,[ID]
		  FROM [Platlabs].[dbo].[Platlabs_Src_AgentMove] l
			WHERE l.[MLSID] in(Select mls_id from src_platlabs.dbo.platlabs_update_config with(NOLOCK) where code like '%_39' and active = '1')
		  

