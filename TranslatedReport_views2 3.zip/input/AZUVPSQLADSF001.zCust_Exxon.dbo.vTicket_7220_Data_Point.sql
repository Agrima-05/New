SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

/****** Script for SelectTopNRows command from SSMS  ******/

CREATE view [zCust_Exxon].[dbo].[vTicket_7220_Data_Point] 
as
SELECT  [FIPS]
      ,[PropertyID]
      ,[APN]
      ,[SitusFullStreetAddress]
      ,[SitusCity]
      ,[SitusState]
      ,[SitusZIP5]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusGeoStatusCode]
      ,[PropertyClassID]
      ,[LandUseCode]
      ,[Zoning]
      ,[LotSizeAcres]
      ,[Owner1CorpInd]
      ,[OwnerNAME1FULL]
      ,[OwnerOccupied]
      ,cast( [AssdTotalValue] as int) [AssdTotalValue]
      ,[SumBuildingSqFt]
      ,cast([YearBuilt] as int) [YearBuilt]
      ,[EffectiveYearBuilt]
      ,[GarageParkingNbr]
      ,[CurrentSaleRecordingDate]
      ,[CurrentSalesPrice]
      ,[FATimeStamp]
      ,[FARecordType]
      --,[Parcel]
      ,[Point] as Geom
  FROM [zCust_Exxon].[dbo].[Ticket_7220_Data]

