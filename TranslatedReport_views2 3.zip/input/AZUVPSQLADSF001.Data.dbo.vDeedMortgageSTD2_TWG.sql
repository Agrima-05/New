SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vDeedMortgageSTD2_TWG]
AS

/*--------------------------------------------------          FROM DEED          ---------------------------------------------------*/ 

		SELECT       D.FIPS AS FIPS
		, D.FAPropertyId AS PROPERTYUNIQUEID
		, CASE WHEN P.FormattedAPN is NULL THEN D.APN ELSE P.FormattedAPN END AS APN
		, NULL AS APNSEQUENCENBR
		, P.OldAPN AS PREVIOUSPARCELNUMBER
		, CASE WHEN P.TaxAccountNumber is NULL THEN D.TaxAccountNbr ELSE P.TaxAccountNumber END AS TAXACCOUNTNUMBER
		, D.FAMatchInd AS MatchedFlag
		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(D.SitusStdStreet,'') Like '') THEN P.SitusStdCity ELSE D.SitusStdCity END AS CITY
		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(D.SitusStdStreet,'') Like '') THEN P.SitusStdZIP5 ELSE D.SitusStdZIP5 END AS ZIPCODE
		, TransactionId AS FirstAmericanUniqueTransactionID
		, RecordingDt AS RECORDINGDATE
		, Coalesce(CMTIDInstNbr,YearDocNbrFrmt,DocNbrSrce) AS DOCUMENTNUMBER
		, Global.dbo.DeleteLeadZeros(BookSrce) AS RECORDINGBOOK
		, Global.dbo.DeleteLeadZeros(PageSrce) AS RECORDINGPAGE
		, DocumentTypeCode AS DOCUMENTTYPE
		, DeedTransactionType AS TRANSACTIONTYPE
		, SalesPrice AS SALEAMOUNT                         										 
		, CASE WHEN [ResaleInd] = 1 THEN 'Y' ELSE NULL END AS RESALEFLAG
		, CASE WHEN [NewConstructionInd] = 1 THEN 'Y' ELSE NULL END AS NEWCONSTRUCTIONFLAG
		, CASE WHEN InterFamilyTransfer = 1 THEN 'Y' ELSE NULL END AS INTERFAMILYFLAG
		, CASE WHEN [Reo] = 1 THEN 'Y' ELSE NULL END AS FORCLOSUREFLAG
		, CASE WHEN [REOSale] = 1 THEN 'Y' ELSE NULL END AS REOSALEFLAG
		, Coalesce(Loan1CMTIDInstNbr,[Loan1DocNbrFmt],Loan1Document) AS FIRSTMORTGAGEDOCUMENTNUMBER
		,  Global.dbo.DeleteLeadZeros(Loan1Book) AS FIRSTMORTGAGERECORDINGBOOK
		,  Global.dbo.DeleteLeadZeros(Loan1Page) AS FIRSTMORTGAGERECORDINGPAGE
		, Loan1Amount AS FIRSTMORTGAGEMORTGAGEAMOUNT
		, ltrim(rtrim([Loan1LenderName])) AS FIRSTMORTGAGELENDERNAME
		, Coalesce(Loan2CMTIDInstNbr,Loan2Document) AS SECONDMORTGAGEDOCUMENTNUMBER
		, Loan2Book AS SECONDMORTGAGERECORDINGBOOK
		, Loan2Page AS SECONDMORTGAGERECORDINGPAGE
		, Loan2Amount AS SECONDMORTGAGEAMOUNT
		, Loan2LenderName AS SECONDMORTGAGELENDERNAME
		, TitleCompanyName AS TITLECOMPANYNAME
		,Coalesce(P.[PropertyCLassID],D.[PropertyUseCode]) as PROPERTYUSECODE
		,Coalesce(P.StdLandUseCode,D.LandUseCode) as STDLANDUSECODE
		,Coalesce(P.[PropertyCLassID],D.[PropertyUseCode]) AS PropertyClassID
		,Coalesce(P.[SitusCensusTract],D.[SitusCensusTract]) AS SitusCensusTract
		, Loan1Type AS FIRSTMORTGAGEDETAILEDLOANTYPE
		, Loan2Type AS SECONDMORTGAGEDETAILEDLOANTYPE
		,D.[CMTID] as DEEDCMTID
		,D.[CMTIDInstNbr] as DEEDCMTIDInstNbr
		,D.[Loan1CMTID]
		, D.[Loan1CMTIDInstNbr]
		, D.[Loan2CMTID]
		, D.[Loan2CMTIDInstNbr]
		, D.[Loan1LenderTypeCode]
		, D.FAUCIDFlag AS UCID
		, D.FATimeStamp as FATimeStamp 
						--, Loan1TransType AS FIRSTMORTGAGELOANTYPECODE
						,Case when [loan1transtype] = '6' then '1'
							when [loan1transtype] = '7' then '2'
							when [loan1transtype] = '8' then '3'
							when [loan1transtype] = '9' then '4'
							when [loan1transtype] = '10' then '5'
							when [loan1transtype] = '11'then '6'
							when [Loan1TransType] = '3' then '5'
							when [Loan1TransType] = '0' then '6'
						end as FIRSTMORTGAGELOANTYPECODE
						--, Loan2TransType AS SECONDMORTGAGELOANTYPECODE
						, Case when [Loan2TransType] = '6' then '1'
							when [Loan2TransType] = '7' then '2'
							when [Loan2TransType] = '8' then '3'
							when [Loan2TransType] = '9' then '4'
							when [Loan2TransType] = '10' then '5'
							when [Loan2TransType] = '11'then '6'
							when [Loan2TransType] = '3' then '5'
							when [Loan2TransType] = '0' then '6'
						end as SECONDMORTGAGELOANTYPECODE
		, NULL  AS FIRSTMORTGAGEREFIFLAG
		, NULL  AS FIRSTMORTGAGEEQUITYFLAG
		, NULL AS FIRSTMORTGAGEHELOCFLAG
		,D.[MultiAPNCode]
		,d.Buyer1FullName as BuyerBorrower1Full
		,d.Buyer2FullName as BuyerBorrower2Full
		,d.Seller1FullName 
		,d.Seller2FullName
		,CASE WHEN P.SitusStdFullStreetAddress is null THEN d.SitusStdFullStreetAddress ELSE P.SitusStdFullStreetAddress END as SitusStdFullSTreetAddress
		,g.[State]
		,g.[County Name] as COUNTY
		FROM Deed D  with(NOLOCK) Left outer join Data.dbo.Property as P with(NOLOCK)
		on D.FIPS = P.FIPS
		and D.FAPropertyID = P.PropertyID
		JOIN Global.dbo.County g on d.FIPS = g.FIPSCode


UNION ALL

/*--------------------------------------------------          FROM MORTGAGE          ---------------------------------------------------*/  

		SELECT M.FIPS AS FIPS
		, M.FAPropertyId AS PROPERTYUNIQUEID
		, CASE WHEN P.FormattedAPN is NULL THEN M.APN ELSE P.FormattedAPN END AS APN
		, NULL AS APNSEQUENCENBR
		, P.OldAPN AS PREVIOUSPARCELNUMBER
		, CASE WHEN P.TaxAccountNumber is NULL THEN M.TaxAccountNbr ELSE P.TaxAccountNumber END AS TAXACCOUNTNUMBER
		, M.FAMatchInd AS MatchedFlag
		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(M.SitusStreet,'') Like '') THEN P.SitusStdCity ELSE M.SitusCity END AS CITY
		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(M.SitusStreet,'') Like '') THEN P.SitusStdZIP5 ELSE M.SitusZIP5 END AS ZIPCODE
		, TransactionId AS FirstAmericanUniqueTransactionID
		, RecordingDt AS RECORDINGDATE
		, Coalesce(CMTIDInstNbr,YearDocNbrFrmt,DocNbrSrce) AS DOCUMENTNUMBER
		,  Global.dbo.DeleteLeadZeros(BookSrce) AS RECORDINGBOOK
		,  Global.dbo.DeleteLeadZeros(PageSrce) AS RECORDINGPAGE
		, DocumentTypeCode AS DOCUMENTTYPE
		, CASE WHEN [LoanTransType] = '6' THEN '1' 
			WHEN [LoanTransType] = '7' THEN '2' 
				WHEN [LoanTransType] = '8' THEN '3' 
					WHEN [LoanTransType] = '9' THEN '4' 
						WHEN [LoanTransType] = '10' THEN '5' 
							WHEN [LoanTransType] = '11' THEN '6' 
								WHEN [LoanTransType] = '3' THEN '5' 
									WHEN [LoanTransType] = '0' THEN '6' 
			END AS TRANSACTIONTYPE
		, NULL AS SALEAMOUNT
		, NULL AS RESALEFLAG
		, NULL AS NEWCONSTRUCTIONFLAG
		, NULL AS INTERFAMILYFLAG
		, NULL AS FORCLOSUREFLAG
		, NULL AS REOSALEFLAG
		, Coalesce(CMTIDInstNbr,YearDocNbrFrmt,DocNbrSrce) AS FIRSTMORTGAGEDOCUMENTNUMBER
		, Global.dbo.DeleteLeadZeros(BookSrce) AS FIRSTMORTGAGERECORDINGBOOK
		, Global.dbo.DeleteLeadZeros(PageSrce) AS FIRSTMORTGAGERECORDINGPAGE
		, LoanAmount AS FIRSTMORTGAGEMORTGAGEAMOUNT
		, ltrim(rtrim([LenderName])) AS FIRSTMORTGAGELENDERNAME
		, NULL AS SECONDMORTGAGEDOCUMENTNUMBER
		, NULL AS SECONDMORTGAGERECORDINGBOOK
		, NULL AS SECONDMORTGAGERECORDINGPAGE
		, NULL AS SECONDMORTGAGEAMOUNT
		, NULL AS SECONDMORTGAGELENDERNAME
		, TitleCompanyName AS TITLECOMPANYNAME
		,P.[PropertyCLassID] as PROPERTYUSECODE
		,P.StdLandUseCode as STDLANDUSECODE
		,P.[PropertyClassID] AS PropertyClassID
		,Coalesce(P.[SitusCensusTract],M.[SitusCensusTract]) AS SitusCensusTract
				, LoanType AS FIRSTMORTGAGEDETAILEDLOANTYPE
				, NULL AS SECONDMORTGAGEDETAILEDLOANTYPE
				,NULL as DEEDCMTID
				,NULL as DEEDCMTIDInstNbr
				,M.[CMTID] as [Loan1CMTID]
				,M.[CMTIDInstNbr] as [Loan1CMTIDInstNbr]
				,NULL as [Loan2CMTID]
				,NULL as [Loan2CMTIDInstNbr]
		,M.[LenderTypeCode]
		,M.FAUCIDFlag AS UCID
		,M.FATimeStamp as FATimeStamp 
						 , Case when [LoanTransType] = '6' then '1'
								when [LoanTransType] = '7' then '2'
								when [LoanTransType] = '8' then '3'
								when [LoanTransType] = '9' then '4'
								when [LoanTransType] = '10' then '5'
								when [LoanTransType] = '11'then '6'
								when [LoanTransType] = '3'then '5'
								when [LoanTransType] = '0'then '6'
						 end as FIRSTMORTGAGELOANTYPECODE
						 , NULL as SECONDMORTGAGELOANTYPECODE
		, [LoanRefiLoanInd]  AS FIRSTMORTGAGEREFIFLAG
		, [LoanEquityLoanInd]  AS FIRSTMORTGAGEEQUITYFLAG
		, [LoanHELOCLoanInd] AS FIRSTMORTGAGEHELOCFLAG
		,M.MultiAPNCode
		,M.Borrower1FullName as BuyerBorrower1Full
		,M.Borrower2FullName as BuyerBorrower2Full
		,NULL as Seller1FullName 
		,NULL as Seller2FullName
		,CASE WHEN P.SitusStdFullStreetAddress is null THEN M.SitusFullStreetAddress ELSE P.SitusStdFullStreetAddress END as SitusStdFullSTreetAddress
		,g.[State]
		,g.[County Name] as COUNTY
		FROM mortgage M with(NOLOCK) JOIN [Global].dbo.[County] b with(NOLOCK)
			ON M.FIPS = b.FIPSCode
		Left outer join Data.dbo.Property as P with(NOLOCK)
		on M.FIPS = P.FIPS
		and M.FAPropertyID = P.PropertyID
		JOIN Global.dbo.County g on M.FIPS = g.FIPSCode



--UNION ALL

--/*--------------------------------------------------          FROM DEED_SUP          ---------------------------------------------------*/ 

--		SELECT       D.FIPS AS FIPS
--		, D.FAPropertyId AS PROPERTYUNIQUEID
--		, CASE WHEN P.FormattedAPN is NULL THEN D.APN ELSE P.FormattedAPN END AS APN
--		, NULL AS APNSEQUENCENBR
--		, P.OldAPN AS PREVIOUSPARCELNUMBER
--		, CASE WHEN P.TaxAccountNumber is NULL THEN D.TaxAccountNbr ELSE P.TaxAccountNumber END AS TAXACCOUNTNUMBER
--		, D.FAMatchInd AS MatchedFlag
--		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(D.SitusStdStreet,'') Like '') THEN P.SitusStdCity ELSE D.SitusStdCity END AS CITY
--		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(D.SitusStdStreet,'') Like '') THEN P.SitusStdZIP5 ELSE D.SitusStdZIP5 END AS ZIPCODE
--		, TransactionId AS FirstAmericanUniqueTransactionID
--		, RecordingDt AS RECORDINGDATE
--		, Coalesce(CMTIDInstNbr,YearDocNbrFrmt,DocNbrSrce) AS DOCUMENTNUMBER
--		, BookSrce AS RECORDINGBOOK
--		, PageSrce AS RECORDINGPAGE
--		, DocumentTypeCode AS DOCUMENTTYPE
--		, DeedTransactionType AS TRANSACTIONTYPE
--		, SalesPrice AS SALEAMOUNT                     										 
--		, CASE WHEN [ResaleInd] = 1 THEN 'Y' ELSE NULL END AS RESALEFLAG
--		, CASE WHEN [NewConstructionInd] = 1 THEN 'Y' ELSE NULL END AS NEWCONSTRUCTIONFLAG
--		, CASE WHEN InterFamilyTransfer = 1 THEN 'Y' ELSE NULL END AS INTERFAMILYFLAG
--		, CASE WHEN [Reo] = 1 THEN 'Y' ELSE NULL END AS FORCLOSUREFLAG
--		, CASE WHEN [REOSale] = 1 THEN 'Y' ELSE NULL END AS REOSALEFLAG
--		, Coalesce(Loan1CMTIDInstNbr,Loan1Document) AS FIRSTMORTGAGEDOCUMENTNUMBER
--		,  Global.dbo.DeleteLeadZeros(Loan1Book) AS FIRSTMORTGAGERECORDINGBOOK
--		,  Global.dbo.DeleteLeadZeros(Loan1Page) AS FIRSTMORTGAGERECORDINGPAGE
--		, Loan1Amount AS FIRSTMORTGAGEMORTGAGEAMOUNT
--		, ltrim(rtrim([Loan1LenderName])) AS FIRSTMORTGAGELENDERNAME
--		, Coalesce(Loan2CMTIDInstNbr,Loan2Document) AS SECONDMORTGAGEDOCUMENTNUMBER
--		, Loan2Book AS SECONDMORTGAGERECORDINGBOOK
--		, Loan2Page AS SECONDMORTGAGERECORDINGPAGE
--		, Loan2Amount AS SECONDMORTGAGEAMOUNT
--		, Loan2LenderName AS SECONDMORTGAGELENDERNAME
--		, TitleCompanyName AS TITLECOMPANYNAME
--		,Coalesce(P.[PropertyCLassID],D.[PropertyUseCode]) as PROPERTYUSECODE
--		,Coalesce(P.StdLandUseCode,D.LandUseCode) as STDLANDUSECODE
--		,Coalesce(P.[PropertyCLassID],D.[PropertyUseCode]) AS PropertyClassID
--		,Coalesce(P.[SitusCensusTract],D.[SitusCensusTract]) AS SitusCensusTract
--		, Loan1Type AS FIRSTMORTGAGEDETAILEDLOANTYPE
--		, Loan2Type AS SECONDMORTGAGEDETAILEDLOANTYPE
--		,D.[CMTID] as DEEDCMTID
--		,D.[CMTIDInstNbr] as DEEDCMTIDInstNbr
--		,D.[Loan1CMTID]
--		,D.[Loan1CMTIDInstNbr]
--		,D.[Loan2CMTID]
--		,D.[Loan2CMTIDInstNbr]
--		,D.[Loan1LenderTypeCode]
--		, D.FAUCIDFlag AS UCID
--		, D.FATimeStamp as FATimeStamp 
--						--, Loan1TransType AS FIRSTMORTGAGELOANTYPECODE
--						,Case when [loan1transtype] = '6' then '1'
--							when [loan1transtype] = '7' then '2'
--							when [loan1transtype] = '8' then '3'
--							when [loan1transtype] = '9' then '4'
--							when [loan1transtype] = '10' then '5'
--							when [loan1transtype] = '11'then '6'
--							when [Loan1TransType] = '3' then '5'
--							when [Loan1TransType] = '0' then '6'
--						end as FIRSTMORTGAGELOANTYPECODE
--						--, Loan2TransType AS SECONDMORTGAGELOANTYPECODE
--						, Case when [Loan2TransType] = '6' then '1'
--							when [Loan2TransType] = '7' then '2'
--							when [Loan2TransType] = '8' then '3'
--							when [Loan2TransType] = '9' then '4'
--							when [Loan2TransType] = '10' then '5'
--							when [Loan2TransType] = '11'then '6'
--							when [Loan2TransType] = '3' then '5'
--							when [Loan2TransType] = '0' then '6'
--						end as SECONDMORTGAGELOANTYPECODE
--		, NULL  AS FIRSTMORTGAGEREFIFLAG
--		, NULL  AS FIRSTMORTGAGEEQUITYFLAG
--		, NULL AS FIRSTMORTGAGEHELOCFLAG
--		,D.MultiAPNCode
--		,d.Buyer1FullName as BuyerBorrower1Full
--		,d.Buyer2FullName as BuyerBorrower2Full
--		,d.Seller1FullName 
--		,d.Seller2FullName
--		,CASE WHEN P.SitusStdFullStreetAddress is null THEN d.SitusStdFullStreetAddress ELSE P.SitusStdFullStreetAddress END as SitusStdFullSTreetAddress
--		,g.[State]
--		,g.[County Name] as COUNTY
--		FROM deed_sup D  with(NOLOCK) JOIN [Global].dbo.[County] b with(NOLOCK)
--			ON D.FIPS = b.FIPSCode
--		Left outer join Data.dbo.Property as P with(NOLOCK)
--		on D.FIPS = P.FIPS
--		and D.FAPropertyID = P.PropertyID
--		JOIN Global.dbo.County g on d.FIPS = g.FIPSCode
--		WHERE D.FAUCIDFlag not like 'D'


--UNION ALL

--/*--------------------------------------------------          FROM MORTGAGE_SUP          ---------------------------------------------------*/  

--		SELECT M.FIPS AS FIPS
--		, M.FAPropertyId AS PROPERTYUNIQUEID
--		, CASE WHEN P.FormattedAPN is NULL THEN M.APN ELSE P.FormattedAPN END AS APN
--		, NULL AS APNSEQUENCENBR
--		, P.OldAPN AS PREVIOUSPARCELNUMBER
--		, CASE WHEN P.TaxAccountNumber is NULL THEN M.TaxAccountNbr ELSE P.TaxAccountNumber END AS TAXACCOUNTNUMBER
--		, M.FAMatchInd AS MatchedFlag
--		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(M.SitusStreet,'') Like '') THEN P.SitusStdCity ELSE M.SitusCity END AS CITY
--		, CASE WHEN (P.SitusStdZip4 not like '' OR isNULL(M.SitusStreet,'') Like '') THEN P.SitusStdZIP5 ELSE M.SitusZIP5 END AS ZIPCODE
--		, TransactionId AS FirstAmericanUniqueTransactionID
--		, RecordingDt AS RECORDINGDATE
--		, Coalesce(CMTIDInstNbr,YearDocNbrFrmt,DocNbrSrce) AS DOCUMENTNUMBER
--		, BookSrce AS RECORDINGBOOK
--		, PageSrce AS RECORDINGPAGE
--		, DocumentTypeCode AS DOCUMENTTYPE
--		, CASE WHEN [LoanTransType] = '6' THEN '1' 
--			WHEN [LoanTransType] = '7' THEN '2' 
--				WHEN [LoanTransType] = '8' THEN '3' 
--					WHEN [LoanTransType] = '9' THEN '4' 
--						WHEN [LoanTransType] = '10' THEN '5' 
--							WHEN [LoanTransType] = '11' THEN '6' 
--								WHEN [LoanTransType] = '3' THEN '5' 
--									WHEN [LoanTransType] = '0' THEN '6' 
--			END AS TRANSACTIONTYPE
--		, NULL AS SALEAMOUNT
--		, NULL AS RESALEFLAG
--		, NULL AS NEWCONSTRUCTIONFLAG
--		, NULL AS INTERFAMILYFLAG
--		, NULL AS FORCLOSUREFLAG
--		, NULL AS REOSALEFLAG
--		, Coalesce(CMTIDInstNbr,YearDocNbrFrmt,DocNbrSrce) AS FIRSTMORTGAGEDOCUMENTNUMBER
--		,  Global.dbo.DeleteLeadZeros(BookSrce) AS FIRSTMORTGAGERECORDINGBOOK
--		,  Global.dbo.DeleteLeadZeros(PageSrce) AS FIRSTMORTGAGERECORDINGPAGE
--		, LoanAmount AS FIRSTMORTGAGEMORTGAGEAMOUNT
--		, ltrim(rtrim([LenderName])) AS FIRSTMORTGAGELENDERNAME
--		, NULL AS SECONDMORTGAGEDOCUMENTNUMBER
--		, NULL AS SECONDMORTGAGERECORDINGBOOK
--		, NULL AS SECONDMORTGAGERECORDINGPAGE
--		, NULL AS SECONDMORTGAGEAMOUNT
--		, NULL AS SECONDMORTGAGELENDERNAME
--		, TitleCompanyName AS TITLECOMPANYNAME
--		,P.[PropertyCLassID] as PROPERTYUSECODE
--		,P.StdLandUseCode as STDLANDUSECODE
--		,P.[PropertyClassID] AS PropertyClassID
--		,Coalesce(P.[SitusCensusTract],M.[SitusCensusTract]) AS SitusCensusTract
--				, LoanType AS FIRSTMORTGAGEDETAILEDLOANTYPE
--				, NULL AS SECONDMORTGAGEDETAILEDLOANTYPE
--				,NULL as DEEDCMTID
--				,NULL as DEEDCMTIDInstNbr
--				,M.[CMTID] as [Loan1CMTID]
--				,M.[CMTIDInstNbr] as [Loan1CMTIDInstNbr]
--				,NULL as [Loan2CMTID]
--				,NULL as [Loan2CMTIDInstNbr]
--		,M.[LenderTypeCode]
--		,M.FAUCIDFlag AS UCID
--		,M.FATimeStamp as FATimeStamp 
--						 , Case when [LoanTransType] = '6' then '1'
--								when [LoanTransType] = '7' then '2'
--								when [LoanTransType] = '8' then '3'
--								when [LoanTransType] = '9' then '4'
--								when [LoanTransType] = '10' then '5'
--								when [LoanTransType] = '11'then '6'
--								when [LoanTransType] = '3'then '5'
--								when [LoanTransType] = '0'then '6'
--						 end as FIRSTMORTGAGELOANTYPECODE
--						 , NULL as SECONDMORTGAGELOANTYPECODE
--		, [LoanRefiLoanInd]  AS FIRSTMORTGAGEREFIFLAG
--		, [LoanEquityLoanInd]  AS FIRSTMORTGAGEEQUITYFLAG
--		, [LoanHELOCLoanInd] AS FIRSTMORTGAGEHELOCFLAG
--		,M.MultiAPNCode
--		,M.Borrower1FullName as BuyerBorrower1Full
--		,M.Borrower2FullName as BuyerBorrower2Full
--		,NULL as Seller1FullName 
--		,NULL as Seller2FullName
--		,CASE WHEN P.SitusStdFullStreetAddress is null THEN M.SitusFullStreetAddress ELSE P.SitusStdFullStreetAddress END as SitusStdFullSTreetAddress
--		,g.[State]
--		,g.[County Name] as COUNTY

--		FROM mortgage_sup M with(NOLOCK) JOIN [Global].dbo.[County] b with(NOLOCK)
--			ON M.FIPS = b.FIPSCode
--		Left outer join Data.dbo.Property as P with(NOLOCK)
--		on M.FIPS = P.FIPS
--		and M.FAPropertyID = P.PropertyID
--		JOIN Global.dbo.County g on M.FIPS = g.FIPSCode
--		WHERE M.FAUCIDFlag not like 'D'
--		and M.LoanAmount is not null 
--		and M.LoanAmount > 0











GRANT SELECT ON [dbo].[vDeedMortgageSTD2_TWG] TO [CORP\cbrady] AS [dbo]
