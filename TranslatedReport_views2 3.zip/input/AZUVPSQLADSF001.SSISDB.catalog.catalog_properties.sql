SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [SSISDB].[catalog].[catalog_properties]
AS
SELECT     [property_name], 
           [property_value]
FROM       [internal].[catalog_properties]

GRANT SELECT ON [catalog].[catalog_properties] TO [ModuleSigner] AS [dbo]
GRANT SELECT ON [catalog].[catalog_properties] TO [public] AS [dbo]
