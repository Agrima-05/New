SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [zCust__GenericAddressMatch].[dbo].[v_Claim_w_Payment_CauseBucket_std_officetype_MelissaMatch]
AS
SELECT        b.MatchCode, b.GeoStatusCode, b.AddressMatchResults, a.RecordId, a.[National Claim Num], a.[ALTA Code], a.[ALTA Desc], a.[Claim Name], a.[Claim Type Code], 
                         a.[Claim Type Desc], a.[County Name], a.[Date Closed], a.[Date Open], a.[Legal Desc], a.[Parcel Num], a.[Primary Policy Amount], a.[Primary Policy Date], 
                         a.[Primary Policy Desc Code], a.[Primary Policy Desc Desc], a.[Primary Policy Num], a.[Primary Policy Type Code], a.[Primary Policy Type Desc], 
                         a.[Primary Policy Fast Order Id], a.[Property Address 1], a.[Property Address 2], a.[Property City], a.[Property Type Code], a.[Property Type Desc], a.[Property Zip], 
                         a.[State Code], a.[State Name], a.[State Postal Code], a.[Claim Cause Code], a.[Claim Cause Desc], a.[CC Complete Desc], a.[Process Cause Code], 
                         a.[Process Cause Desc], a.[PC Complete Desc], a.[Expense Payment], a.[Settlement Payment], a.[Total Payment], a.ClaimCause_Code, a.CC_Complete_Desc, 
                         a.CCTier1, a.CCTier2, a.CCTier3, a.CCTier4, a.ClaimCause1, a.ClaimCause2, a.ProcessCause_Code, a.PC_Complete_Desc, a.PCTier1, a.PCTier2, a.PCTier3, 
                         a.ProcessCause1, a.ProcessCause2, a.REF_ID, a.Fips, a.[Issuing Office Type], a.[Office Type]
FROM            dbo.Claim_w_Payment_CauseBucket_std_officetype AS a INNER JOIN
                         dbo.Claim_w_Payment_CauseBucket_std_officetype_MelissaMatch AS b ON a.RecordId = b.RAW_ID

