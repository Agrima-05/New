SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON








CREATE VIEW [xKLowe].[dbo].[v_HOA_Fulfillment]
AS
Select G.FIPS,G.FAPropertyParent, X.* from 
(

Select REF_ID, Id, Type, Name
		,ContactTypeId
		, ContactName, Address, City, State, Zip, Plus4, Email
	   , BusinessPhoneNbr
	   , BusinessExtNbr
	   , CellPhoneNbr
	   , FaxPhoneNbr
	   , PagerPhoneNbr
	   , ContactRanking
	   , FeeRanking
	   , Amount, FeeTypeId, MinAmount, MaxAmount, FeeFrequencyId, HOARanking from (
select oap.REF_ID
	, o.Id
       ,ISNULL(oat.Type , 'HOA') as Type
       , Case When (o.StatusId IN (1, 2, 5)) THEN o.Name END as Name
	   --, o.Name
	   , c.ContactTypeId
	   , c.Name as ContactName
	   , c.Address
	   , c.City
	   , c.State
	   , c.Zip
	   , c.Plus4
	   , c.[Email]
	   , c.BusinessPhoneNbr
	   , c.BusinessExtNbr
	   , c.CellPhoneNbr
	   , c.FaxPhoneNbr
	   , c.PagerPhoneNbr
	   --, oac.Ranking as ContactRanking
	   , oaf.Amount 
	   , oaf.FeeTypeId
	   , oaf.MinAmount
	   , oaf.MaxAmount
       , oaf.FeeFrequencyId
       , DENSE_RANK() OVER (Partition By oap.REF_ID ORDER BY Case When o.StatusId = 2 THEN 1 WHEN o.StatusId = 1 THEN 2 ELSE 3 END, ISNULL(oat.Id, 0), o.CreateDate DESC, o.Id) as HOARanking
	   , DENSE_RANK() OVER (Partition By oap.REF_ID, o.Id ORDER BY oac.SourceCount DESC, oac.ContactId) as ContactRanking
	   , DENSE_RANK() OVER (Partition By oap.REF_ID, o.Id ORDER BY Case When (oaf.Amount > 0 AND (oaf.FeeTypeId IS NULL or oaf.FeeTypeId IN (4,5,8))) THEN 1 ELSE 2 END, oaf.Id) as FeeRanking  
	   , DENSE_RANK() OVER (Partition By oap.REF_ID ORDER BY Case When o.StatusId = 2 THEN 1 WHEN o.StatusId = 1 THEN 2 ELSE 3 END) as DenseRank        
from HOA.OA.OwnerAssociationProperty oap WITH (NOLOCK) 
LEFT JOIN HOA.OA.OwnerAssociationType oat on oat.Id = oap.OwnerAssociationTypeId
LEFT JOIN HOA.OA.OwnerAssociation o  WITH (NOLOCK) on o.Id = oap.OwnerAssociationId and (o.OwnerAssociationTypeId IS NULL OR o.OwnerAssociationTypeId NOT IN (4,5,6))
LEFT JOIN HOA.OA.OwnerAssociationFee oaf  WITH (NOLOCK) on oaf.OwnerAssociationId = o.Id --and (oaf.FeeTypeId IS NULL or oaf.FeeTypeId IN (4,5,8))
LEFT JOIN (
       select oac.OwnerAssociationId, oac.ContactId, sc.SourceCount--, ROW_NUMBER() OVER (Partition By oac.OwnerAssociationId ORDER BY sc.SourceCount DESC) as Ranking
       from HOA.OA.OwnerAssociationContact oac
       LEFT JOIN HOA.OA.Contact c  WITH (NOLOCK) on c.Id = oac.ContactId
       LEFT JOIN HOA.Staging.Contact sc on sc.Id = c.StagingId
) oac on oac.OwnerAssociationId = o.Id
LEFT JOIN HOA.OA.Contact c  WITH (NOLOCK) on c.Id = oac.ContactId
--LEFT JOIN HOA.OA.FeeFrequency ff  WITH (NOLOCK) on ff.Id = oaf.FeeFrequencyId
Where   o.StatusId NOT IN (3, 6)
	  
) r where HOARanking <= 4 and ContactRanking < 4 and FeeRanking = 1 and DenseRank = 1 --DenseRank filter will exclude all alternative 'hits' if there is a hit of higher quality

UNION ALL

Select REF_ID, Id, Type, Name
		,ContactTypeId
		, ContactName, Address, City, State, Zip, Plus4, Email
	   , BusinessPhoneNbr
	   , BusinessExtNbr
	   , CellPhoneNbr
	   , FaxPhoneNbr
	   , PagerPhoneNbr
	   , ContactRanking
	   , NULL as FeeRanking
	   , Amount, FeeTypeId, MinAmount, MaxAmount, FeeFrequencyId, HOARanking from (
select oap.REF_ID
	, o.Id
       ,oat.Type 
       ,  o.Name 
	   , c.ContactTypeId
	   , c.Name as ContactName
	   , c.Address
	   , c.City
	   , c.State
	   , c.Zip
	   , c.Plus4
	   , c.[Email]
	   , c.BusinessPhoneNbr
	   , c.BusinessExtNbr
	   , c.CellPhoneNbr
	   , c.FaxPhoneNbr
	   , c.PagerPhoneNbr
	   , NULL as Amount
	   , NULL as FeeTypeId
	   , NULL as MinAmount
	   , NULL as MaxAmount
       , NULL as FeeFrequencyId
       , DENSE_RANK() OVER (Partition By oap.REF_ID ORDER BY Case When o.StatusId = 2 THEN 1 WHEN o.StatusId = 1 THEN 2 ELSE 3 END, ISNULL(oat.Id, 0), o.CreateDate DESC, o.Id) as HOARanking
	   , DENSE_RANK() OVER (Partition By oap.REF_ID, o.Id ORDER BY oac.SourceCount DESC, oac.ContactId) as ContactRanking
	   --, DENSE_RANK() OVER (Partition By oap.REF_ID, o.Id ORDER BY Case When (oaf.Amount > 0 AND (oaf.FeeTypeId IS NULL or oaf.FeeTypeId IN (4,5,8))) THEN 1 ELSE 2 END, oaf.Id) as FeeRanking      
from HOA.OA.OwnerAssociationProperty oap WITH (NOLOCK) 
INNER JOIN HOA.OA.OwnerAssociationType oat on oat.Id = oap.OwnerAssociationTypeId
INNER JOIN HOA.OA.OwnerAssociation o  WITH (NOLOCK) on o.Id = oap.OwnerAssociationId and (o.OwnerAssociationTypeId  IN (4))
LEFT JOIN (
       select oac.OwnerAssociationId, oac.ContactId, sc.SourceCount--, ROW_NUMBER() OVER (Partition By oac.OwnerAssociationId ORDER BY sc.SourceCount DESC) as Ranking
       from HOA.OA.OwnerAssociationContact oac
       LEFT JOIN HOA.OA.Contact c  WITH (NOLOCK) on c.Id = oac.ContactId
       LEFT JOIN HOA.Staging.Contact sc on sc.Id = c.StagingId
) oac on oac.OwnerAssociationId = o.Id
LEFT JOIN HOA.OA.Contact c  WITH (NOLOCK) on c.Id = oac.ContactId
--LEFT JOIN HOA.OA.FeeFrequency ff  WITH (NOLOCK) on ff.Id = oaf.FeeFrequencyId
Where   o.StatusId NOT IN (3, 6)
	  
) r where HOARanking <= 1 and ContactRanking <= 1 

UNION ALL

Select REF_ID, Id, Type, Name
		,ContactTypeId
		, ContactName, Address, City, State, Zip, Plus4, Email
	   , BusinessPhoneNbr
	   , BusinessExtNbr
	   , CellPhoneNbr
	   , FaxPhoneNbr
	   , PagerPhoneNbr
	   , ContactRanking
	   , NULL as FeeRanking
	   , Amount, FeeTypeId, MinAmount, MaxAmount, FeeFrequencyId, HOARanking from (
select oap.REF_ID
	, o.Id
       ,oat.Type 
       ,  o.Name 
	   , c.ContactTypeId
	   , c.Name as ContactName
	   , c.Address
	   , c.City
	   , c.State
	   , c.Zip
	   , c.Plus4
	   , c.[Email]
	   , c.BusinessPhoneNbr
	   , c.BusinessExtNbr
	   , c.CellPhoneNbr
	   , c.FaxPhoneNbr
	   , c.PagerPhoneNbr
	   , NULL as Amount
	   , NULL as FeeTypeId
	   , NULL as MinAmount
	   , NULL as MaxAmount
       , NULL as FeeFrequencyId
       , DENSE_RANK() OVER (Partition By oap.REF_ID ORDER BY Case When o.StatusId = 2 THEN 1 WHEN o.StatusId = 1 THEN 2 ELSE 3 END, ISNULL(oat.Id, 0), o.CreateDate DESC, o.Id) as HOARanking
	   , DENSE_RANK() OVER (Partition By oap.REF_ID, o.Id ORDER BY oac.SourceCount DESC, oac.ContactId) as ContactRanking
	   --, DENSE_RANK() OVER (Partition By oap.REF_ID, o.Id ORDER BY Case When (oaf.Amount > 0 AND (oaf.FeeTypeId IS NULL or oaf.FeeTypeId IN (4,5,8))) THEN 1 ELSE 2 END, oaf.Id) as FeeRanking      
from HOA.OA.OwnerAssociationProperty oap WITH (NOLOCK) 
INNER JOIN HOA.OA.OwnerAssociationType oat on oat.Id = oap.OwnerAssociationTypeId
INNER JOIN HOA.OA.OwnerAssociation o  WITH (NOLOCK) on o.Id = oap.OwnerAssociationId and (o.OwnerAssociationTypeId  IN (6))
LEFT JOIN (
       select oac.OwnerAssociationId, oac.ContactId, sc.SourceCount--, ROW_NUMBER() OVER (Partition By oac.OwnerAssociationId ORDER BY sc.SourceCount DESC) as Ranking
       from HOA.OA.OwnerAssociationContact oac
       LEFT JOIN HOA.OA.Contact c  WITH (NOLOCK) on c.Id = oac.ContactId
       LEFT JOIN HOA.Staging.Contact sc on sc.Id = c.StagingId
) oac on oac.OwnerAssociationId = o.Id
LEFT JOIN HOA.OA.Contact c  WITH (NOLOCK) on c.Id = oac.ContactId
--LEFT JOIN HOA.OA.FeeFrequency ff  WITH (NOLOCK) on ff.Id = oaf.FeeFrequencyId
Where   o.StatusId NOT IN (3, 6)
	  
) r where HOARanking <= 1 and ContactRanking <= 1 
) X
join Global.dbo.Property_Master as G with(NOLOCK)
on X.REF_ID = G.DTDB_REF_ID
where G.FAPropertyParent = G.FAPropertyID








