SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [xEBader].[dbo].[weeklyupdates] AS SELECT 
CAST(SourceId AS INT) AS QueryOID,
       [PropertyId]
      ,[FIPS]
      ,[LotSqFt]
      ,[Shell]
      ,[Multi]
      ,[Parcel]
      ,[Latitude]
      ,[Longitude]
      ,[Point]
      ,[SourceId]
      ,[SourceGeoCodeId]
      ,[FAGeoCodeId]
      ,[ProcessDate]
      ,[CurrencyDate]
      ,[Stacked]
      ,[created]
      ,[Precision]
      ,[InsertFrom]
      ,[ExtractDate]
  FROM [xEBader].[dbo].[DtDotCom20260419] WHERE Point is not null

