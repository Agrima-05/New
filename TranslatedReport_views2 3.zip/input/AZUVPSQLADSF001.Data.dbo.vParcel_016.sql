SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vParcel_016]
AS
SELECT
		[FIPS]
      ,[PropertyID]
      ,[FormattedAPN]
      ,[SitusStdFullStreetAddress]
      ,[SitusStdHouseNbr]
      ,[SitusStdHouseNbrSuffix]
      ,[SitusStdDirectionLeft]
      ,[SitusStdStreet]
      ,[SitusStdMode]
      ,[SitusStdDirectionRight]
      ,[SitusStdUnitType]
      ,[SitusStdUnitNbr]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusStdCarrierCode]
      ,[FALatitude]
      ,[FALongitude]
      ,[FAGeoStatusCode]
      ,[Geom]
      ,[FATimestamp]
      ,[FAUCIDFlag]
      ,[FAPropertyBoundaryID]
      ,[DTDB_FORMATTED_APN]
      ,[DTDB_UNFORMATTED_APN]
      ,[GeomSpatial]



FROM OPENQUERY(
    [AZUVNSQLDTDB016], 
    'Select * FROM [DigitalMap].[dbo].[vParcelBoundaryAll_TOOL_USE] d  with(nolock)'
    );

 


GRANT SELECT ON [dbo].[vParcel_016] TO [CORP\cbrady] AS [dbo]
