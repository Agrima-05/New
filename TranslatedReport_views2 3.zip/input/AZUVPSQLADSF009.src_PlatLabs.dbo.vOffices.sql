SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

 Create view [src_PlatLabs].[dbo].[vOffices] 
 as
 ---- PHOTO LINKS WITH REF_ID

	 SELECT [uid]
      ,[dp_mls_id]
      ,[mls_id]
      ,[dp_office_id]
      ,[active]
      ,[last_update_date]
      ,[mls_create_date]
      ,[mls_update_date]
      ,[franchise_affiliation]
      ,[address]
      ,[city]
      ,[zip]
      ,[state]
      ,[email]
      ,[fax]
      ,[mlskey]
      ,[license_number]
      ,[short_name]
      ,[full_name]
      ,[nrds_id]
      ,[office_status_date]
      ,[type]
      ,[website]
      ,[status]
      ,[phone]
      ,[originating_system_id]
      ,[originating_system_name]
      ,[subsystem_locale]
      ,[system_locale]
      ,[primary_association]
      ,[parent_org_id]
      ,[LoadDate]
	 from Office.Platlabs_Offices a with(NOLOCK) 
	 WHERE mls_id in(Select mls_id from platlabs_update_config where code like '%_39' and active = '1')



