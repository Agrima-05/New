SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [src_DoOrDiE].[dbo].[SI_MTG_BORROWER_DTDB]
AS
Select * from src_DoOrDiE.dbo.SI_MTG_BORROWER 
WHERE RecordingDocumentNumber in(Select distinct DeedID from [dbo].[SI_MTG_DTDB])


