SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [AgentKey].[dbo].[vMasterDRE_Tim]
AS

SELECT a.[State]
      ,[License_Type]
      ,[License_Number]
      ,[License_Status]
      ,[Original_License_Date]
      ,[Expiration_License_Date]
      ,[License_First]
      ,[License_Middle]
      ,[License_Last]
      ,[License_suffix]
      ,[License_FullName]
      ,[License_Email]
      ,[License_Telephone]
      ,[Telephone_Type]
      ,[2nd_License_Telephone]
      ,[2nd_Telephone_Type]
      ,[3rd_License_Telephone]
      ,[3rd_Telephone_Type]
      ,[License_Address_1]
      ,[License_Address_2]
      ,[License_City]
      ,[License_State]
      ,[License_Zip]
      ,[License_County]
      ,[License_Full_Address]
      ,[Office_Name]
      ,[Office_Address_1]
      ,[Office_Address_2]
      ,[Office_City]
      ,[Office_State]
      ,[Office_Zip]
      ,[Office_County]
      ,[Office_Full_Address]
      ,[Office_License_Number]
      ,[Office_License_Status]
      ,[Office_Original_License_Date]
      ,[Office_Expiration_License_Date]
      ,[Office_License_Type]
      ,[Office_Broker_License]
      ,[Entity_Legal_Name]
      ,[LoadDate]
      ,[UniqueID]
      ,[FileType]
      ,[Comments]
	  ,b.[FIPS]
	  ,b.[REF_ID]
	  ,[FullStreetAddress] as NormalizedAddress
	  ,[City] as NormalizedCity
	  ,b.[State] as NormalizedState
	  ,[Zip] as NormalizedZip
	  ,p.StdLandUseCode
	  ,p.PropertyClassID

  FROM AgentKey.[dbo].[MasterDRE] a LEFT OUTER JOIN [ASP_Offcycle].[addr].[StandardizedAddress_DRE] b
  on replace(a.[State] + '_' + [License_Type] + '_' + [License_Number],' ','') = RAW_ID
  LEFT OUTER JOIN zCust_ADS__00_SharedProcs.dbo.Property p with(NOLOCK) on p.PropertyID = b.PropertyID



