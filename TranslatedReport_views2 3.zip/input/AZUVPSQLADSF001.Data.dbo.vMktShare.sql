SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vMktShare]
AS

/*--------------------------------------------------          FROM DEED          ---------------------------------------------------*/ 

SELECT D.FIPS as FIPS
, D.TransactionId as TransactionID
, D.FAPropertyId as PropertyID
, Coalesce(case when P.SitusStdCity like '' then null else P.SitusStdCity end,case when D.SitusStdCity like '' then null else D.SitusStdCity end,case when D.LegalCityMuniTownship like '' then null else D.LegalCityMuniTownship end) as City
, CASE WHEN isNULL(P.SitusStdZip5,'') like '' THEN D.SitusStdZip5 ELSE P.SitusStdZip5 END as Zipcode
, P.[SitusCensusTract] as CensusTract
, Buyer1FullName + CASE WHEN IsNULL(Buyer2FullName,'') not like '' then ' & ' + Buyer2FullName Else '' End as BuyerBorrowerName
, CASE WHEN D.[Buyer1NoParsInd] = 1 THEN 'YES' ELSE 'NO' END as BuyerBorrowerCorp
, D.BuyerVestingCode as RightsCode
, i.CodeDesc as BuyerBorrowerRightsDesc
, D.[Armslength] as ArmslengthFlag
, D.RecordingDt as RecordingDate
, SaleDate as SaleDate
, t.[FA_YearDocNbrFmt] as DeedDocNbr
, t.[FA_BookPageFmt] as DeedBkPg
, DocumentTypeCode as DeedDocType
, b.CodeDesc as DeedDocTypeDesc
, DeedTransactionType as DeedTransType
, c.CodeDesc as DeedTransTypeDesc
, Seller1FullName as SellerName
, CASE WHEN [Seller1NoParsInd] = 1 THEN 'YES' ELSE 'NO' END as SellerCorp
, SalesPrice as SaleAmount
, CASE WHEN [ResaleInd] = 1 THEN 'Y' ELSE NULL END as ResaleFlag
, CASE WHEN [NewConstructionInd] = 1 THEN 'Y' ELSE NULL END as NewConstFlag
, CASE WHEN InterFamilyTransfer = 1 THEN 'Y' ELSE NULL END as InterFamilyFlag
, CASE WHEN [Reo] = 1 THEN 'Y' ELSE NULL END as ForeclosureFlag
, CASE WHEN [REOSale] = 1 THEN 'Y' ELSE NULL END as REOSaleFlag
, [Loan1TransactionID] as Loan1TransactionId
, D.Loan1Type as Loan1Type
, e.CodeDesc as Loan1TypeDesc
, [Loan1RecordingDt] as Loan1RecordingDate
, CASE WHEN Loan1Amount > 0 THEN Saledate ELSE NULL END as Loan1ContractDate
, [FA_YearDocNbrFmt_II] as Loan1DocumentNbr
, [FA_BookPageFmt_II] as Loan1BkPg
, Loan1DocumentTypeCode as Loan1DocTypeCode
, g.CodeDesc as LoanDocTypeDesc
, Loan1Amount as Loan1Amount
, Replace(Replace([Loan1LenderName ], ',',''), '.','') as Loan1LenderName
, [Loan1LenderTypeCode] as Loan1LenderTypeCode
, Loan1TransType as Loan1TransType
, c.CodeDesc as LoanTransTypeDesc
, [Loan1TermMonths] as Loan1TermMonths
, Loan1DueDate as Loan1DueDate
, [Loan1TypeFinance] as Loan1TypeFinance
, NULL as Loan1RefiFlag
, NULL as Loan1EquityFlag
, NULL as Loan1HelocFlag
, [Loan2TransactionID] as Loan2TransactionID
, D.Loan2Type as Loan2Type
, f.CodeDesc as Loan2TypeDesc
, Loan2RecordingDt  as Loan2RecordingDate
, CASE WHEN Loan2RecordingDt IS NOT NULL THEN SaleDate ELSE NULL END as Loan2ContractDate
, [FA_YearDocNbrFmt_III] as Loan2DocumentNbr
, [FA_BookPageFmt_III] as Loan2BkPg
, [Loan2DocumentTypeCode] as Loan2DocTypeCode
, h.CodeDesc as Loan2DocTypeDesc
, Loan2Amount as Loan2Amount
, Loan2LenderName as Loan2LenderName
, Loan2LenderTypeCode as Loan2LenderTypeCode
, Loan2TransType as Loan2TransType
, [Loan2TermMonths] as Loan2TermMonths
, Loan2DueDate as Loan2DueDate
, [Loan2TypeFinance] as Loan2TypeFinance
, TitleCompanyName as TitleCoName
, D.FAUCIDFlag as UCID
, D.FATimeStamp as Timestamp
, P.[PropertyCLassID] as PropClass
, P.StdLandUseCode as LandUse
, D.[CMTID] as DeedCMITD
, D.[CMTIDInstNbr] as DEEDCMTIDInstNbr
, D.[Loan1CMTID] as Loan1CMTID
, D.[Loan1CMTIDInstNbr] as Loan1CMTIDInstNbr
, D.[Loan2CMTID] as Loan2CMTID
, D.[Loan2CMTIDInstNbr] as Loan2CMTIDInstNbr
FROM Data.dbo.Deed D with(NOLOCK) JOIN [Global].dbo.[Transaction_Master] t with(NOLOCK) on d.Fips = t.Fips and d.TransactionID = t.TransactionID
	LEFT OUTER JOIN Data.dbo.Property P with(NOLOCK) on D.FIPS = P.FIPS and D.FAPropertyID = P.PropertyID
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] b with(NOLOCK) on d.[DocumentTypeCode] = b.[DocTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Trans_Type] c with(NOLOCK) on d.[DeedTransactionType] = c.[TransType]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] e with(NOLOCK) on d.[Loan1Type] = e.[LoanTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] f with(NOLOCK) on d.[Loan2Type] = f.[LoanTypeID]
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] g with(NOLOCK) on d.[Loan1DocumentTypeCode] = g.[DocTypeID]
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] h with(NOLOCK) on d.[Loan2DocumentTypeCode] = h.[DocTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Buy_Vesting] i with(NOLOCK) on d.[BuyerVestingCode] = i.[BuyVestingId]
WHERE d.RecordingDt > '20170101' 
	--and isNULL([Loan1CMTIDInstNbr],'') not like '' 
		and d.FAUCIDFlag != 'D' and t.FileType = 'D'

UNION ALL

/*--------------------------------------------------          FROM MORTGAGE          ---------------------------------------------------*/  

SELECT M.FIPS AS FIPS
, M.TransactionId as TransactionID
, M.FAPropertyId as PropertyID
, Coalesce(case when P.SitusStdCity like '' then null else P.SitusStdCity end,case when M.SitusCity like '' then null else M.SitusCity end,case when M.[LegalCityMunicipalityTownship] like '' then null else M.[LegalCityMunicipalityTownship] end) as City
, CASE WHEN isNULL(P.SitusStdZip5,'') like '' THEN M.SitusZip5 ELSE P.SitusStdZip5 END as Zipcode
,P.[SitusCensusTract] as CensusTract
, Borrower1FullName + CASE WHEN IsNULL(Borrower2FullName,'') not like '' then ' & ' + Borrower2FullName Else '' End as BuyerBorrowerName
, CASE WHEN [Borrower1NoParsInd] = 1 THEN 'YES' ELSE 'NO' END as BuyerBorrowerCorp
, BorrowerVestingCode as RightsCode
, i.CodeDesc as BuyerBorrowerRightsDesc
, NULL as ArmslengthFlag
, M.RecordingDt as RecordingDate
, M.ContractDate as SaleDate
, NULL as DeedDocNbr
, NULL as DeedBkPg
, NULL as DeedDocType
, NULL as DeedDocTypeDesc
, NULL as DeedTransType
, NULL as DeedTransTypeDesc
, NULL as SellerName
, NULL as SellerCorp
, NULL as SaleAmount
, NULL as ResaleFlag
, NULL as NewConstFlag
, NULL as InterFamilyFlag
, NULL as ForeclosureFlag
, NULL as REOSaleFlag
, M.TransactionId as Loan1TransactionId
, LoanType as Loan1Type
, e.CodeDesc as Loan1TypeDesc
, M.RecordingDt as Loan1RecordingDate
, M.ContractDate as Loan1ContractDate
, t.[FA_YearDocNbrFmt] as Loan1DocumentNbr
, t.[FA_BookPageFmt] as Loan1BkPg
, DocumentTypeCode as Loan1DocTypeCode
, b.CodeDesc as LoanDocTypeDesc
, LoanAmount as Loan1Amount
, Replace(Replace([LenderName], ',', ''), '.', '')  as Loan1LenderName
, [LenderCode] as Loan1LenderTypeCode
, LoanTransType as Loan1TransType
, c.CodeDesc as LoanTransTypeDesc
, [LoanTermMonths]  as Loan1TermMonths
, LoanDueDate as Loan1DueDate
, [TypeFinance] as Loan1TypeFinance
, [LoanRefiLoanInd] as Loan1RefiFlag
, [LoanEquityLoanInd] as Loan1EquityFlag
, [LoanHELOCLoanInd] as Loan1HelocFlag
, NULL as Loan2TransactionID
, NULL as Loan2Type
, NULL as Loan2TypeDesc
, NULL as Loan2RecordingDate
, NULL as Loan2ContractDate
, NULL as Loan2DocumentNbr
, NULL as Loan2BkPg
, NULL as Loan2DocTypeCode
, NULL as Loan2DocTypeDesc
, NULL as Loan2Amount
, NULL as Loan2LenderName
, NULL as Loan2LenderTypeCode
, NULL as Loan2TransType
, NULL as Loan2TermMonths
, NULL as Loan2DueDate
, NULL as Loan2TypeFinance
, TitleCompanyName as TitleCoName
, M.FAUCIDFlag as UCID
, M.FATimeStamp as [Timestamp]
,P.[PropertyCLassID] as PropClass
,P.StdLandUseCode as LandUse
,NULL DeedCMITD
,NULL DEEDCMTIDInstNbr
,M.[CMTID] as Loan1CMTID
,M.[CMTIDInstNbr] as Loan1CMTIDInstNbr
,NULL as Loan2CMTID
,NULL as Loan2CMTIDInstNbr
FROM  mortgage as M  with(NOLOCK) JOIN [Global].dbo.[Transaction_Master] t with(NOLOCK) on m.Fips = t.Fips and m.TransactionID = t.TransactionID
	LEFT OUTER JOIN  Data.dbo.Property as P with(NOLOCK) on M.FIPS = P.FIPS and M.FAPropertyID = P.PropertyID
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] b on m.[DocumentTypeCode] = b.[DocTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Trans_Type] c on m.[TransactionType] = c.[TransType]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] e on m.[LoanType] = e.[LoanTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] f on m.[LoanType] = f.[LoanTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Buy_Vesting] i with(NOLOCK) on [BorrowerVestingCode] = i.[BuyVestingId]
WHERE m.RecordingDt > '20170101' 
	--and isNULL(M.[CMTIDInstNbr],'') NOT LIKE '' 
		and M.FAUCIDFlag != 'D' and t.FileType = 'M'


UNION ALL

/*--------------------------------------------------          FROM DEED_SUP          ---------------------------------------------------*/ 

SELECT D.FIPS as FIPS
, D.TransactionId as TransactionID
, D.FAPropertyId as PropertyID
, Coalesce(case when P.SitusStdCity like '' then null else P.SitusStdCity end,case when D.SitusStdCity like '' then null else D.SitusStdCity end,case when D.LegalCityMuniTownship like '' then null else D.LegalCityMuniTownship end) as City
, CASE WHEN isNULL(P.SitusStdZip5,'') like '' THEN D.SitusStdZip5 ELSE P.SitusStdZip5 END as Zipcode
, P.[SitusCensusTract] as CensusTract
, Buyer1FullName + CASE WHEN IsNULL(Buyer2FullName,'') not like '' then ' & ' + Buyer2FullName Else '' End as BuyerBorrowerName
, CASE WHEN D.[Buyer1NoParsInd] = 1 THEN 'YES' ELSE 'NO' END as BuyerBorrowerCorp
, D.BuyerVestingCode as RightsCode
, i.CodeDesc as BuyerBorrowerRightsDesc
, D.[Armslength] as ArmslengthFlag
, D.RecordingDt as RecordingDate
, SaleDate as SaleDate
, t.[FA_YearDocNbrFmt] as DeedDocNbr
, t.[FA_BookPageFmt] as DeedBkPg
, DocumentTypeCode as DeedDocType
, b.CodeDesc as DeedDocTypeDesc
, DeedTransactionType as DeedTransType
, c.CodeDesc as DeedTransTypeDesc
, Seller1FullName as SellerName
, CASE WHEN [Seller1NoParsInd] = 1 THEN 'YES' ELSE 'NO' END as SellerCorp
, SalesPrice as SaleAmount
, CASE WHEN [ResaleInd] = 1 THEN 'Y' ELSE NULL END as ResaleFlag
, CASE WHEN [NewConstructionInd] = 1 THEN 'Y' ELSE NULL END as NewConstFlag
, CASE WHEN InterFamilyTransfer = 1 THEN 'Y' ELSE NULL END as InterFamilyFlag
, CASE WHEN [Reo] = 1 THEN 'Y' ELSE NULL END as ForeclosureFlag
, CASE WHEN [REOSale] = 1 THEN 'Y' ELSE NULL END as REOSaleFlag
, [Loan1TransactionID] as Loan1TransactionId
, D.Loan1Type as Loan1Type
, e.CodeDesc as Loan1TypeDesc
, [Loan1RecordingDt] as Loan1RecordingDate
, CASE WHEN Loan1Amount > 0 THEN Saledate ELSE NULL END as Loan1ContractDate
, [FA_YearDocNbrFmt_II] as Loan1DocumentNbr
, [FA_BookPageFmt_II] as Loan1BkPg
, Loan1DocumentTypeCode as Loan1DocTypeCode
, g.CodeDesc as LoanDocTypeDesc
, Loan1Amount as Loan1Amount
, Replace(Replace([Loan1LenderName ], ',',''), '.','') as Loan1LenderName
, [Loan1LenderTypeCode] as Loan1LenderTypeCode
, Loan1TransType as Loan1TransType
, c.CodeDesc as LoanTransTypeDesc
, [Loan1TermMonths] as Loan1TermMonths
, Loan1DueDate as Loan1DueDate
, [Loan1TypeFinance] as Loan1TypeFinance
, NULL as Loan1RefiFlag
, NULL as Loan1EquityFlag
, NULL as Loan1HelocFlag
, [Loan2TransactionID] as Loan2TransactionID
, D.Loan2Type as Loan2Type
, f.CodeDesc as Loan2TypeDesc
, Loan2RecordingDt  as Loan2RecordingDate
, CASE WHEN Loan2RecordingDt IS NOT NULL THEN SaleDate ELSE NULL END as Loan2ContractDate
, [FA_YearDocNbrFmt_III] as Loan2DocumentNbr
, [FA_BookPageFmt_III] as Loan2BkPg
, [Loan2DocumentTypeCode] as Loan2DocTypeCode
, h.CodeDesc as Loan2DocTypeDesc
, Loan2Amount as Loan2Amount
, Loan2LenderName as Loan2LenderName
, Loan2LenderTypeCode as Loan2LenderTypeCode
, Loan2TransType as Loan2TransType
, [Loan2TermMonths] as Loan2TermMonths
, Loan2DueDate as Loan2DueDate
, [Loan2TypeFinance] as Loan2TypeFinance
, TitleCompanyName as TitleCoName
, D.FAUCIDFlag as UCID
, D.FATimeStamp as Timestamp
, P.[PropertyCLassID] as PropClass
, P.StdLandUseCode as LandUse
, D.[CMTID] as DeedCMITD
, D.[CMTIDInstNbr] as DEEDCMTIDInstNbr
, D.[Loan1CMTID] as Loan1CMTID
, D.[Loan1CMTIDInstNbr] as Loan1CMTIDInstNbr
, D.[Loan2CMTID] as Loan2CMTID
, D.[Loan2CMTIDInstNbr] as Loan2CMTIDInstNbr
FROM deed_sup D  with(NOLOCK) 	JOIN [Global].dbo.[Transaction_Master] t with(NOLOCK) on d.Fips = t.Fips and d.TransactionID = t.TransactionID
	LEFT OUTER JOIN  Data.dbo.Property as P with(NOLOCK) on D.FIPS = P.FIPS and d.FAPropertyID = P.PropertyID
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] b on d.[DocumentTypeCode] = b.[DocTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Trans_Type] c on d.[DeedTransactionType] = c.[TransType]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] e on d.[Loan1Type] = e.[LoanTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] f on d.[Loan2Type] = f.[LoanTypeID]
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] g with(NOLOCK) on d.[Loan1DocumentTypeCode] = g.[DocTypeID]
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] h with(NOLOCK) on d.[Loan2DocumentTypeCode] = h.[DocTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Buy_Vesting] i with(NOLOCK) on d.[BuyerVestingCode] = i.[BuyVestingId]
WHERE d.RecordingDt > '20170101' 
	--and isNULL(d.[Loan1CMTIDInstNbr],'') NOT LIKE '' 
		and d.FAUCIDFlag != 'D' and t.FileType = 'D'




UNION ALL

/*--------------------------------------------------          FROM MORTGAGE_SUP          ---------------------------------------------------*/  

SELECT M.FIPS AS FIPS
, M.TransactionId as TransactionID
, M.FAPropertyId as PropertyID
, Coalesce(case when P.SitusStdCity like '' then null else P.SitusStdCity end,case when M.SitusCity like '' then null else M.SitusCity end,case when M.[LegalCityMunicipalityTownship] like '' then null else M.[LegalCityMunicipalityTownship] end) as City
, CASE WHEN isNULL(P.SitusStdZip5,'') like '' THEN M.SitusZip5 ELSE P.SitusStdZip5 END as Zipcode
, P.[SitusCensusTract] as CensusTract
, Borrower1FullName + CASE WHEN IsNULL(Borrower2FullName,'') not like '' then ' & ' + Borrower2FullName Else '' End as BuyerBorrowerName
, CASE WHEN [Borrower1NoParsInd] = 1 THEN 'YES' ELSE 'NO' END as BuyerBorrowerCorp
, BorrowerVestingCode as RightsCode
, i.CodeDesc as BuyerBorrowerRightsDesc
, NULL as ArmslengthFlag
, M.RecordingDt as RecordingDate
, M.ContractDate as SaleDate
, NULL as DeedDocNbr
, NULL as DeedBkPg
, NULL as DeedDocType
, NULL as DeedDocTypeDesc
, NULL as DeedTransType
, NULL as DeedTransTypeDesc
, NULL as SellerName
, NULL as SellerCorp
, NULL as SaleAmount
, NULL as ResaleFlag
, NULL as NewConstFlag
, NULL as InterFamilyFlag
, NULL as ForeclosureFlag
, NULL as REOSaleFlag
, M.TransactionId as Loan1TransactionId
, LoanType as Loan1Type
, e.CodeDesc as Loan1TypeDesc
, M.RecordingDt as Loan1RecordingDate
, M.ContractDate as Loan1ContractDate
, t.[FA_YearDocNbrFmt] as Loan1DocumentNbr
, t.[FA_BookPageFmt] as Loan1BkPg
, DocumentTypeCode as Loan1DocTypeCode
, b.CodeDesc as LoanDocTypeDesc
, LoanAmount as Loan1Amount
, Replace(Replace([LenderName], ',', ''), '.', '')  as Loan1LenderName
, [LenderCode] as Loan1LenderTypeCode
, LoanTransType as Loan1TransType
, c.CodeDesc as LoanTransTypeDesc
, [LoanTermMonths]  as Loan1TermMonths
, LoanDueDate as Loan1DueDate
, [TypeFinance] as Loan1TypeFinance
, [LoanRefiLoanInd] as Loan1RefiFlag
, [LoanEquityLoanInd] as Loan1EquityFlag
, [LoanHELOCLoanInd] as Loan1HelocFlag
, NULL as Loan2TransactionID
, NULL as Loan2Type
, NULL as Loan2TypeDesc
, NULL as Loan2RecordingDate
, NULL as Loan2ContractDate
, NULL as Loan2DocumentNbr
, NULL as Loan2BkPg
, NULL as Loan2DocTypeCode
, NULL as Loan2DocTypeDesc
, NULL as Loan2Amount
, NULL as Loan2LenderName
, NULL as Loan2LenderTypeCode
, NULL as Loan2TransType
, NULL as Loan2TermMonths
, NULL as Loan2DueDate
, NULL as Loan2TypeFinance
, TitleCompanyName as TitleCoName
, M.FAUCIDFlag as UCID
, M.FATimeStamp as [Timestamp]
,P.[PropertyCLassID] as PropClass
,P.StdLandUseCode as LandUse
,NULL DeedCMITD
,NULL DEEDCMTIDInstNbr
,M.[CMTID] as Loan1CMTID
,M.[CMTIDInstNbr] as Loan1CMTIDInstNbr
,NULL as Loan2CMTID
,NULL as Loan2CMTIDInstNbr
FROM mortgage_sup M with(NOLOCK)  JOIN [Global].dbo.[Transaction_Master] t with(NOLOCK) on m.Fips = t.Fips and m.TransactionID = t.TransactionID
	LEFT OUTER JOIN  Data.dbo.Property as P with(NOLOCK) on M.FIPS = P.FIPS and M.FAPropertyID = P.PropertyID
	LEFT OUTER JOIN [Global].dbo.[lkup_Doc_Type_AD] b on m.[DocumentTypeCode] = b.[DocTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Trans_Type] c on m.[TransactionType] = c.[TransType]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] e on m.[LoanType] = e.[LoanTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Loan_Type] f on m.[LoanType] = f.[LoanTypeID]
	LEFT OUTER JOIN [Global].[dbo].[lkup_Buy_Vesting] i with(NOLOCK) on [BorrowerVestingCode] = i.[BuyVestingId]
WHERE m.RecordingDt > '20170101' 
	--and isNULL(M.[CMTIDInstNbr],'') NOT LIKE '' 
		and M.FAUCIDFlag != 'D' and t.FileType = 'M'




















GRANT SELECT ON [dbo].[vMktShare] TO [CORP\cbrady] AS [dbo]
