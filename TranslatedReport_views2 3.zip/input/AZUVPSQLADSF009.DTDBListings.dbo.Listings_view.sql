SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create VIEW [DTDBListings].[dbo].[Listings_view]
AS
	SELECT * 
	FROM [src_PlatLabs].[dbo].vStdLayout
	
	

