SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON






CREATE VIEW [Data].[dbo].[vDeedMortgageSTD2_20171205]
AS
SELECT       D.FIPS AS FIPS, D.FAPropertyId AS PROPERTYUNIQUEID, D.APN AS APN, NULL AS APNSEQUENCENBR, NULL AS PREVIOUSPARCELNUMBER, D.TaxAccountNbr AS TAXACCOUNTNUMBER, D.FAMatchInd AS MatchedFlag, D.
                         SitusStdHouseNbr AS HOUSENUMBER, D.SitusStdHouseNbr2 AS HOUSENUMBER2, D.SitusStdHouseNbrSuffix AS HOUSENUMBERSUFFIX, D.SitusStdDirectionLeft AS DIRECTIONLEFT, D.SitusStdStreet AS STREETNAME,
                          D.SitusStdMode AS Suffix, D.SitusStdDirectionRight AS DIRECTIONRIGHT, D.SitusStdUnitType AS UNITTYPE, D.SitusStdUnitNbr AS UNITNUMBER, D.SitusStdCity AS CITY, D.SitusStdState AS STATE, D.
                         SitusStdZIP5 AS ZIPCODE, D.SitusStdZip4 AS ZIPPLUS4, D.SitusStdCarrierCode AS CARRIERCODE, CASE WHEN [Buyer1NoParsInd] = 1 THEN 'Y' ELSE NULL END AS CORPORATEINDICATOR, D.
                         Buyer1FullName AS BUYERNAMEBORROWERNAME1, D.BuyerNameAddendum AS OWNERETALIND, D.BuyerMailCareOfName AS OwnerCAREOfNAME, D.BuyerVestingCode AS OWNERSHIPRIGHTSCODE1, D.
                         Buyer1IDCode AS OWNERRELATIONSHIPTYPE1, D.Buyer2NoParsInd AS CORPORATEINDICATOR2, D.Buyer2FullName AS BUYERNAMEBORROWERNAME2, NULL AS OWNERSHIPRIGHTSCODE2, D.
                         Buyer2IDCode AS OWNERRELATIONSHIPTYPE2, Buyer1LastName AS BUYER1LASTNAME, Buyer1FirstName AS BUYER1FIRSTNAME, Buyer1MiddleInitial AS BUYER1MIDDLEName, 
                         Buyer1NameSiffix AS BUYER1SUFFIX, Buyer2LastName AS BUYER2LASTNAME, Buyer2FirstName AS BUYER2FIRSTNAME, Buyer2MiddleInitial AS BUYER2MIDDLEName, 
                         Buyer2NameSuffix AS BUYER2SUFFIX, BuyerMailHouseNbr AS MAILHOUSENUMBER, BuyerMailHouseNbr2 AS MAILHOUSENUMBER2, BuyerMailHouseNbrSuffix AS MAILHOUSENUMBERSUFFIX, 
                         BuyerMailLeftDirection AS MAILDIRECTIONLEFT, BuyerMailStreetName AS MAILSTREETNAME, BuyerMailMode AS MAILMODE, BuyerMailRightDirection AS MAILDIRECTIONRIGHT, 
                         BuyerMailUnitType AS MAILUNITTYPE, BuyerMailUnitNumber AS MAILUNITNUMBER, BuyerMailCity AS MAILCITY, BuyerMailState AS MAILSTATE, BuyerMailZip5 AS MAILZIPCODE, 
                         BuyerMailZip4 AS MAILZIPPlus4, BuyerMailCarrierCode AS MAILCARRIERCODE, TransactionId AS FirstAmericanUniqueTransactionID, RecordingDt AS RECORDINGDATE, SaleDate AS SALEDATE, 
                         DocNbrSrce AS DOCUMENTNUMBER, BookSrce AS RECORDINGBOOK, PageSrce AS RECORDINGPAGE, HILandCountDocumentNbr AS HAWAIILANDCOURTDOCUMENTNUMBER, 
                         HICertificateNbr AS HAWAIITCTCERTIFICATENUMBER, WaExciseNbr AS WAEXCISENUMBER, DocumentTypeCode AS DOCUMENTTYPE, DeedTransactionType AS TRANSACTIONTYPE, 
                         Substring(ltrim(rtrim(Ltrim(Rtrim(CASE WHEN [Seller1LastNameOrCorpName] IS NULL THEN '' ELSE [Seller1LastNameOrCorpName] END)) + ' ' + ltrim(rtrim(CASE WHEN [Seller1FirstNameMiddlename] IS NULL 
                         THEN '' ELSE [Seller1FirstNameMiddlename] END)))), 1, 60) AS SELLERNAME, CASE WHEN ([Seller1LastNameOrCorpName] IS NOT NULL AND [Seller1FirstNameMiddlename] IS NULL) THEN 'Y' ELSE NULL 
                         END AS SELLERNAMECORPINDICATOR, Substring(ltrim(rtrim(Ltrim(Rtrim(CASE WHEN [Seller2LastNameOrCorpName] IS NULL THEN '' ELSE [Seller2LastNameOrCorpName] END)) 
                         + ' ' + ltrim(rtrim(CASE WHEN [Seller2FirstNameMiddlename] IS NULL THEN '' ELSE [Seller2FirstNameMiddlename] END)))), 1, 60) AS SELLERNAME2, CASE WHEN ([Seller2LastNameOrCorpName] IS NOT NULL 
                         AND [Seller2FirstNameMiddlename] IS NULL) THEN 'Y' ELSE NULL END AS SELLERNAME2CORPINDICATOR, SalesPrice AS SALEAMOUNT, 
						
						  ------20161208 - Changed to cascade Tax fields per BR - KL
						 case 
						 when (TaxTotalTransferTax is null or TaxTotalTransferTax = 0) and (TaxCountyTransferTax is null or TaxCountyTransferTax = 0) then TaxCityTransferTax
						 when (TaxTotalTransferTax is null or TaxTotalTransferTax = 0) and (TaxCountyTransferTax >= 0) then TaxCountyTransferTax
						 else TaxTotalTransferTax end

						  AS TRANSFERTAX, 
						 --TaxTotalTransferTax AS TRANSFERTAX,  
                         
						 
						 
						 PartialInterestTransferred AS PARTIALINTERESTINDICATORFLAG, CASE WHEN [ResaleInd] = 1 THEN 'Y' ELSE NULL END AS RESALEFLAG, CASE WHEN [NewConstructionInd] = 1 THEN 'Y' ELSE NULL 
                         END AS NEWCONSTRUCTIONFLAG, CASE WHEN substring([Seller2LastNameOrCorpName], 1, 4) LIKE substring(Buyer1FullName, 1, 4) THEN 'Y' ELSE NULL 
                         END AS INTERFAMILYFLAG/*,Case when [InterFamilyTransfer] = 1 then 'Y' else null end as INTERFAMILYFLAG*/ , CASE WHEN [Reo] = 1 THEN 'Y' ELSE NULL END AS FORCLOSUREFLAG, 
                         CASE WHEN [REOSale] = 1 THEN 'Y' ELSE NULL END AS REOSALEFLAG, CASE WHEN Loan1Amount > 0 THEN RecordingDt ELSE NULL END AS FIRSTMORTGAGERECORDINGDATE, 
                         CASE WHEN Loan1Amount > 0 THEN Saledate ELSE NULL END AS FIRSTMORTGAGEDOCDATE, CASE WHEN Loan1Document LIKE '%/%' THEN NULL 
                         ELSE Loan1Document END AS FIRSTMORTGAGEDOCUMENTNUMBER, CASE WHEN Loan1Document LIKE '%/%' THEN substring(Loan1Document, 1, (Charindex('/', Loan1Document) - 1)) 
                         ELSE '' END AS FIRSTMORTGAGERECORDINGBOOK, CASE WHEN Loan1Document LIKE '%/%' THEN substring(Loan1Document, (Charindex('/', Loan1Document) + 1), 20) 
                         ELSE '' END AS FIRSTMORTGAGERECORDINGPAGE, CASE WHEN Loan1Amount > 0 THEN 'MG' ELSE NULL END AS FIRSTMORTGAGEDETAILEDDOCUMENTTYPE, 
                         Loan1Amount AS FIRSTMORTGAGEMORTGAGEAMOUNT, Replace(Replace([Loan1LenderName ], ',',''), '.','') AS FIRSTMORTGAGELENDERNAME
						 --, Loan1TransType AS FIRSTMORTGAGELOANTYPECODE
						 ,Case when [loan1transtype] = '6' then '1'
								when [loan1transtype] = '7' then '2'
								when [loan1transtype] = '8' then '3'
								when [loan1transtype] = '9' then '4'
								when [loan1transtype] = '10' then '5'
								when [loan1transtype] = '11'then '6'
						 end as FIRSTMORTGAGELOANTYPECODE
						 ,CASE WHEN [Loan1DueDate] IS NOT NULL THEN 'M' ELSE NULL END AS FIRSTMORTGAGETERMCODE, CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 
                         350 AND 365 THEN '360' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 230 AND 250 THEN '240' WHEN (datediff(mm, cast(RecordingDt AS date), 
                         cast(Loan1DueDate AS date)) - 1) BETWEEN 118 AND 122 THEN '120' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 175 AND 185 THEN '180' WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 10 AND 13 THEN '12' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 22 AND 
                         26 THEN '24' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 32 AND 39 THEN '36' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) 
                         BETWEEN 57 AND 62 THEN '60' ELSE (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) END AS FIRSTMORTGAGETERM, Loan1DueDate AS FIRSTMORTGAGEDUEDATE, 
                        --------------Removed 20151104 due to population of FA values vs BK------------
						 ---CASE WHEN [Loan1TypeFinance] = '1' THEN 'ADJ' WHEN [Loan1TypeFinance] = '2' THEN 'FIX' WHEN [Loan1TypeFinance] = '3' THEN 'MUL' WHEN [Loan1TypeFinance] = '4' THEN 'OTH' WHEN [Loan1TypeFinance]
                         --- = '5' THEN 'STP' WHEN [Loan1TypeFinance] = '6' THEN 'UNK' WHEN [Loan1TypeFinance] = '7' THEN 'VAR' END AS FIRSTMORTGAGEINTERESTRATETYPE
						 CASE WHEN  [Loan1TypeFinance] = 'MULT' THEN 'MUL' ELSE [Loan1TypeFinance] END AS FIRSTMORTGAGEINTERESTRATETYPE

						 ,format([Loan1InterestRate], '00000')  AS FIRSTMORTGAGEINTERESTRATE, CASE WHEN [Loan1LenderTypeCode] = 'S' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGESELLERCARRYBACKFLAG, 
                         CASE WHEN [Loan1LenderTypeCode] = 'P' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGEPRIVATEPARTYLENDER, CASE WHEN [Loan1Type] = '8' THEN 'Y' ELSE NULL 
                         END AS FIRSTMORTGAGECONSTRUCTIONLOAN, 
						NULL FIRSTMORTGAGEREFIFLAG --Changed to null 3/10/2016 CB
						 , NULL AS FIRSTMORTGAGEEQUITYFLAG, NULL 
                         AS FIRSTMORTGAGEHELOCFLAG,Loan1SubordinateLoanInd AS FIRSTMORTGAGEOTHERSUBORDINATELOANFlag, SecondHomeRider AS FIRSTMORTGAGESecondHomeRider, 
                         CondominiumRider AS FIRSTMORTGAGECondominiumRider, MultiFamily4Rider AS FIRSTMORTGAGEMultiFamily4Rider, PlannedUnitDevelopmentRider AS FIRSTMORTGAGEPlannedUnitDevelopmentRider, 
                         Loan1AssumabilityRider AS FIRSTMORTGAGEAssumabilityRider, Loan1BalloonRider AS FIRSTMORTGAGEBalloonRider, Loan1BiweeklyPaymentRider AS FIRSTMORTGAGEBiweeklyPaymentRider, 
                         Loan1FixedStepRateRider AS FIRSTMORTGAGEFixedStepRateRider, Loan1GraduatedPaymentRider AS FIRSTMORTGAGEGraduatedPaymentRider, Loan1PrePaymentRider AS FIRSTMORTGAGEPrepaymentRider, 
                         Loan1RateImprovementRider AS FIRSTMORTGAGERateImprovementRider, Loan1AdjRateRider AS FIRSTMORTGAGEAdjustableRateRider, Loan1AdjRateIndex AS FIRSTMORTGAGEAdjustableRateIndex, 
                         Loan1ChangeIndex AS FIRSTMORTGAGEChangeIndex, Loan1FirstChangeDateMMDD AS FIRSTMORTGAGEFirstChangeDateMonthDay, Loan1FirstChangeDateYYYY AS FIRSTMORTGAGEFirstChangeDateYear, 
                         Loan1IntOnlyPeriod AS FIRSTMORTGAGEInterestOnlyPeriod, Loan1MaximumInt AS FIRSTMORTGAGEMaximumInterestRate, Loan1IntRateNotLess AS FIRSTMORTGAGEMinimumInterestRate, 
                         Loan1RateChangeFrequency AS FIRSTMORTGAGERateChangeFrequency, Loan2RecordingDt AS SECONDMORTGAGERECORDINGDATE, CASE WHEN Loan2RecordingDt IS NOT NULL THEN SaleDate ELSE NULL 
                         END AS SECONDMORTGAGEDOCDATE, Loan2Document AS SECONDMORTGAGEDOCUMENTNUMBER, Loan2Book AS SECONDMORTGAGERECORDINGBOOK, 
                         Loan2Page AS SECONDMORTGAGERECORDINGPAGE, 
						 CASE WHEN Loan2Amount > 0 THEN 'MG' ELSE NULL END 
						 -----Changed to force to MG 20171201 KL---
						 --Loan2DocumentTypeCode 
						 AS SECONDMORTGAGEDETAILEDDOCUMENTTYPE, Loan2Amount AS SECONDMORTGAGEAMOUNT, 
                         Loan2LenderName AS SECONDMORTGAGELENDERNAME
						 --, Loan2TransType AS SECONDMORTGAGELOANTYPECODE
						 , Case when [Loan2TransType] = '6' then '1'
								when [Loan2TransType] = '7' then '2'
								when [Loan2TransType] = '8' then '3'
								when [Loan2TransType] = '9' then '4'
								when [Loan2TransType] = '10' then '5'
								when [Loan2TransType] = '11'then '6'
						 end as SECONDMORTGAGELOANTYPECODE
						 
						 , CASE WHEN [Loan2DueDate] IS NOT NULL THEN 'M' ELSE NULL 
                         END AS SECONDMORTGAGETERMCODE, CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 350 AND 365 THEN '360' WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 230 AND 250 THEN '240' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 118 AND 
                         122 THEN '120' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 175 AND 185 THEN '180' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) 
                         - 1) BETWEEN 10 AND 13 THEN '12' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 22 AND 26 THEN '24' WHEN (datediff(mm, cast(RecordingDt AS date), 
                         cast(Loan2DueDate AS date)) - 1) BETWEEN 32 AND 39 THEN '36' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 57 AND 62 THEN '60' ELSE (datediff(mm, 
                         cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) END AS SECONDMORTGAGETERM/*,case when [Loan2DueDate] is not null then 'M' else null end as SECONDMORTGAGETERM*/ , 
                         Loan2DueDate AS SECONDMORTGAGEDUEDATE, 
						 -----------------Removed 20151104 due to population of FA values vs BK------------
						 ---Loan2TypeFinance AS SECONDMORTGAGEINTERESTRATETYPE
						 CASE WHEN  [Loan2TypeFinance] = 'MULT' THEN 'MUL' ELSE [Loan2TypeFinance] END AS SECONDMORTGAGEINTERESTRATETYPE

						 , Loan2InterestRate AS SECONDMORTGAGEINTERESTRATE, 
                         CASE WHEN [Loan2LenderCode] = 'S' THEN 'Y' WHEN [Loan2LenderCode] = '25' THEN 'Y' ELSE NULL END AS SECONDMORTGAGESELLERCARRYBACK, 
                         CASE WHEN [Loan2LenderCode] = 'P' THEN 'Y' ELSE NULL END AS SECONDMORTGAGEPRIVATEPARTYLENDER, Loan2NewConstructionLoanInd AS SECONDMORTGAGECONSTRUCTIONLOAN, NULL 
                         AS SECONDMORTGAGEREFIFLAG, CASE WHEN Loan2Amount > 0 THEN 'Y' ELSE NULL END AS SECONDMORTGAGEEQUITYFLAG, NULL AS SECONDMORTGAGEHELOCFLAG, 
                         Loan2SubordinateLoanInd AS SECONDMORTGAGEOTHERSUBORDINATELOANFlag, SecondHomeRider AS SECONDMORTGAGESecondHomeRider, CondominiumRider AS SECONDMORTGAGECondominiumRider, 
                         MultiFamily4Rider AS SECONDMORTGAGEMultiFamily4Rider, PlannedUnitDevelopmentRider AS SECONDMORTGAGEPlannedUnitDevelopmentRider, 
                         Loan2AssumabilityRider AS SECONDMORTGAGEAssumabilityRider, Loan2BalloonRider AS SECONDMORTGAGEBalloonRider, Loan2BiweeklyPaymentRider AS SECONDMORTGAGEBiweeklyPaymentRider, 
                         Loan2FixedStepRateRider AS SECONDMORTGAGEFixedStepRateRider, Loan2GraduatedPaymentRider AS SECONDMORTGAGEGraduatedPaymentRider, 
                         Loan2PrePaymentRider AS SECONDMORTGAGEPrepaymentRider, Loan2RateImprovementRider AS SECONDMORTGAGERateImprovementRider, 
                         Loan2AdjRateRider AS SECONDMORTGAGEAdjustableRateRider, NULL AS SECONDMORTGAGEAdjustableRateIndex, Loan2ChangeIndex AS SECONDMORTGAGEChangeIndex, 
                         Loan2FirstChangeDateMMDD AS SECONDMORTGAGEFirstChangeDateMonthDay, Loan2FirstChangeDateYYYY AS SECONDMORTGAGEFirstChangeDateYear, 
                         Loan2IntOnlyPeriod AS SECONDMORTGAGEInterestOnlyPeriod, Loan2MaximumInt AS SECONDMORTGAGEMaximumInterestRate, Loan2IntRateNotLess AS SECONDMORTGAGEMinimumInterestRate, 
                         Loan2RateChangeFrequency AS SECONDMORTGAGERateChangeFrequency, LegalLotCode AS LotCode, LegalLandLot AS LotNumber, LegalLotNumber AS LandLot, LegalBlock AS Block, 
                         -----------------20161122 - NULLED this out per CB - KL-----
						 --LegalSectionTownshipRangeMeridian AS Section, 
						  NULL AS Section,
						 
						 DistrictCode AS District, D.LegalUnit AS Unit, LegalCityMuniTownship AS CityMunicipalityTownship, LegalSubdivision AS SubdivisionName, 
                         LegalPhaseNumber AS PhaseNo, LegalTractNumber AS TractNo, LegalSectionTownshipRangeMeridian AS SecTwnRngMer, NULL AS AssessorsMapRef, LegalBriefDescription AS LEGALDESCRIPTION, 
                         TitleCompanyName AS TITLECOMPANYNAME, [MultiAPNCode] AS MULTIAPN, D.FATimeStamp AS UPDATETIMESTAMP, D.FAUCIDFlag AS UCID, D.FATimeStamp as FATimeStamp 
						-----------------Added for Altisource - KL 20160727------------
						 ,P.[PropertyCLassID] as PROPERTYUSECODE
						 ,P.StdLandUseCode as STDLANDUSECODE
						 ,D.BuyerNameAddendum as BUYERBORROWERNAMEADDENDUM
						 --------------Added for RealEstateU 20160830 - KL----------
						 ,P.[SitusStdFullStreetAddress] AS SitusStdFullStreetAddress

						

						 ,case when len(D.RecordingDt) < 8 then NULL else Right(LEFT(D.RecordingDt,6),2) end as RecordingDateMonth
						 ,case when len(D.RecordingDt) < 8 then NULL else LEFT(D.RecordingDt,4) end as RecordingDateYear

						 ,case when len(D.SaleDate) < 8 then NULL else Right(LEFT(D.SaleDate,6),2) end as SaleDateMonth
						 ,case when len(D.SaleDate) < 8 then NULL else LEFT(D.SaleDate,4) end as SaleDateYear



						 ,P.[PropertyClassID] AS PropertyClassID
						,P.[SitusCensusTract] AS SitusCensusTract
						,P.[MobileHomeInd] AS MobileHomeInd
						,P.[TimeshareCode] AS TimeshareCode
						,P.[LotSizeAcres] AS LotSizeAcres
						,P.[LotSizeSqFt] AS LotSizeSqFt
						,P.[AssdTotalValue] AS AssdTotalValue
						,P.[AssdLandValue] AS AssdLandValue
						,P.[AssdImprovementValue] AS AssdImprovementValue
						,P.[MarketTotalValue] AS MarketTotalValue
						,P.[MarketValueLand] AS MarketValueLand
						,P.[MarketValueImprovement] AS MarketValueImprovement
						,P.[AssdYear] AS AssdYear
						,P.[BuildingArea] AS BuildingArea
						,P.[BuildingAreaInd] AS BuildingAreaInd
						,P.[SumBuildingSqFt] AS SumBuildingSqFt
						,P.[SumLivingAreaSqFt] AS SumLivingAreaSqFt
						,P.[SumGroundFloorSqFt] AS SumGroundFloorSqFt
						,P.[SumGrossAreaSqFt] AS SumGrossAreaSqFt
						,P.[SumAdjAreaSqFt] AS SumAdjAreaSqFt
						,P.[SumBasementSqFt] AS SumBasementSqFt
						,P.[SumGarageSqFt] AS SumGarageSqFt
						,P.[YearBuilt] AS YearBuilt
						,P.[EffectiveYearBuilt] AS EffectiveYearBuilt
						,P.[Bedrooms] AS Bedrooms
						,P.[TotalRooms] AS TotalRooms
						,P.[BathTotalCalc] AS BathTotalCalc
						,P.[BathFull] AS BathFull
						,P.[BathsParcialNbr] AS BathsParcialNbr
						,P.[BuildingClassCode] AS BuildingClassCode
						,D.[Armslength] as Armslength
						, Loan1Type AS FIRSTMORTGAGEDETAILEDLOANTYPE
						, Loan2Type AS SECONDMORTGAGEDETAILEDLOANTYPE
						,D.SitusLatitude as SitusLatitude
						,D.SitusLongitude as SitusLongitude
						------Added for Equimine 20161107 - KL----
						,D.SalesPriceCode as SalesPriceCode

						-----Added 20161121 - KL----
						,P.[MailingStdFullStreetAddress] as MailingStdFullStreetAddress
						,P.[OwnerOccupied] as OwnerOccupied
						,P.[PoolCode] as PoolCode

						-----Added 20170202 for Compstak - KL
						,P.[SitusGeoStatusCode] as SitusGeoStatusCode

						-----Added 20170217 for MyListingsAgent - JE
						,D.[FASalePosition]
						
						-----Added 20171114 KL----
						,D.[CMTID] as DEEDCMTID
						,D.[CMTIDInstNbr] as DEEDCMTIDInstNbr
						,D.[Loan1CMTID]
						,D.[Loan1CMTIDInstNbr]
						,D.[Loan2CMTID]
						,D.[Loan2CMTIDInstNbr]





FROM            deed D  with(NOLOCK)

--------added to allow fields from other data set to be used in data pulls through tool per BR - KL 201607027

Left outer join Data.dbo.Property as P with(NOLOCK)
on D.FIPS = P.FIPS
and D.FAPropertyID = P.PropertyID



UNION ALL
/*-------------------------------------------------------------------------------------*/ 

SELECT M.FIPS AS FIPS, M.FAPropertyId AS PROPERTYUNIQUEID, M.APN AS APN, NULL AS APNSEQUENCENBR, NULL AS PREVIOUSPARCELNUMBER, M.
                         TaxAccountNbr AS TAXACCOUNTNUMBER, M.FAMatchInd AS MatchedFlag, M.SitusHouseNbr AS HOUSENUMBER, M.SitusHouseNbr2 AS HOUSENUMBER2, NULL AS HOUSENUMBERSUFFIX, M.
                         SitusDirectionLeft AS DIRECTIONLEFT, M.SitusStreet AS STREETNAME, M.SitusMode AS Suffix, M.SitusDirectionRight AS DIRECTIONRIGHT, M.SitusUnitType AS UNITTYPE, M.SitusUnitNbr AS UNITNUMBER, M.
                         SitusCity AS CITY, M.SitusState AS STATE, M.SitusZIP5 AS ZIPCODE, M.SitusZip4 AS ZIPPLUS4, M.SitusCarrierCode AS CARRIERCODE, CASE WHEN [Borrower1NoParsInd] = 1 THEN 'Y' ELSE NULL 
                         END AS CORPORATEINDICATOR, M.Borrower1FullName AS BUYERNAMEBORROWERNAME1, BorrowerNameAddendum AS OWNERETALIND, NULL AS OwnerCAREOfNAME, 
                         BorrowerVestingCode AS OWNERSHIPRIGHTSCODE1, Borrower1IDCode AS OWNERRELATIONSHIPTYPE1, Borrower2NoParsInd AS CORPORATEINDICATOR2, 
                         Borrower2FullName AS BUYERNAMEBORROWERNAME2, BorrowerVestingCode AS OWNERSHIPRIGHTSCODE2, Borrower21IDCode AS OWNERRELATIONSHIPTYPE2, 
                         Borrower1LastName AS BUYER1LASTNAME, Borrower1FirstName AS BUYER1FIRSTNAME, Borrower1MiddleInitial AS BUYER1MIDDLEName, Borrower1NameSuffix AS BUYER1SUFFIX, 
                         Borrower2LastName AS BUYER2LASTNAME, Borrower2FirstName AS BUYER2FIRSTNAME, Borrower2MiddleInitial AS BUYER2MIDDLEName, Borrower2NameSuffix AS BUYER2SUFFIX, 
                         BorrowerMailHouseNbr AS MAILHOUSENUMBER, BorrowerMailHouseNbr2 AS MAILHOUSENUMBER2, BorrowerMailHouseNbrSuffix AS MAILHOUSENUMBERSUFFIX, 
                         BorrowerMailLeftDirection AS MAILDIRECTIONLEFT, BorrowerMailStreetName AS MAILSTREETNAME, BorrowerMailMode AS MAILMODE, BorrowerMailRightDirection AS MAILDIRECTIONRIGHT, 
                         BorrowerMailUnitType AS MAILUNITTYPE, BorrowerMailUnitNumber AS MAILUNITNUMBER, BorrowerMailCity AS MAILCITY, BorrowerMailState AS MAILSTATE, BorrowerMailZip5 AS MAILZIPCODE, 
                         BorrowerMailZip4 AS MAILZIPPlus4, BorrowerMailCarrierCode AS MAILCARRIERCODE, TransactionId AS FirstAmericanUniqueTransactionID, RecordingDt AS RECORDINGDATE, ContractDate AS SALEDATE, 
                         DocNbrSrce AS DOCUMENTNUMBER, BookSrce AS RECORDINGBOOK, PageSrce AS RECORDINGPAGE, NULL AS HAWAIILANDCOURTDOCUMENTNUMBER, NULL AS HAWAIITCTCERTIFICATENUMBER, NULL 
                         AS WAEXCISENUMBER, DocumentTypeCode AS DOCUMENTTYPE
						 --,LoanTransType AS TRANSACTIONTYPE
						 , Case when [LoanTransType] = '6' then '1'
								when [LoanTransType] = '7' then '2'
								when [LoanTransType] = '8' then '3'
								when [LoanTransType] = '9' then '4'
								when [LoanTransType] = '10' then '5'
								when [LoanTransType] = '11'then '6'
						 end as TRANSACTIONTYPE


						, NULL AS SELLERNAME, NULL AS SELLERNAMECORPINDICATOR, NULL AS SELLERNAME2, NULL 
                         AS SELLERNAME2CORPINDICATOR, NULL AS SALEAMOUNT, NULL AS TRANSFERTAX, NULL AS PARTIALINTERESTINDICATORFLAG, NULL AS RESALEFLAG, NULL AS NEWCONSTRUCTIONFLAG, NULL 
                         AS INTERFAMILYFLAG, NULL AS FORCLOSUREFLAG, NULL AS REOSALEFLAG, RecordingDt AS FIRSTMORTGAGERECORDINGDATE, ContractDate AS FIRSTMORTGAGEDOCDATE, 
                         DocNbrSrce AS FIRSTMORTGAGEDOCUMENTNUMBER, BookSrce AS FIRSTMORTGAGERECORDINGBOOK, PageSrce AS FIRSTMORTGAGERECORDINGPAGE, CASE WHEN LoanAmount > 0 THEN 'MG' ELSE NULL 
                         END AS FIRSTMORTGAGEDETAILEDDOCUMENTTYPE, LoanAmount AS FIRSTMORTGAGEMORTGAGEAMOUNT, Replace(Replace([LenderName], ',', ''), '.', '') AS FIRSTMORTGAGELENDERNAME
						 --, LoanTransType AS FIRSTMORTGAGELOANTYPECODE
						 , Case when [LoanTransType] = '6' then '1'
								when [LoanTransType] = '7' then '2'
								when [LoanTransType] = '8' then '3'
								when [LoanTransType] = '9' then '4'
								when [LoanTransType] = '10' then '5'
								when [LoanTransType] = '11'then '6'
						 end as FIRSTMORTGAGELOANTYPECODE
											 
						 , CASE WHEN [LoanDueDate] IS NOT NULL THEN 'M' ELSE NULL END AS FIRSTMORTGAGETERMCODE, CASE WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 350 AND 365 THEN '360' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 230 AND 
                         250 THEN '240' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 118 AND 122 THEN '120' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) 
                         - 1) BETWEEN 175 AND 185 THEN '180' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 10 AND 13 THEN '12' WHEN (datediff(mm, cast(RecordingDt AS date), 
                         cast(LoanDueDate AS date)) - 1) BETWEEN 22 AND 26 THEN '24' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 32 AND 39 THEN '36' WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 57 AND 62 THEN '60' ELSE (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) END AS FIRSTMORTGAGETERM, 
                         LoanDueDate AS FIRSTMORTGAGEDUEDATE, 

						 -----------------Removed 20151104 due to population of FA values vs BK------------
						 --CASE WHEN [TypeFinance] = 'AD' THEN 'ADJ' WHEN [TypeFinance] = 'FI' THEN 'FIX' WHEN [TypeFinance] = 'MU' THEN 'MUL' WHEN [TypeFinance] = 'OT' THEN 'OTH' WHEN [TypeFinance] = 'ST' THEN 'STP' WHEN
						--   [TypeFinance] = 'UN' THEN 'UNK' WHEN [TypeFinance] = 'VA' THEN 'VAR' ELSE [TypeFinance] END AS FIRSTMORTGAGEINTERESTRATETYPE
						  CASE WHEN  [TypeFinance] = 'MULT' then 'MUL' ELSE [TypeFinance] END AS FIRSTMORTGAGEINTERESTRATETYPE

						  , format([LoanInterestRate], '00000') AS FIRSTMORTGAGEINTERESTRATE, CASE WHEN [LenderTypeCode] = 'S' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGESELLERCARRYBACKFLAG, CASE WHEN [LenderTypeCode] = 'P' THEN 'Y' ELSE NULL 
                         END AS FIRSTMORTGAGEPRIVATEPARTYLENDER, CASE WHEN [LoanType] = '8' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGECONSTRUCTIONLOAN, 
                        -----------------Removed 20151104 due to addition of [LoanRefiLoanInd]  field------------
						 --CASE WHEN [LoanType] = '1' THEN 'Y' WHEN [LoanType] = 'N' THEN 'Y' WHEN [LoanType] = 'R' THEN 'Y' WHEN [LoanTransType] = '5' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGEREFIFLAG, 
						 [LoanRefiLoanInd]  AS FIRSTMORTGAGEREFIFLAG

                         ,LoanEquityLoanInd  AS FIRSTMORTGAGEEQUITYFLAG, 

						   -----------------Removed 20151104 due to addition of [LoanHELOCLoanInd]  field------------
                         --CASE WHEN [LoanTransType] = '4' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGEHELOCFLAG

						 [LoanHELOCLoanInd] AS FIRSTMORTGAGEHELOCFLAG
						 
						 , SubordinateLoanInd AS FIRSTMORTGAGEOTHERSUBORDINATELOANFlag, 
                         SecondHomeRider AS FIRSTMORTGAGESecondHomeRider, CondominiumRider AS FIRSTMORTGAGECondominiumRider, MultiFamily4Rider AS FIRSTMORTGAGEMultiFamily4Rider, 
                         PlannedUnitDevelopmentRider AS FIRSTMORTGAGEPlannedUnitDevelopmentRider, LoanAssumabilityRider AS FIRSTMORTGAGEAssumabilityRider, LoanBalloonRider AS FIRSTMORTGAGEBalloonRider, 
                         LoanBiweeklyPaymentRider AS FIRSTMORTGAGEBiweeklyPaymentRider, LoanFixedStepRateRider AS FIRSTMORTGAGEFixedStepRateRider, 
                         LoanGraduatedPaymentRider AS FIRSTMORTGAGEGraduatedPaymentRider, LoanPrePaymentRider AS FIRSTMORTGAGEPrepaymentRider, 
                         LoanRateImprovementRider AS FIRSTMORTGAGERateImprovementRider, LoanAdjRateRider AS FIRSTMORTGAGEAdjustableRateRider, LoanAdjRateIndex AS FIRSTMORTGAGEAdjustableRateIndex, 
                         LoanChangeIndex AS FIRSTMORTGAGEChangeIndex, LoanFirstChangeDateMMDD AS FIRSTMORTGAGEFirstChangeDateMonthDay, LoanFirstChangeDateYYYY AS FIRSTMORTGAGEFirstChangeDateYear, 
                         LoanIntOnlyPeriod AS FIRSTMORTGAGEInterestOnlyPeriod, LoanMaximumInt AS FIRSTMORTGAGEMaximumInterestRate, LoanIntRateNotLess AS FIRSTMORTGAGEMinimumInterestRate, 
                         LoanRateChangeFrequency AS FIRSTMORTGAGERateChangeFrequency, NULL AS SECONDMORTGAGERECORDINGDATE, NULL AS SECONDMORTGAGEDOCDATE, NULL 
                         AS SECONDMORTGAGEDOCUMENTNUMBER, NULL AS SECONDMORTGAGERECORDINGBOOK, NULL AS SECONDMORTGAGERECORDINGPAGE, NULL AS SECONDMORTGAGEDETAILEDDOCUMENTTYPE, NULL 
                         AS SECONDMORTGAGEAMOUNT, NULL AS SECONDMORTGAGELENDERNAME, NULL AS SECONDMORTGAGELOANTYPECODE, NULL AS SECONDMORTGAGETERMCODE, NULL 
                         AS SECONDMORTGAGETERM, NULL AS SECONDMORTGAGEDUEDATE, NULL AS SECONDMORTGAGEINTERESTRATETYPE, NULL AS SECONDMORTGAGEINTERESTRATE, NULL 
                         AS SECONDMORTGAGESELLERCARRYBACK, NULL AS SECONDMORTGAGEPRIVATEPARTYLENDER, NULL AS SECONDMORTGAGECONSTRUCTIONLOAN, NULL AS SECONDMORTGAGEREFIFLAG, NULL 
                         AS SECONDMORTGAGEEQUITYFLAG, NULL AS SECONDMORTGAGEHELOCFLAG, NULL AS SECONDMORTGAGEOTHERSUBORDINATELOANFlag, NULL AS SECONDMORTGAGESecondHomeRider, NULL 
                         AS SECONDMORTGAGECondominiumRider, NULL AS SECONDMORTGAGEMultiFamily4Rider, NULL AS SECONDMORTGAGEPlannedUnitDevelopmentRider, NULL AS SECONDMORTGAGEAssumabilityRider, NULL 
                         AS SECONDMORTGAGEBalloonRider, NULL AS SECONDMORTGAGEBiweeklyPaymentRider, NULL AS SECONDMORTGAGEFixedStepRateRider, NULL AS SECONDMORTGAGEGraduatedPaymentRider, NULL 
                         AS SECONDMORTGAGEPrepaymentRider, NULL AS SECONDMORTGAGERateImprovementRider, NULL AS SECONDMORTGAGEAdjustableRateRider, NULL AS SECONDMORTGAGEAdjustableRateIndex, NULL 
                         AS SECONDMORTGAGEChangeIndex, NULL AS SECONDMORTGAGEFirstChangeDateMonthDay, NULL AS SECONDMORTGAGEFirstChangeDateYear, NULL AS SECONDMORTGAGEInterestOnlyPeriod, NULL 
                         AS SECONDMORTGAGEMaximumInterestRate, NULL AS SECONDMORTGAGEMinimumInterestRate, NULL AS SECONDMORTGAGERateChangeFrequency, NULL AS LotCode, LegalLandLot AS LotNumber, 
                         LegalLotNumber AS LandLot, LegalBlock AS Block, M.LegalSection AS Section, LegalDistrict AS District, M.LegalUnit AS Unit, LegalCityMunicipalityTownship AS CityMunicipalityTownship, 
                         LegalSubdivision AS SubdivisionName, LegalPhaseNumber AS PhaseNo, LegalTractNumber AS TractNo, LegalMeridian AS SecTwnRngMer, NULL AS AssessorsMapRef, 
                         LegalBriefDescription AS LEGALDESCRIPTION, TitleCompanyName AS TITLECOMPANYNAME, 
                          -----------------Removed 20151104 due to population of FA values vs BK------------
						 --CASE WHEN [MultiAPNCode] = '+' THEN '1' WHEN [MultiAPNCode] = 'A' THEN '2' WHEN [MultiAPNCode] = 'E' THEN '3' WHEN [MultiAPNCode] = 'P' THEN '4' WHEN [MultiAPNCode] = 'T' THEN '5' WHEN [MultiAPNCode]
       --                   = 'C' THEN '6' ELSE NULL END AS MULTIAPN
						   [MultiAPNCode] AS MULTIAPN
						  , M.FATimeStamp AS UPDATETIMESTAMP, M.FAUCIDFlag AS UCID, M.FATimeStamp  as FATimeStamp 
						  -----------------Added for Altisource - KL 20160727------------
						 ,P.[PropertyCLassID] as PROPERTYUSECODE
						 ,P.StdLandUseCode as STDLANDUSECODE
						 ,M.BorrowerNameAddendum as BUYERBORROWERNAMEADDENDUM

						  --------------Added for RealEstateU 20160830 - KL----------
						 ,P.[SitusStdFullStreetAddress] AS SitusStdFullStreetAddress


						  ,case when len(M.RecordingDt) < 8 then NULL else Right(LEFT(M.RecordingDt,6),2) end as RecordingDateMonth
						 ,case when len(M.RecordingDt) < 8 then NULL else LEFT(M.RecordingDt,4) end as RecordingDateYear

						 ,case when len(M.ContractDate) < 8 then NULL else Right(LEFT(M.ContractDate,6),2) end as SaleDateMonth
						 ,case when len(M.ContractDate) < 8 then NULL else LEFT(M.ContractDate,4) end as SaleDateYear

						 			
						
						
						 ,P.[PropertyClassID] AS PropertyClassID
						,P.[SitusCensusTract] AS SitusCensusTract
						,P.[MobileHomeInd] AS MobileHomeInd
						,P.[TimeshareCode] AS TimeshareCode
						,P.[LotSizeAcres] AS LotSizeAcres
						,P.[LotSizeSqFt] AS LotSizeSqFt
						,P.[AssdTotalValue] AS AssdTotalValue
						,P.[AssdLandValue] AS AssdLandValue
						,P.[AssdImprovementValue] AS AssdImprovementValue
						,P.[MarketTotalValue] AS MarketTotalValue
						,P.[MarketValueLand] AS MarketValueLand
						,P.[MarketValueImprovement] AS MarketValueImprovement
						,P.[AssdYear] AS AssdYear
						,P.[BuildingArea] AS BuildingArea
						,P.[BuildingAreaInd] AS BuildingAreaInd
						,P.[SumBuildingSqFt] AS SumBuildingSqFt
						,P.[SumLivingAreaSqFt] AS SumLivingAreaSqFt
						,P.[SumGroundFloorSqFt] AS SumGroundFloorSqFt
						,P.[SumGrossAreaSqFt] AS SumGrossAreaSqFt
						,P.[SumAdjAreaSqFt] AS SumAdjAreaSqFt
						,P.[SumBasementSqFt] AS SumBasementSqFt
						,P.[SumGarageSqFt] AS SumGarageSqFt
						,P.[YearBuilt] AS YearBuilt
						,P.[EffectiveYearBuilt] AS EffectiveYearBuilt
						,P.[Bedrooms] AS Bedrooms
						,P.[TotalRooms] AS TotalRooms
						,P.[BathTotalCalc] AS BathTotalCalc
						,P.[BathFull] AS BathFull
						,P.[BathsParcialNbr] AS BathsParcialNbr
						,P.[BuildingClassCode] AS BuildingClassCode
						,NULL as Armslength
						, LoanType AS FIRSTMORTGAGEDETAILEDLOANTYPE
						, NULL AS SECONDMORTGAGEDETAILEDLOANTYPE

						,M.SitusLatitude as SitusLatitude
						,M.SitusLongitude as SitusLongitude

						------Added for Equimine 20161107 - KL----
						,NULL as SalesPriceCode

						-----Added 20161121 - KL----
						,P.[MailingStdFullStreetAddress] as MailingStdFullStreetAddress
						,P.[OwnerOccupied] as OwnerOccupied
						,P.[PoolCode] as PoolCode

						-----Added 20170202 for Compstak - KL
						,P.[SitusGeoStatusCode] as SitusGeoStatusCode

						-----Added 20170217 for MyListingsAgent - JE
						,NULL as [FASalePosition]

						
						-----Added 20171114 KL----
						,NULL as DEEDCMTID
						,NULL as DEEDCMTIDInstNbr
						,M.[CMTID] as [Loan1CMTID]
						,M.[CMTIDInstNbr] as [Loan1CMTIDInstNbr]
						,NULL as [Loan2CMTID]
						,NULL as [Loan2CMTIDInstNbr]
						


FROM            mortgage as M  with(NOLOCK)
--------added to allow fields from other data set to be used in data pulls through tool per BR - KL 201607027

Left outer join Data.dbo.Property as P with(NOLOCK)
on M.FIPS = P.FIPS
and M.FAPropertyID = P.PropertyID


UNION ALL
/*-------------------------------------------------------------------------------------*/ 

SELECT       A.FIPS AS FIPS, A.FAPropertyId AS PROPERTYUNIQUEID, A.APN AS APN, NULL AS APNSEQUENCENBR, NULL AS PREVIOUSPARCELNUMBER, A.TaxAccountNbr AS TAXACCOUNTNUMBER, A.FAMatchInd AS MatchedFlag, A.
                         SitusStdHouseNbr AS HOUSENUMBER, A.SitusStdHouseNbr2 AS HOUSENUMBER2, A.SitusStdHouseNbrSuffix AS HOUSENUMBERSUFFIX, A.SitusStdDirectionLeft AS DIRECTIONLEFT, A.SitusStdStreet AS STREETNAME,
                          A.SitusStdMode AS Suffix, A.SitusStdDirectionRight AS DIRECTIONRIGHT, A.SitusStdUnitType AS UNITTYPE, A.SitusStdUnitNbr AS UNITNUMBER, A.SitusStdCity AS CITY, A.SitusStdState AS STATE, A.
                         SitusStdZIP5 AS ZIPCODE, A.SitusStdZip4 AS ZIPPLUS4, A.SitusStdCarrierCode AS CARRIERCODE, CASE WHEN [Buyer1NoParsInd] = 1 THEN 'Y' ELSE NULL END AS CORPORATEINDICATOR, 
                         Buyer1FullName AS BUYERNAMEBORROWERNAME1, BuyerNameAddendum AS OWNERETALIND, BuyerMailCareOfName AS OwnerCAREOfNAME, BuyerVestingCode AS OWNERSHIPRIGHTSCODE1, 
                         Buyer1IDCode AS OWNERRELATIONSHIPTYPE1, Buyer2NoParsInd AS CORPORATEINDICATOR2, Buyer2FullName AS BUYERNAMEBORROWERNAME2, NULL AS OWNERSHIPRIGHTSCODE2, 
                         Buyer2IDCode AS OWNERRELATIONSHIPTYPE2, Buyer1LastName AS BUYER1LASTNAME, Buyer1FirstName AS BUYER1FIRSTNAME, Buyer1MiddleInitial AS BUYER1MIDDLEName, 
                         Buyer1NameSiffix AS BUYER1SUFFIX, Buyer2LastName AS BUYER2LASTNAME, Buyer2FirstName AS BUYER2FIRSTNAME, Buyer2MiddleInitial AS BUYER2MIDDLEName, 
                         Buyer2NameSuffix AS BUYER2SUFFIX, BuyerMailHouseNbr AS MAILHOUSENUMBER, BuyerMailHouseNbr2 AS MAILHOUSENUMBER2, BuyerMailHouseNbrSuffix AS MAILHOUSENUMBERSUFFIX, 
                         BuyerMailLeftDirection AS MAILDIRECTIONLEFT, BuyerMailStreetName AS MAILSTREETNAME, BuyerMailMode AS MAILMODE, BuyerMailRightDirection AS MAILDIRECTIONRIGHT, 
                         BuyerMailUnitType AS MAILUNITTYPE, BuyerMailUnitNumber AS MAILUNITNUMBER, BuyerMailCity AS MAILCITY, BuyerMailState AS MAILSTATE, BuyerMailZip5 AS MAILZIPCODE, 
                         BuyerMailZip4 AS MAILZIPPlus4, BuyerMailCarrierCode AS MAILCARRIERCODE, TransactionId AS FirstAmericanUniqueTransactionID, RecordingDt AS RECORDINGDATE, SaleDate AS SALEDATE, 
                         DocNbrSrce AS DOCUMENTNUMBER, BookSrce AS RECORDINGBOOK, PageSrce AS RECORDINGPAGE, HILandCountDocumentNbr AS HAWAIILANDCOURTDOCUMENTNUMBER, 
                         HICertificateNbr AS HAWAIITCTCERTIFICATENUMBER, WaExciseNbr AS WAEXCISENUMBER, DocumentTypeCode AS DOCUMENTTYPE, DeedTransactionType AS TRANSACTIONTYPE, 
                         Substring(ltrim(rtrim(Ltrim(Rtrim(CASE WHEN [Seller1LastNameOrCorpName] IS NULL THEN '' ELSE [Seller1LastNameOrCorpName] END)) + ' ' + ltrim(rtrim(CASE WHEN [Seller1FirstNameMiddlename] IS NULL 
                         THEN '' ELSE [Seller1FirstNameMiddlename] END)))), 1, 60) AS SELLERNAME, CASE WHEN ([Seller1LastNameOrCorpName] IS NOT NULL AND [Seller1FirstNameMiddlename] IS NULL) THEN 'Y' ELSE NULL 
                         END AS SELLERNAMECORPINDICATOR, Substring(ltrim(rtrim(Ltrim(Rtrim(CASE WHEN [Seller2LastNameOrCorpName] IS NULL THEN '' ELSE [Seller2LastNameOrCorpName] END)) 
                         + ' ' + ltrim(rtrim(CASE WHEN [Seller2FirstNameMiddlename] IS NULL THEN '' ELSE [Seller2FirstNameMiddlename] END)))), 1, 60) AS SELLERNAME2, CASE WHEN ([Seller2LastNameOrCorpName] IS NOT NULL 
                         AND [Seller2FirstNameMiddlename] IS NULL) THEN 'Y' ELSE NULL END AS SELLERNAME2CORPINDICATOR, SalesPrice AS SALEAMOUNT, 
						 
						  ------20161208 - Changed to cascade Tax fields per BR - KL
						 case 
						 when (TaxTotalTransferTax is null or TaxTotalTransferTax = 0) and (TaxCountyTransferTax is null or TaxCountyTransferTax = 0) then TaxCityTransferTax
						 when (TaxTotalTransferTax is null or TaxTotalTransferTax = 0) and (TaxCountyTransferTax >= 0) then TaxCountyTransferTax
						 else TaxTotalTransferTax end

						  AS TRANSFERTAX, 
						 --TaxTotalTransferTax AS TRANSFERTAX, 
                         
						 
						 PartialInterestTransferred AS PARTIALINTERESTINDICATORFLAG, CASE WHEN [ResaleInd] = 1 THEN 'Y' ELSE NULL END AS RESALEFLAG, CASE WHEN [NewConstructionInd] = 1 THEN 'Y' ELSE NULL 
                         END AS NEWCONSTRUCTIONFLAG, CASE WHEN substring([Seller2LastNameOrCorpName], 1, 4) LIKE substring(Buyer1FullName, 1, 4) THEN 'Y' ELSE NULL 
                         END AS INTERFAMILYFLAG/*,Case when [InterFamilyTransfer] = 1 then 'Y' else null end as INTERFAMILYFLAG*/ , CASE WHEN [Reo] = 1 THEN 'Y' ELSE NULL END AS FORCLOSUREFLAG, 
                         CASE WHEN [REOSale] = 1 THEN 'Y' ELSE NULL END AS REOSALEFLAG, CASE WHEN Loan1Amount > 0 THEN RecordingDt ELSE NULL END AS FIRSTMORTGAGERECORDINGDATE, 
                         CASE WHEN Loan1Amount > 0 THEN Saledate ELSE NULL END AS FIRSTMORTGAGEDOCDATE, 
						 CASE WHEN Loan1Document LIKE '%/%' THEN NULL 
                         ELSE Loan1Document END AS FIRSTMORTGAGEDOCUMENTNUMBER, CASE WHEN Loan1Document LIKE '%/%' THEN substring(Loan1Document, 1, (Charindex('/', Loan1Document) - 1)) 
                         ELSE '' END AS FIRSTMORTGAGERECORDINGBOOK, CASE WHEN Loan1Document LIKE '%/%' THEN substring(Loan1Document, (Charindex('/', Loan1Document) + 1), 20) 
                         ELSE '' END AS FIRSTMORTGAGERECORDINGPAGE, CASE WHEN Loan1Amount > 0 THEN 'MG' ELSE NULL END AS FIRSTMORTGAGEDETAILEDDOCUMENTTYPE, 
                         Loan1Amount AS FIRSTMORTGAGEMORTGAGEAMOUNT, Replace(Replace([Loan1LenderName ], ',', ''), '.', '') AS FIRSTMORTGAGELENDERNAME
						 --, Loan1TransType AS FIRSTMORTGAGELOANTYPECODE
						 ,Case when [loan1transtype] = '6' then '1'
								when [loan1transtype] = '7' then '2'
								when [loan1transtype] = '8' then '3'
								when [loan1transtype] = '9' then '4'
								when [loan1transtype] = '10' then '5'
								when [loan1transtype] = '11'then '6'
						 end as FIRSTMORTGAGELOANTYPECODE
						 ,CASE WHEN [Loan1DueDate] IS NOT NULL THEN 'M' ELSE NULL END AS FIRSTMORTGAGETERMCODE, CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 
                         350 AND 365 THEN '360' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 230 AND 250 THEN '240' WHEN (datediff(mm, cast(RecordingDt AS date), 
                         cast(Loan1DueDate AS date)) - 1) BETWEEN 118 AND 122 THEN '120' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 175 AND 185 THEN '180' WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 10 AND 13 THEN '12' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 22 AND 
                         26 THEN '24' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) BETWEEN 32 AND 39 THEN '36' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) 
                         BETWEEN 57 AND 62 THEN '60' ELSE (datediff(mm, cast(RecordingDt AS date), cast(Loan1DueDate AS date)) - 1) END AS FIRSTMORTGAGETERM, Loan1DueDate AS FIRSTMORTGAGEDUEDATE, 
                        --------------Removed 20151104 due to population of FA values vs BK------------
						 ---CASE WHEN [Loan1TypeFinance] = '1' THEN 'ADJ' WHEN [Loan1TypeFinance] = '2' THEN 'FIX' WHEN [Loan1TypeFinance] = '3' THEN 'MUL' WHEN [Loan1TypeFinance] = '4' THEN 'OTH' WHEN [Loan1TypeFinance]
                         --- = '5' THEN 'STP' WHEN [Loan1TypeFinance] = '6' THEN 'UNK' WHEN [Loan1TypeFinance] = '7' THEN 'VAR' END AS FIRSTMORTGAGEINTERESTRATETYPE
						 CASE WHEN  [Loan1TypeFinance] = 'MULT' THEN 'MUL' ELSE [Loan1TypeFinance] END AS FIRSTMORTGAGEINTERESTRATETYPE

						 ,format([Loan1InterestRate], '00000')  AS FIRSTMORTGAGEINTERESTRATE, CASE WHEN [Loan1LenderTypeCode] = 'S' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGESELLERCARRYBACKFLAG, 
                         CASE WHEN [Loan1LenderTypeCode] = 'P' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGEPRIVATEPARTYLENDER, CASE WHEN [Loan1Type] = '8' THEN 'Y' ELSE NULL 
                         END AS FIRSTMORTGAGECONSTRUCTIONLOAN, 
						NULL FIRSTMORTGAGEREFIFLAG --Changed to null 3/10/2016 CB
						 , NULL AS FIRSTMORTGAGEEQUITYFLAG, NULL 
                         AS FIRSTMORTGAGEHELOCFLAG,Loan1SubordinateLoanInd AS FIRSTMORTGAGEOTHERSUBORDINATELOANFlag, SecondHomeRider AS FIRSTMORTGAGESecondHomeRider, 
                         CondominiumRider AS FIRSTMORTGAGECondominiumRider, MultiFamily4Rider AS FIRSTMORTGAGEMultiFamily4Rider, PlannedUnitDevelopmentRider AS FIRSTMORTGAGEPlannedUnitDevelopmentRider, 
                         Loan1AssumabilityRider AS FIRSTMORTGAGEAssumabilityRider, Loan1BalloonRider AS FIRSTMORTGAGEBalloonRider, Loan1BiweeklyPaymentRider AS FIRSTMORTGAGEBiweeklyPaymentRider, 
                         Loan1FixedStepRateRider AS FIRSTMORTGAGEFixedStepRateRider, Loan1GraduatedPaymentRider AS FIRSTMORTGAGEGraduatedPaymentRider, Loan1PrePaymentRider AS FIRSTMORTGAGEPrepaymentRider, 
                         Loan1RateImprovementRider AS FIRSTMORTGAGERateImprovementRider, Loan1AdjRateRider AS FIRSTMORTGAGEAdjustableRateRider, Loan1AdjRateIndex AS FIRSTMORTGAGEAdjustableRateIndex, 
                         Loan1ChangeIndex AS FIRSTMORTGAGEChangeIndex, Loan1FirstChangeDateMMDD AS FIRSTMORTGAGEFirstChangeDateMonthDay, Loan1FirstChangeDateYYYY AS FIRSTMORTGAGEFirstChangeDateYear, 
                         Loan1IntOnlyPeriod AS FIRSTMORTGAGEInterestOnlyPeriod, Loan1MaximumInt AS FIRSTMORTGAGEMaximumInterestRate, Loan1IntRateNotLess AS FIRSTMORTGAGEMinimumInterestRate, 
                         Loan1RateChangeFrequency AS FIRSTMORTGAGERateChangeFrequency, Loan2RecordingDt AS SECONDMORTGAGERECORDINGDATE, CASE WHEN Loan2RecordingDt IS NOT NULL THEN SaleDate ELSE NULL 
                         END AS SECONDMORTGAGEDOCDATE, Loan2Document AS SECONDMORTGAGEDOCUMENTNUMBER, Loan2Book AS SECONDMORTGAGERECORDINGBOOK, 
                         Loan2Page AS SECONDMORTGAGERECORDINGPAGE, 
						  CASE WHEN Loan2Amount > 0 THEN 'MG' ELSE NULL END 
						 -----Changed to force to MG 20171201 KL---
						 --Loan2DocumentTypeCode 
						 AS SECONDMORTGAGEDETAILEDDOCUMENTTYPE
						, Loan2Amount AS SECONDMORTGAGEAMOUNT, 
                         Loan2LenderName AS SECONDMORTGAGELENDERNAME
						 --, Loan2TransType AS SECONDMORTGAGELOANTYPECODE
						 , Case when [Loan2TransType] = '6' then '1'
								when [Loan2TransType] = '7' then '2'
								when [Loan2TransType] = '8' then '3'
								when [Loan2TransType] = '9' then '4'
								when [Loan2TransType] = '10' then '5'
								when [Loan2TransType] = '11'then '6'
						 end as SECONDMORTGAGELOANTYPECODE
						 
						 , CASE WHEN [Loan2DueDate] IS NOT NULL THEN 'M' ELSE NULL 
                         END AS SECONDMORTGAGETERMCODE, CASE WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 350 AND 365 THEN '360' WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 230 AND 250 THEN '240' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 118 AND 
                         122 THEN '120' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 175 AND 185 THEN '180' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) 
                         - 1) BETWEEN 10 AND 13 THEN '12' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 22 AND 26 THEN '24' WHEN (datediff(mm, cast(RecordingDt AS date), 
                         cast(Loan2DueDate AS date)) - 1) BETWEEN 32 AND 39 THEN '36' WHEN (datediff(mm, cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) BETWEEN 57 AND 62 THEN '60' ELSE (datediff(mm, 
                         cast(RecordingDt AS date), cast(Loan2DueDate AS date)) - 1) END AS SECONDMORTGAGETERM/*,case when [Loan2DueDate] is not null then 'M' else null end as SECONDMORTGAGETERM*/ , 
                         Loan2DueDate AS SECONDMORTGAGEDUEDATE, 
						 -----------------Removed 20151104 due to population of FA values vs BK------------
						 ---Loan2TypeFinance AS SECONDMORTGAGEINTERESTRATETYPE
						 CASE WHEN  [Loan2TypeFinance] = 'MULT' THEN 'MUL' ELSE [Loan2TypeFinance] END AS SECONDMORTGAGEINTERESTRATETYPE

						 , Loan2InterestRate AS SECONDMORTGAGEINTERESTRATE, 
                         CASE WHEN [Loan2LenderCode] = 'S' THEN 'Y' WHEN [Loan2LenderCode] = '25' THEN 'Y' ELSE NULL END AS SECONDMORTGAGESELLERCARRYBACK, 
                         CASE WHEN [Loan2LenderCode] = 'P' THEN 'Y' ELSE NULL END AS SECONDMORTGAGEPRIVATEPARTYLENDER, Loan2NewConstructionLoanInd AS SECONDMORTGAGECONSTRUCTIONLOAN, NULL 
                         AS SECONDMORTGAGEREFIFLAG, CASE WHEN Loan2Amount > 0 THEN 'Y' ELSE NULL END AS SECONDMORTGAGEEQUITYFLAG, NULL AS SECONDMORTGAGEHELOCFLAG, 
                         Loan2SubordinateLoanInd AS SECONDMORTGAGEOTHERSUBORDINATELOANFlag, SecondHomeRider AS SECONDMORTGAGESecondHomeRider, CondominiumRider AS SECONDMORTGAGECondominiumRider, 
                         MultiFamily4Rider AS SECONDMORTGAGEMultiFamily4Rider, PlannedUnitDevelopmentRider AS SECONDMORTGAGEPlannedUnitDevelopmentRider, 
                         Loan2AssumabilityRider AS SECONDMORTGAGEAssumabilityRider, Loan2BalloonRider AS SECONDMORTGAGEBalloonRider, Loan2BiweeklyPaymentRider AS SECONDMORTGAGEBiweeklyPaymentRider, 
                         Loan2FixedStepRateRider AS SECONDMORTGAGEFixedStepRateRider, Loan2GraduatedPaymentRider AS SECONDMORTGAGEGraduatedPaymentRider, 
                         Loan2PrePaymentRider AS SECONDMORTGAGEPrepaymentRider, Loan2RateImprovementRider AS SECONDMORTGAGERateImprovementRider, 
                         Loan2AdjRateRider AS SECONDMORTGAGEAdjustableRateRider, NULL AS SECONDMORTGAGEAdjustableRateIndex, Loan2ChangeIndex AS SECONDMORTGAGEChangeIndex, 
                         Loan2FirstChangeDateMMDD AS SECONDMORTGAGEFirstChangeDateMonthDay, Loan2FirstChangeDateYYYY AS SECONDMORTGAGEFirstChangeDateYear, 
                         Loan2IntOnlyPeriod AS SECONDMORTGAGEInterestOnlyPeriod, Loan2MaximumInt AS SECONDMORTGAGEMaximumInterestRate, Loan2IntRateNotLess AS SECONDMORTGAGEMinimumInterestRate, 
                         Loan2RateChangeFrequency AS SECONDMORTGAGERateChangeFrequency, LegalLotCode AS LotCode, LegalLandLot AS LotNumber, LegalLotNumber AS LandLot, LegalBlock AS Block, 
                         -----------------20161122 - NULLED this out per CB - KL-----
						 --LegalSectionTownshipRangeMeridian AS Section
						 NULL AS Section
						 
						 , DistrictCode AS District, A.LegalUnit AS Unit, LegalCityMuniTownship AS CityMunicipalityTownship, LegalSubdivision AS SubdivisionName, 
                         LegalPhaseNumber AS PhaseNo, LegalTractNumber AS TractNo, LegalSectionTownshipRangeMeridian AS SecTwnRngMer, NULL AS AssessorsMapRef, LegalBriefDescription AS LEGALDESCRIPTION, 
                         TitleCompanyName AS TITLECOMPANYNAME, [MultiAPNCode] AS MULTIAPN, A.FATimeStamp AS UPDATETIMESTAMP, A.FAUCIDFlag AS UCID, A.FATimeStamp as FATimeStamp 
						 -----------------Added for Altisource - KL 20160727------------
						 ,P.[PropertyCLassID] as PROPERTYUSECODE
						 ,P.StdLandUseCode as STDLANDUSECODE
						 ,A.BuyerNameAddendum as BUYERBORROWERNAMEADDENDUM

						  --------------Added for RealEstateU 20160830 - KL----------
						 ,P.[SitusStdFullStreetAddress] AS SitusStdFullStreetAddress

						 ,case when len(A.RecordingDt) < 8 then NULL else Right(LEFT(A.RecordingDt,6),2) end as RecordingDateMonth
						 ,case when len(A.RecordingDt) < 8 then NULL else LEFT(A.RecordingDt,4) end as RecordingDateYear

						 ,case when len(A.SaleDate) < 8 then NULL else Right(LEFT(A.SaleDate,6),2) end as SaleDateMonth
						 ,case when len(A.SaleDate) < 8 then NULL else LEFT(A.SaleDate,4) end as SaleDateYear

						 			
						
						
						
						 ,P.[PropertyClassID] AS PropertyClassID
						,P.[SitusCensusTract] AS SitusCensusTract
						,P.[MobileHomeInd] AS MobileHomeInd
						,P.[TimeshareCode] AS TimeshareCode
						,P.[LotSizeAcres] AS LotSizeAcres
						,P.[LotSizeSqFt] AS LotSizeSqFt
						,P.[AssdTotalValue] AS AssdTotalValue
						,P.[AssdLandValue] AS AssdLandValue
						,P.[AssdImprovementValue] AS AssdImprovementValue
						,P.[MarketTotalValue] AS MarketTotalValue
						,P.[MarketValueLand] AS MarketValueLand
						,P.[MarketValueImprovement] AS MarketValueImprovement
						,P.[AssdYear] AS AssdYear
						,P.[BuildingArea] AS BuildingArea
						,P.[BuildingAreaInd] AS BuildingAreaInd
						,P.[SumBuildingSqFt] AS SumBuildingSqFt
						,P.[SumLivingAreaSqFt] AS SumLivingAreaSqFt
						,P.[SumGroundFloorSqFt] AS SumGroundFloorSqFt
						,P.[SumGrossAreaSqFt] AS SumGrossAreaSqFt
						,P.[SumAdjAreaSqFt] AS SumAdjAreaSqFt
						,P.[SumBasementSqFt] AS SumBasementSqFt
						,P.[SumGarageSqFt] AS SumGarageSqFt
						,P.[YearBuilt] AS YearBuilt
						,P.[EffectiveYearBuilt] AS EffectiveYearBuilt
						,P.[Bedrooms] AS Bedrooms
						,P.[TotalRooms] AS TotalRooms
						,P.[BathTotalCalc] AS BathTotalCalc
						,P.[BathFull] AS BathFull
						,P.[BathsParcialNbr] AS BathsParcialNbr
						,P.[BuildingClassCode] AS BuildingClassCode
						,A.ArmsLength as Armslength
						, Loan1Type AS FIRSTMORTGAGEDETAILEDLOANTYPE
						, Loan2Type AS SECONDMORTGAGEDETAILEDLOANTYPE
						,A.SitusLatitude as SitusLatitude
						,A.SitusLongitude as SitusLongitude
						------Added for Equimine 20161107 - KL----
						,A.SalesPriceCode as SalesPriceCode

						-----Added 20161121 - KL----
						,P.[MailingStdFullStreetAddress] as MailingStdFullStreetAddress
						,P.[OwnerOccupied] as OwnerOccupied
						,P.[PoolCode] as PoolCode


						-----Added 20170202 for Compstak - KL
						,P.[SitusGeoStatusCode] as SitusGeoStatusCode

						-----Added 20170217 for MyListingsAgent - JE
						,a.[FASalePosition]


						-----Added 20171114 KL----
						,NULL as DEEDCMTID
						,NULL as DEEDCMTIDInstNbr
						,NULL as [Loan1CMTID]
						,NULL as [Loan1CMTIDInstNbr]
						,NULL as [Loan2CMTID]
						,NULL as [Loan2CMTIDInstNbr]


FROM            deed_sup a  with(NOLOCK) JOIN [Global].dbo.[County] b with(NOLOCK)
	ON a.FIPS = b.FIPSCode

	--------added to allow fields from other data set to be used in data pulls through tool per BR - KL 201607027

Left outer join Data.dbo.Property as P with(NOLOCK)
on A.FIPS = P.FIPS
and A.FAPropertyID = P.PropertyID

--------------------
	---- Commented OUT 20170403 to allow Sup data to serve as gap fill as well as currency
	--WHERE a.RecordingDt > b.DeedMaxRecordDate

		-----------Commented out 20160812 per M.S.    KL-----------
		--	and (a.FAUCIDFlag is NULL or a.FAUCIDFlag <> 'D')

UNION ALL
/*-------------------------------------------------------------------------------------*/ 

SELECT A.FIPS AS FIPS, A.FAPropertyId AS PROPERTYUNIQUEID, A.APN AS APN, NULL AS APNSEQUENCENBR, NULL AS PREVIOUSPARCELNUMBER, A.
                         TaxAccountNbr AS TAXACCOUNTNUMBER, A.FAMatchInd AS MatchedFlag, A.SitusHouseNbr AS HOUSENUMBER, A.SitusHouseNbr2 AS HOUSENUMBER2, NULL AS HOUSENUMBERSUFFIX, A.
                         SitusDirectionLeft AS DIRECTIONLEFT, A.SitusStreet AS STREETNAME, A.SitusMode AS Suffix, A.SitusDirectionRight AS DIRECTIONRIGHT, A.SitusUnitType AS UNITTYPE, A.SitusUnitNbr AS UNITNUMBER, A.
                         SitusCity AS CITY, A.SitusState AS STATE, A.SitusZIP5 AS ZIPCODE, A.SitusZip4 AS ZIPPLUS4, A.SitusCarrierCode AS CARRIERCODE, CASE WHEN [Borrower1NoParsInd] = 1 THEN 'Y' ELSE NULL 
                         END AS CORPORATEINDICATOR, Borrower1FullName AS BUYERNAMEBORROWERNAME1, BorrowerNameAddendum AS OWNERETALIND, NULL AS OwnerCAREOfNAME, 
                         BorrowerVestingCode AS OWNERSHIPRIGHTSCODE1, Borrower1IDCode AS OWNERRELATIONSHIPTYPE1, Borrower2NoParsInd AS CORPORATEINDICATOR2, 
                         Borrower2FullName AS BUYERNAMEBORROWERNAME2, BorrowerVestingCode AS OWNERSHIPRIGHTSCODE2, Borrower21IDCode AS OWNERRELATIONSHIPTYPE2, 
                         Borrower1LastName AS BUYER1LASTNAME, Borrower1FirstName AS BUYER1FIRSTNAME, Borrower1MiddleInitial AS BUYER1MIDDLEName, Borrower1NameSuffix AS BUYER1SUFFIX, 
                         Borrower2LastName AS BUYER2LASTNAME, Borrower2FirstName AS BUYER2FIRSTNAME, Borrower2MiddleInitial AS BUYER2MIDDLEName, Borrower2NameSuffix AS BUYER2SUFFIX, 
                         BorrowerMailHouseNbr AS MAILHOUSENUMBER, BorrowerMailHouseNbr2 AS MAILHOUSENUMBER2, BorrowerMailHouseNbrSuffix AS MAILHOUSENUMBERSUFFIX, 
                         BorrowerMailLeftDirection AS MAILDIRECTIONLEFT, BorrowerMailStreetName AS MAILSTREETNAME, BorrowerMailMode AS MAILMODE, BorrowerMailRightDirection AS MAILDIRECTIONRIGHT, 
                         BorrowerMailUnitType AS MAILUNITTYPE, BorrowerMailUnitNumber AS MAILUNITNUMBER, BorrowerMailCity AS MAILCITY, BorrowerMailState AS MAILSTATE, BorrowerMailZip5 AS MAILZIPCODE, 
                         BorrowerMailZip4 AS MAILZIPPlus4, BorrowerMailCarrierCode AS MAILCARRIERCODE, TransactionId AS FirstAmericanUniqueTransactionID, RecordingDt AS RECORDINGDATE, ContractDate AS SALEDATE, 
                         DocNbrSrce AS DOCUMENTNUMBER, BookSrce AS RECORDINGBOOK, PageSrce AS RECORDINGPAGE, NULL AS HAWAIILANDCOURTDOCUMENTNUMBER, NULL AS HAWAIITCTCERTIFICATENUMBER, NULL 
                         AS WAEXCISENUMBER, DocumentTypeCode AS DOCUMENTTYPE
						 --,LoanTransType AS TRANSACTIONTYPE
						 , Case when [LoanTransType] = '6' then '1'
								when [LoanTransType] = '7' then '2'
								when [LoanTransType] = '8' then '3'
								when [LoanTransType] = '9' then '4'
								when [LoanTransType] = '10' then '5'
								when [LoanTransType] = '11'then '6'
						 end as TRANSACTIONTYPE


						, NULL AS SELLERNAME, NULL AS SELLERNAMECORPINDICATOR, NULL AS SELLERNAME2, NULL 
                         AS SELLERNAME2CORPINDICATOR, NULL AS SALEAMOUNT, NULL AS TRANSFERTAX, NULL AS PARTIALINTERESTINDICATORFLAG, NULL AS RESALEFLAG, NULL AS NEWCONSTRUCTIONFLAG, NULL 
                         AS INTERFAMILYFLAG, NULL AS FORCLOSUREFLAG, NULL AS REOSALEFLAG, RecordingDt AS FIRSTMORTGAGERECORDINGDATE, ContractDate AS FIRSTMORTGAGEDOCDATE, 
                         replace(DocNbrSrce,'MTG ','') AS FIRSTMORTGAGEDOCUMENTNUMBER, BookSrce AS FIRSTMORTGAGERECORDINGBOOK, PageSrce AS FIRSTMORTGAGERECORDINGPAGE, CASE WHEN LoanAmount > 0 THEN 'MG' ELSE NULL 
                         END AS FIRSTMORTGAGEDETAILEDDOCUMENTTYPE, LoanAmount AS FIRSTMORTGAGEMORTGAGEAMOUNT, Replace(Replace([LenderName], ',', ''), '.', '') AS FIRSTMORTGAGELENDERNAME
						 --, LoanTransType AS FIRSTMORTGAGELOANTYPECODE
						 , Case when [LoanTransType] = '6' then '1'
								when [LoanTransType] = '7' then '2'
								when [LoanTransType] = '8' then '3'
								when [LoanTransType] = '9' then '4'
								when [LoanTransType] = '10' then '5'
								when [LoanTransType] = '11'then '6'
						 end as FIRSTMORTGAGELOANTYPECODE
											 
						 , CASE WHEN [LoanDueDate] IS NOT NULL THEN 'M' ELSE NULL END AS FIRSTMORTGAGETERMCODE, CASE WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 350 AND 365 THEN '360' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 230 AND 
                         250 THEN '240' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 118 AND 122 THEN '120' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) 
                         - 1) BETWEEN 175 AND 185 THEN '180' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 10 AND 13 THEN '12' WHEN (datediff(mm, cast(RecordingDt AS date), 
                         cast(LoanDueDate AS date)) - 1) BETWEEN 22 AND 26 THEN '24' WHEN (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 32 AND 39 THEN '36' WHEN (datediff(mm, 
                         cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) BETWEEN 57 AND 62 THEN '60' ELSE (datediff(mm, cast(RecordingDt AS date), cast(LoanDueDate AS date)) - 1) END AS FIRSTMORTGAGETERM, 
                         LoanDueDate AS FIRSTMORTGAGEDUEDATE, 

						 -----------------Removed 20151104 due to population of FA values vs BK------------
						 --CASE WHEN [TypeFinance] = 'AD' THEN 'ADJ' WHEN [TypeFinance] = 'FI' THEN 'FIX' WHEN [TypeFinance] = 'MU' THEN 'MUL' WHEN [TypeFinance] = 'OT' THEN 'OTH' WHEN [TypeFinance] = 'ST' THEN 'STP' WHEN
						--   [TypeFinance] = 'UN' THEN 'UNK' WHEN [TypeFinance] = 'VA' THEN 'VAR' ELSE [TypeFinance] END AS FIRSTMORTGAGEINTERESTRATETYPE
						  CASE WHEN  [TypeFinance] = 'MULT' then 'MUL' ELSE [TypeFinance] END AS FIRSTMORTGAGEINTERESTRATETYPE

						  , format([LoanInterestRate], '00000') AS FIRSTMORTGAGEINTERESTRATE, CASE WHEN [LenderTypeCode] = 'S' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGESELLERCARRYBACKFLAG, CASE WHEN [LenderTypeCode] = 'P' THEN 'Y' ELSE NULL 
                         END AS FIRSTMORTGAGEPRIVATEPARTYLENDER, CASE WHEN [LoanType] = '8' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGECONSTRUCTIONLOAN, 
                        -----------------Removed 20151104 due to addition of [LoanRefiLoanInd]  field------------
						 --CASE WHEN [LoanType] = '1' THEN 'Y' WHEN [LoanType] = 'N' THEN 'Y' WHEN [LoanType] = 'R' THEN 'Y' WHEN [LoanTransType] = '5' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGEREFIFLAG, 
						 [LoanRefiLoanInd]  AS FIRSTMORTGAGEREFIFLAG

                         ,LoanEquityLoanInd  AS FIRSTMORTGAGEEQUITYFLAG, 

						   -----------------Removed 20151104 due to addition of [LoanHELOCLoanInd]  field------------
                         --CASE WHEN [LoanTransType] = '4' THEN 'Y' ELSE NULL END AS FIRSTMORTGAGEHELOCFLAG

						 [LoanHELOCLoanInd] AS FIRSTMORTGAGEHELOCFLAG
						 
						 , SubordinateLoanInd AS FIRSTMORTGAGEOTHERSUBORDINATELOANFlag, 
                         SecondHomeRider AS FIRSTMORTGAGESecondHomeRider, CondominiumRider AS FIRSTMORTGAGECondominiumRider, MultiFamily4Rider AS FIRSTMORTGAGEMultiFamily4Rider, 
                         PlannedUnitDevelopmentRider AS FIRSTMORTGAGEPlannedUnitDevelopmentRider, LoanAssumabilityRider AS FIRSTMORTGAGEAssumabilityRider, LoanBalloonRider AS FIRSTMORTGAGEBalloonRider, 
                         LoanBiweeklyPaymentRider AS FIRSTMORTGAGEBiweeklyPaymentRider, LoanFixedStepRateRider AS FIRSTMORTGAGEFixedStepRateRider, 
                         LoanGraduatedPaymentRider AS FIRSTMORTGAGEGraduatedPaymentRider, LoanPrePaymentRider AS FIRSTMORTGAGEPrepaymentRider, 
                         LoanRateImprovementRider AS FIRSTMORTGAGERateImprovementRider, LoanAdjRateRider AS FIRSTMORTGAGEAdjustableRateRider, LoanAdjRateIndex AS FIRSTMORTGAGEAdjustableRateIndex, 
                         LoanChangeIndex AS FIRSTMORTGAGEChangeIndex, LoanFirstChangeDateMMDD AS FIRSTMORTGAGEFirstChangeDateMonthDay, LoanFirstChangeDateYYYY AS FIRSTMORTGAGEFirstChangeDateYear, 
                         LoanIntOnlyPeriod AS FIRSTMORTGAGEInterestOnlyPeriod, LoanMaximumInt AS FIRSTMORTGAGEMaximumInterestRate, LoanIntRateNotLess AS FIRSTMORTGAGEMinimumInterestRate, 
                         LoanRateChangeFrequency AS FIRSTMORTGAGERateChangeFrequency, NULL AS SECONDMORTGAGERECORDINGDATE, NULL AS SECONDMORTGAGEDOCDATE, NULL 
                         AS SECONDMORTGAGEDOCUMENTNUMBER, NULL AS SECONDMORTGAGERECORDINGBOOK, NULL AS SECONDMORTGAGERECORDINGPAGE, NULL AS SECONDMORTGAGEDETAILEDDOCUMENTTYPE, NULL 
                         AS SECONDMORTGAGEAMOUNT, NULL AS SECONDMORTGAGELENDERNAME, NULL AS SECONDMORTGAGELOANTYPECODE, NULL AS SECONDMORTGAGETERMCODE, NULL 
                         AS SECONDMORTGAGETERM, NULL AS SECONDMORTGAGEDUEDATE, NULL AS SECONDMORTGAGEINTERESTRATETYPE, NULL AS SECONDMORTGAGEINTERESTRATE, NULL 
                         AS SECONDMORTGAGESELLERCARRYBACK, NULL AS SECONDMORTGAGEPRIVATEPARTYLENDER, NULL AS SECONDMORTGAGECONSTRUCTIONLOAN, NULL AS SECONDMORTGAGEREFIFLAG, NULL 
                         AS SECONDMORTGAGEEQUITYFLAG, NULL AS SECONDMORTGAGEHELOCFLAG, NULL AS SECONDMORTGAGEOTHERSUBORDINATELOANFlag, NULL AS SECONDMORTGAGESecondHomeRider, NULL 
                         AS SECONDMORTGAGECondominiumRider, NULL AS SECONDMORTGAGEMultiFamily4Rider, NULL AS SECONDMORTGAGEPlannedUnitDevelopmentRider, NULL AS SECONDMORTGAGEAssumabilityRider, NULL 
                         AS SECONDMORTGAGEBalloonRider, NULL AS SECONDMORTGAGEBiweeklyPaymentRider, NULL AS SECONDMORTGAGEFixedStepRateRider, NULL AS SECONDMORTGAGEGraduatedPaymentRider, NULL 
                         AS SECONDMORTGAGEPrepaymentRider, NULL AS SECONDMORTGAGERateImprovementRider, NULL AS SECONDMORTGAGEAdjustableRateRider, NULL AS SECONDMORTGAGEAdjustableRateIndex, NULL 
                         AS SECONDMORTGAGEChangeIndex, NULL AS SECONDMORTGAGEFirstChangeDateMonthDay, NULL AS SECONDMORTGAGEFirstChangeDateYear, NULL AS SECONDMORTGAGEInterestOnlyPeriod, NULL 
                         AS SECONDMORTGAGEMaximumInterestRate, NULL AS SECONDMORTGAGEMinimumInterestRate, NULL AS SECONDMORTGAGERateChangeFrequency, NULL AS LotCode, LegalLandLot AS LotNumber, 
                         LegalLotNumber AS LandLot, LegalBlock AS Block, A.LegalSection AS Section, LegalDistrict AS District, A.LegalUnit AS Unit, LegalCityMunicipalityTownship AS CityMunicipalityTownship, 
                         LegalSubdivision AS SubdivisionName, LegalPhaseNumber AS PhaseNo, LegalTractNumber AS TractNo, LegalMeridian AS SecTwnRngMer, NULL AS AssessorsMapRef, 
                         LegalBriefDescription AS LEGALDESCRIPTION, TitleCompanyName AS TITLECOMPANYNAME, 
                          -----------------Removed 20151104 due to population of FA values vs BK------------
						 --CASE WHEN [MultiAPNCode] = '+' THEN '1' WHEN [MultiAPNCode] = 'A' THEN '2' WHEN [MultiAPNCode] = 'E' THEN '3' WHEN [MultiAPNCode] = 'P' THEN '4' WHEN [MultiAPNCode] = 'T' THEN '5' WHEN [MultiAPNCode]
       --                   = 'C' THEN '6' ELSE NULL END AS MULTIAPN
						   [MultiAPNCode] AS MULTIAPN
						  , A.FATimeStamp AS UPDATETIMESTAMP, A.FAUCIDFlag AS UCID, A.FATimeStamp  as FATimeStamp 
						  -----------------Added for Altisource - KL 20160727------------
						 ,P.[PropertyCLassID] as PROPERTYUSECODE
						 ,P.StdLandUseCode as STDLANDUSECODE
						 ,A.BorrowerNameAddendum as BUYERBORROWERNAMEADDENDUM

						  --------------Added for RealEstateU 20160830 - KL----------
						 ,P.[SitusStdFullStreetAddress] AS SitusStdFullStreetAddress

						 

						 ,case when len(A.RecordingDt) < 8 then NULL else Right(LEFT(A.RecordingDt,6),2) end as RecordingDateMonth
						 ,case when len(A.RecordingDt) < 8 then NULL else LEFT(A.RecordingDt,4) end as RecordingDateYear

						 ,case when len(A.ContractDate) < 8 then NULL else Right(LEFT(A.ContractDate,6),2) end as SaleDateMonth
						 ,case when len(A.ContractDate) < 8 then NULL else LEFT(A.ContractDate,4) end as SaleDateYear




						 ,P.[PropertyClassID] AS PropertyClassID
						,P.[SitusCensusTract] AS SitusCensusTract
						,P.[MobileHomeInd] AS MobileHomeInd
						,P.[TimeshareCode] AS TimeshareCode
						,P.[LotSizeAcres] AS LotSizeAcres
						,P.[LotSizeSqFt] AS LotSizeSqFt
						,P.[AssdTotalValue] AS AssdTotalValue
						,P.[AssdLandValue] AS AssdLandValue
						,P.[AssdImprovementValue] AS AssdImprovementValue
						,P.[MarketTotalValue] AS MarketTotalValue
						,P.[MarketValueLand] AS MarketValueLand
						,P.[MarketValueImprovement] AS MarketValueImprovement
						,P.[AssdYear] AS AssdYear
						,P.[BuildingArea] AS BuildingArea
						,P.[BuildingAreaInd] AS BuildingAreaInd
						,P.[SumBuildingSqFt] AS SumBuildingSqFt
						,P.[SumLivingAreaSqFt] AS SumLivingAreaSqFt
						,P.[SumGroundFloorSqFt] AS SumGroundFloorSqFt
						,P.[SumGrossAreaSqFt] AS SumGrossAreaSqFt
						,P.[SumAdjAreaSqFt] AS SumAdjAreaSqFt
						,P.[SumBasementSqFt] AS SumBasementSqFt
						,P.[SumGarageSqFt] AS SumGarageSqFt
						,P.[YearBuilt] AS YearBuilt
						,P.[EffectiveYearBuilt] AS EffectiveYearBuilt
						,P.[Bedrooms] AS Bedrooms
						,P.[TotalRooms] AS TotalRooms
						,P.[BathTotalCalc] AS BathTotalCalc
						,P.[BathFull] AS BathFull
						,P.[BathsParcialNbr] AS BathsParcialNbr
						,P.[BuildingClassCode] AS BuildingClassCode
						,NULL as ArmsLength
						, LoanType AS FIRSTMORTGAGEDETAILEDLOANTYPE
						, NULL AS SECONDMORTGAGEDETAILEDLOANTYPE
						,A.SitusLatitude as SitusLatitude
						,A.SitusLongitude as SitusLongitude
						------Added for Equimine 20161107 - KL----
						,NULL as SalesPriceCode

						-----Added 20161121 - KL----
						,P.[MailingStdFullStreetAddress] as MailingStdFullStreetAddress
						,P.[OwnerOccupied] as OwnerOccupied
						,P.[PoolCode] as PoolCode

						-----Added 20170202 for Compstak - KL
						,P.[SitusGeoStatusCode] as SitusGeoStatusCode

						-----Added 20170217 for MyListingsAgent - JE
						,NULL as [FASalePosition]


						-----Added 20171114 KL----
						,NULL as DEEDCMTID
						,NULL as DEEDCMTIDInstNbr
						,NULL as [Loan1CMTID]
						,NULL as [Loan1CMTIDInstNbr]
						,NULL as [Loan2CMTID]
						,NULL as [Loan2CMTIDInstNbr]


FROM mortgage_sup a with(NOLOCK) JOIN [Global].dbo.[County] b with(NOLOCK)
	ON a.FIPS = b.FIPSCode


	--------added to allow fields from other data set to be used in data pulls through tool per BR - KL 201607027

Left outer join Data.dbo.Property as P with(NOLOCK)
on A.FIPS = P.FIPS
and A.FAPropertyID = P.PropertyID


-------------------------------------------------------------------
	---- Commented OUT to allow all to go to refresh customers for gap fill MAS 20170404
	--WHERE a.RecordingDt > b.SAMMaxRecordDate

	-----------Commented out 20160812 per M.S.    KL-----------
		--and (a.FAUCIDFlag is NULL or a.FAUCIDFlag <> 'D')



























GRANT SELECT ON [dbo].[vDeedMortgageSTD2_20171205] TO [CORP\cbrady] AS [dbo]
