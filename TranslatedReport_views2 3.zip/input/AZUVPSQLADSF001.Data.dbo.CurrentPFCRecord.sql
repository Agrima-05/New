SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Data].[dbo].[CurrentPFCRecord]
AS
SELECT        a.FIPS
		, a.TransactionID
		, a.FAPropertyId
		, a.RecordingDt
		, a.DocumentType
		, a.FAActiveInd
		, a.[OrigLoanCMTIDInstNbr]
		, REPLACE(ltrim(rtrim(Global.[dbo].[RemoveNonAlphaCharacters](a.[ReleaseReason]))),'DefaultDate','Expired') as [ReleaseReason]
FROM            Data.dbo.Foreclosure AS a WITH (NOLOCK) INNER JOIN
                         Data.dbo.Transaction_MaxChronoKey_Foreclosure AS b WITH (NOLOCK) ON a.FIPS = b.Fips AND a.FAPropertyId = b.FAPropertyID AND a.ChronoKey = b.ChronoKey AND 
                         a.ForeclosureUniqueID = b.MAXUniqueID
WHERE        (a.FAActiveInd IS NOT NULL)




