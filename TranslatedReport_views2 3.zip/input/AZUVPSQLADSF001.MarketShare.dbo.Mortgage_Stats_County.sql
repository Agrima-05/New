SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [MarketShare].[dbo].[Mortgage_Stats_County]
AS

SELECT *
  FROM [AZUVPSQLDTDB029.datatree.local].[Fulfillment].[dbo].[Mortgage_Stats_County]


