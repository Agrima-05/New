SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON








CREATE VIEW [Data].[dbo].[vSMR]
AS
SELECT       
	 A.[FIPS] as FIPS,
	A.[PropertyID] as PropertyID,
	A.[FormattedAPN] as APN,
	A.[SitusStdHouseNbr] as SitusStdHouseNbr,
	A.[SitusStdHouseNbrSuffix] as SitusStdHouseNbrSuffix,
	A.[SitusStdDirectionLeft] as SitusStdDirectionLeft,
	A.[SitusStdStreet] as SitusStdStreet,
	A.[SitusStdMode] as SitusStdMode,
	A.[SitusStdDirectionRight] as SitusStdDirectionRight,
	A.[SitusStdUnitType] as SitusStdUnitType,
	A.[SitusStdUnitNbr] as SitusStdUnitNbr,
	A.[SitusStdCity] as SitusStdCity,
	A.[SitusStdState] as SitusStdState,
	A.[SitusStdZIP5] as SitusStdZIP5,
	A.[SitusStdZIP4] as SitusStdZIP4,
	A.[SitusStdCarrierCode] as SitusStdCarrierCode,
	B.[Conventional_Mortgage_Refi_Score] as RefiIntelScore_Conventional ,
    B.[FHA_Refinance_Score] as RefiIntelScore_FHA,
    B.[Home_Equity_Loan_Score] as HomeEquityIntelScore_LineofCredit,
    B.[Cashout_Refi_Score] as RefiIntelScore_Cashout,
    B.[Home_Purchase_Mortgage_Score] as PurchaseIntelScore,
    B.[Total_Liquid_Assets_Score] as LiquidAssetsScore

	---------Added 20190212-----
	,A.SitusSTDFullStreetAddress as SitusSTDFullStreetAddress

	---------Added 20200514-----
	,B.Foreclosure_Score as Foreclosure_Score

	-------Added 20210301----
	,A.OwnerSTD1CorpInd as Owner1CorpInd
	,A.OwnerSTD1LastName as Owner1LastName
	,A.OwnerSTD1FirstName as Owner1FirstName
	,A.OwnerSTD1MiddleName as Owner1MiddleName
	,A.OwnerSTD1Suffix as Owner1Suffix
	,A.OwnerSTD2CorpInd as Owner2CorpInd
	,A.OwnerSTD2LastName as Owner2LastName
	,A.OwnerSTD2FirstName as Owner2FirstName
	,A.OwnerSTD2MiddleName as Owner2MiddleName
	,A.OwnerSTD2Suffix as Owner2Suffix
	,A.OwnerSTDNAME1FULL as OwnerNAME1FULL
	,A.OwnerSTDNAME2FULL as OwnerNAME2FULL



	FROM  
	Data.dbo.Property as A WITH (nolock)
	join Data.dbo.SMR as B with(NOLOCK)
	on A.PropertyID = B.[FAM_Property_Id]


	
	















GRANT SELECT ON [dbo].[vSMR] TO [CORP\cbrady] AS [dbo]
