SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [SSISDB].[internal].[current_user_readable_operations]
AS
SELECT     [object_id] AS [ID]
FROM       [catalog].[effective_object_permissions]
WHERE      [object_type] = 4
           AND  [permission_type] = 1

