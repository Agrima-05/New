SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data_Archive].[dbo].[vAVM_History_II]
AS

SELECT FIPSCode
	, Final_Value
	, [low] as Low_Value
	, [high] as High_Value
	, [score] as ConfidenceScore
	, [score] as StandardDeviation
	, convert(datetime,[VALUATION_DATE]) as VALUATION_DATE
	, [PropertyID]
FROM  [dbo].[valuation_hist_2017_new]

UNION ALL

SELECT FIPSCode
	, Final_Value
	, [low] as Low_Value
	, [high] as High_Value
	, [score] as ConfidenceScore
	, [score] as StandardDeviation
	, convert(datetime,[VALUATION_DATE]) as VALUATION_DATE
	, [PropertyID]
FROM  [dbo].[valuation_hist_2018_new]



