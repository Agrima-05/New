SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vAVM_BKFS]
AS
SELECT      
a.[FIPS] as FIPS,
a.[PropertyID] as PropertyID,
a.[Assessor_Parcel_Number] as Assessor_Parcel_Number,
b.[SitusStdHouseNbr] as SitusStdHouseNbr,
b.[SitusStdHouseNbr2] as SitusStdHouseNbr2,
b.[SitusStdHouseNbrSuffix] as SitusStdHouseNbrSuffix,
b.[SitusStdDirectionLeft] as SitusStdDirectionLeft,
b.[SitusStdStreet] as SitusStdStreet,
b.[SitusStdMode] as SitusStdMode,
b.[SitusStdDirectionRight] as SitusStdDirectionRight,
b.[SitusStdUnitType] as SitusStdUnitType,
b.[SitusStdUnitNbr] as SitusStdUnitNbr,
b.[SitusStdCity] as SitusStdCity,
b.[SitusStdState] as SitusStdState,
b.[SitusStdZIP5] as SitusStdZIP5,
b.[SitusStdZIP4] as SitusStdZIP4,
b.[SitusStdCarrierCode] as SitusStdCarrierCode,
[SafeValueVal] as SafeValueVal,
[SafeValueMin] as SafeValueMin,
[SafeValueMax] as SafeValueMax,
[SafeValueConfidenceScore] as SafeValueConfidenceScore,
[SafeValueFSD] as SafeValueFSD,
[ValueSureVal] as ValueSureVal,
[ValueSureValMin] as ValueSureValMin,
[ValueSureValMax] as ValueSureValMax,
[ValueSureFSD] as ValueSureFSD,
[ValueSureComps] as ValueSureComps,
[SiteXVal] as SiteXVal,
[SitexValMin] as SitexValMin,
[SitexValMax] as SitexValMax,
[SitexValConfidence] as SitexValConfidence,
[SiteXFSD] as SiteXFSD,
[EZVal] as EZVal,
[EZValMin] as EZValMin,
[EZValMax] as EZValMax,
[EZValConfidenceScore] as EZValConfidenceScore,
[EZValFSD] as EZValFSD,
[Valuation_Date] as Valuation_Date,
[BKFS_Internal_PID] as BKFS_Internal_PID
FROM DATA.dbo.[AVM_BKFS] a with(nolock) JOIN DATA.dbo.[Property] b with(NOLOCK)
on a.Fips = b.fips
and a.PropertyID = b.PropertyID

GRANT SELECT ON [dbo].[vAVM_BKFS] TO [CORP\cbrady] AS [dbo]
