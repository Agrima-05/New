SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [zCust_ADS__S11_Foreclosure].[dbo].[FAMS_NOD]
AS
SELECT INPUTKEY, INPUTApn, INPUTAddress, INPUTCity, INPUTState, INPUTZip, PropertyAddress, City, State, ZipCode, ReportDate, CoverageStatus, AddressStandardization, 
                  PropertyStatus, TransactionStatus, Recording_Date, Document_Date, Document_Nbr, Document_Type, Borrower_Defendant_Name, Trustee_Attorney_Plaintiff,
				  Lender_Beneficiary_Name, Default_Amount, 
                  Default_Date, Original_Loan_Date, Original_Loan_Amount, Original_Loan_Document_Nbr
FROM     dbo.x_Custom_OUTPUT



