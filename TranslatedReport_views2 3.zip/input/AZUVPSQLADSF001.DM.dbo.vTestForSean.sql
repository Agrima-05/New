SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [DM].[dbo].[vTestForSean]
AS
/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [State]
      ,[Fips]
      ,[County Name]
      ,[Parcel_Raw]
      ,[Missing_Parcels_On_Spot]
      ,[Missing_Parcels_On_Regrid]
  FROM [AZUVPSQLDTDB034].[Spot].[dbo].[vSpotGap1]

