SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [prod_Listing].[dbo].[v_Altisource_Listing]
AS
			Select
			REPLACE([Property Address],char(9),'') as [Property Address],
			REPLACE([Property City],char(9),'') as [Property City],
			REPLACE([Property State],char(9),'') as [Property State],
			REPLACE([Property Zip],char(9),'') as [Property Zip],
			REPLACE([Property Zip + 4],char(9),'') as [Property Zip + 4],
			CASE WHEN PM_APN is NULL then REPLACE([Assessor's Parcel Identification Number],char(9),'') ELSE REPLACE(PM_APN,char(9),'') END AS [Assessor's Parcel Identification Number],
			REPLACE([County FIPS],char(9),'') as [County FIPS],
			REPLACE(PM_PropertyID,char(9),'') AS [Internal FA Property Ref ID],
			REPLACE([Property Type],char(9),'') as [Property Type],
			REPLACE([Property Sub-Type],char(9),'') as [Property Sub-Type],
			REPLACE([Lot Size (Sq Ft)],char(9),'') as [Lot Size (Sq Ft)],
			REPLACE([Home Size (Sq Ft)],char(9),'') as [Home Size (Sq Ft)],
			REPLACE([Home or Building Style],char(9),'') as [Home or Building Style],
			REPLACE([Heating Type],char(9),'') as [Heating Type],
			REPLACE([Heating Fuel Type],char(9),'') as [Heating Fuel Type],
			REPLACE([Cooling Type],char(9),'') as [Cooling Type],
			REPLACE([Cooling Fuel Type],char(9),'') as [Cooling Fuel Type],
			REPLACE([Number of Stories],char(9),'') as [Number of Stories],
			REPLACE([Year Built],char(9),'') as [Year Built],
			REPLACE([Roof Type],char(9),'') as [Roof Type],
			REPLACE([Exterior Construction],char(9),'') as [Exterior Construction],
			REPLACE([Number of Bedrooms],char(9),'') as [Number of Bedrooms],
			REPLACE([Number of Bathrooms],char(9),'') as [Number of Bathrooms],
			REPLACE([Number of Garages],char(9),'') as [Number of Garages],
			REPLACE([Garage Type],char(9),'') as [Garage Type],
			REPLACE([Pool Features],char(9),'') as [Pool Features],
			REPLACE([View Features],char(9),'') as [View Features],
			REPLACE([Price per Square Feet],char(9),'') as [Price per Square Feet],
			REPLACE([Porch],char(9),'') as [Porch],
			REPLACE([Patio],char(9),'') as [Patio],
			REPLACE([Deck],char(9),'') as [Deck],
			REPLACE([Basement],char(9),'') as [Basement],
			REPLACE([Air Conditioner],char(9),'') as [Air Conditioner],
			REPLACE([Number of Fireplaces],char(9),'') as [Number of Fireplaces],
			REPLACE([Presence of Fireplace],char(9),'') as [Presence of Fireplace],
			REPLACE([Fireplace Description],char(9),'') as [Fireplace Description],
			REPLACE([Interior Features],char(9),'') as [Interior Features],
			REPLACE([Exterior Features],char(9),'') as [Exterior Features],
			REPLACE([Existing Structures],char(9),'') as [Existing Structures],
			REPLACE([Property Details],char(9),'') as [Property Details],
			REPLACE([Lot Features],char(9),'') as [Lot Features],
			REPLACE([Zoning],char(9),'') as [Zoning],
			REPLACE([Neighborhood],char(9),'') as [Neighborhood],
			REPLACE([School District],char(9),'') as [School District],
			REPLACE([Elementary School],char(9),'') as [Elementary School],
			REPLACE([Middle School],char(9),'') as [Middle School],
			REPLACE([High School],char(9),'') as [High School],
			REPLACE([Appliances],char(9),'') as [Appliances],
			REPLACE([Approximate Lot Dimensions],char(9),'') as [Approximate Lot Dimensions],
			REPLACE([Topogrophy],char(9),'') as [Topogrophy],
			REPLACE([Waterfront Features],char(9),'') as [Waterfront Features],
			REPLACE([Water],char(9),'') as [Water],
			REPLACE([Water Source],char(9),'') as [Water Source],
			REPLACE([Water Amenities],char(9),'') as [Water Amenities],
			REPLACE([Water Access],char(9),'') as [Water Access],
			REPLACE([Water Heater],char(9),'') as [Water Heater],
			REPLACE([FA Calculated Days on Market],char(9),'') as [FA Calculated Days on Market],
			REPLACE([Current Original Listing Date],char(9),'') as [Current Original Listing Date],
			REPLACE([Listing Number],char(9),'') as [Listing Number],
			REPLACE([Status],char(9),'') as [Status],
			REPLACE([Status Sub Type],char(9),'') as [Status Sub Type],
			REPLACE([Rental Ind],char(9),'') as [Rental Ind],
			REPLACE([Current Listing Price],char(9),'') as [Current Listing Price],
			REPLACE([Sold Price],char(9),'') as [Sold Price],
			REPLACE([Sold Date],char(9),'') as [Sold Date],
			REPLACE([FA Adjusted Sold Price],char(9),'') as [FA Adjusted Sold Price],
			REPLACE([FA Sold Price Range],char(9),'') as [FA Sold Price Range],
			REPLACE([Listing Agent License Number],char(9),'') as [Listing Agent License Number],
			REPLACE([Listing Agent Name],char(9),'') as [Listing Agent Name],
			REPLACE([Listing Agent Address],char(9),'') as [Listing Agent Address],
			REPLACE([Listing Agent Phone],char(9),'') as [Listing Agent Phone],
			REPLACE([Listing Agent Email],char(9),'') as [Listing Agent Email],
			REPLACE([Office Name],char(9),'') as [Office Name],
			REPLACE([Office Address],char(9),'') as [Office Address],
			REPLACE([Office Phone],char(9),'') as [Office Phone],
			REPLACE([Office Email],char(9),'') as [Office Email],
			REPLACE([Listing Tracking ID],char(9),'') as [Listing Tracking ID],
			REPLACE([FA Unique Listing Identifier - Ref ID],char(9),'') as [FA Unique Listing Identifier - Ref ID],
			REPLACE([Update Timestamp],char(9),'') as [Update Timestamp],
			REPLACE([Add, Change, Delete Indicator],char(9),'') as [Add, Change, Delete Indicator]



	FROM     dbo.Altisource_WORK











