SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON








CREATE VIEW [HOA].[OA].[ADBScrub] 
AS
SELECT a.*
	,(
		SELECT count(1)
		FROM ADB.dbo.MD_Deed d
		WHERE d.FIPS = a.FIPS
			AND d.APN = a.APN
			AND CondominiumRider = 'Y'
		) + (
		SELECT count(1)
		FROM ADB.dbo.MD_SAM s
		WHERE s.FIPS = a.FIPS
			AND s.APN = a.APN
			AND CondominiumRider = 'Y'
		) AS CondoRider
	,(
		SELECT MAX(RecordingDate)
		FROM (
			SELECT RecordingDate
			FROM ADB..MD_Deed d
			WHERE d.FIPS = a.FIPS
				AND d.APN = a.APN
				AND d.CondominiumRider = 'Y'
			
			UNION ALL
			
			SELECT RecordingDate
			FROM ADB..MD_SAM s
			WHERE s.FIPS = a.FIPS
				AND s.APN = a.APN
				AND s.CondominiumRider = 'Y'
			) r
		) AS CondoRiderLastRecording
	,(
		SELECT count(1)
		FROM ADB.dbo.MD_Deed d
		WHERE d.FIPS = a.FIPS
			AND d.APN = a.APN
			AND PlannedUnitDevelopmentRider = 'Y'
		) + (
		SELECT count(1)
		FROM ADB.dbo.MD_SAM s
		WHERE s.FIPS = a.FIPS
			AND s.APN = a.APN
			AND PlannedUnitDevelopmentRider = 'Y'
		) AS PudRider
	,(
		SELECT MAX(RecordingDate)
		FROM (
			SELECT RecordingDate
			FROM ADB..MD_Deed d
			WHERE d.FIPS = a.FIPS
				AND d.APN = a.APN
				AND d.PlannedUnitDevelopmentRider = 'Y'
			
			UNION ALL
			
			SELECT RecordingDate
			FROM ADB..MD_SAM s
			WHERE s.FIPS = a.FIPS
				AND s.APN = a.APN
				AND s.PlannedUnitDevelopmentRider = 'Y'
			) r
		) AS PudRiderLastRecording
, Case When 		StandardizedLandUseCode IN (
			--'0024' --Common Area (misc.)
			'1004' --Condominium (Residential)
			,'1009' --Planned Unit Development (PUD) (Residential)
			,'1010' --Residential Common Area (Condo/PUD/etc.)
			--,'1114' --Residential Condominium Development (Association Assessment)
			) THEN 1 ELSE 0 END as LandUseScrub
, Case When
(
			StandardizedLandUseCode IN (
				'0024' --Common Area (misc.)
				--'1004' --Condominium (Residential)
				--,'1009' --Planned Unit Development (PUD) (Residential)
				--,'1010' --Residential Common Area (Condo/PUD/etc.)
				,'1114' --Residential Condominium Development (Association Assessment)
				--,
				,'1000' --Residential (General) (Single)
				,'1001' --Single Family Residential
				,'1002' --Townhouse (Residential)
				,'1003' --Cluster home (Residential)
				,'1005' --Cooperative (Residential)
				,'1006' --Mobile home
				,'1007' --Row house (Residential)
				,'1008' --Rural Residence (Agricultural)
				,'1013' --Bungalow (Residential)
				,'1014' --Zero Lot Line (Residential)
				,'1016' --Manufactured, Modular, Pre-Fabricated Homes
				,'1017' --Patio Home
				,'1100' --Residential Income (General) (Multi-Family)
				,'1101' --Duplex (2 units, any combination)
				,'1102' --Triplex (3 units, any combination)
				,'1103' --Quadruplex (4 units, any combination)
				,'1104' --Apartment house (5+ units)
				,'1105' --Apartment house (100+ units)
				,'1106' --Garden Apt, Court Apt (5+ units)
				,'1107' --Highrise Apartments
				,'1109' --Mobile Home Park, Trailer Park
				,'1110' --Multi-Family Dwellings (Generic, any combination 2+)
				,'1112' --Apartments (generic)
				,'1999' --Single Family Residential
				,'8000' --Vacant Land (General)
				,'8001' --Residential-Vacant Land
				,'8004' --Private Preserve, Open Space-Vacant Land (Forest Land, Conservation)
				,'8007' --Multi-Family-Vacant Land
				)
			AND (
				(
					(
						(
							LegalSubdivisionName LIKE 'CONDO[^NRT]%'
							OR LegalSubdivisionName LIKE '% CONDO[^NRT]%'--surname
							OR LegalSubdivisionName LIKE '% CONDO'
							OR LegalSubdivisionName LIKE '% CONDO %'
							OR LegalSubdivisionName LIKE 'CONDO %'
							)
						OR LegalSubdivisionName LIKE '%[T ]OWN% ASS%'
						OR LegalSubdivisionName LIKE 'OWN% ASS%'
						--OR LegalSubdivisionName LIKE '%OWN% ASS%'
						OR LegalSubdivisionName LIKE '%HOME%ASS%'
						OR LegalSubdivisionName LIKE '%PLAN%UNIT%DEV%'
						OR (
							LegalSubdivisionName LIKE '% PUD %'
							OR LegalSubdivisionName LIKE 'PUD %'
							OR LegalSubdivisionName LIKE '% PUD'
							)
						OR (
							LegalSubdivisionName LIKE '% [CHP]OA %'
							OR LegalSubdivisionName LIKE '[CHP]OA %'
							OR LegalSubdivisionName LIKE '% [CHP]OA'
							)
						OR LegalSubdivisionName LIKE '%TWNH[SM]%'
						)
					AND NOT (
						LegalSubdivisionName LIKE '%COMMERCIAL%'
						OR LegalSubdivisionName LIKE '%INDUSTRIAL%'
						OR (
							LegalSubdivisionName LIKE '% INDST %'
							OR LegalSubdivisionName LIKE 'INDST %'
							OR LegalSubdivisionName LIKE '% INDST'
							)
						OR LegalSubdivisionName LIKE '%MEDICAL%'
						OR LegalSubdivisionName LIKE '%OFFICE%'
						OR LegalSubdivisionName LIKE '%BUSINESS%'
						OR LegalSubdivisionName LIKE '%HOUSING ASS%'
						OR LegalSubdivisionName LIKE '%ASSESSOR%'
						OR LegalSubdivisionName LIKE '%NURSING%'
						)
					)
				OR (
					(
						(
							LegalBriefDescription LIKE 'CONDO[^NRT]%'
							OR LegalBriefDescription LIKE '% CONDO[^NRT]%'--surname
							OR LegalBriefDescription LIKE '% CONDO'
							OR LegalBriefDescription LIKE '% CONDO %'
							OR LegalBriefDescription LIKE 'CONDO %'
							)
						OR LegalBriefDescription LIKE '%[T ]OWN% ASS%'
						OR LegalBriefDescription LIKE 'OWN% ASS%'
						--OR LegalBriefDescription LIKE '%OWN% ASS%'
						OR LegalBriefDescription LIKE '%HOME%ASS%'
						OR LegalBriefDescription LIKE '%PLAN%UNIT%DEV%'
						OR (
							LegalBriefDescription LIKE '% PUD %'
							OR LegalBriefDescription LIKE 'PUD %'
							OR LegalBriefDescription LIKE '% PUD'
							)
						OR (
							LegalBriefDescription LIKE '% [CHP]OA %'
							OR LegalBriefDescription LIKE '[CHP]OA %'
							OR LegalBriefDescription LIKE '% [CHP]OA'
							)
						OR LegalBriefDescription LIKE '%TWNH[SM]%'
						)
					AND NOT (
						LegalBriefDescription LIKE '%COMMERCIAL%'
						OR LegalBriefDescription LIKE '%INDUSTRIAL%'
						OR (
							LegalBriefDescription LIKE '% INDST %'
							OR LegalBriefDescription LIKE 'INDST %'
							OR LegalBriefDescription LIKE '% INDST'
							)
						OR LegalBriefDescription LIKE '%MEDICAL%'
						OR LegalBriefDescription LIKE '%OFFICE%'
						OR LegalBriefDescription LIKE '%BUSINESS%'
						OR LegalBriefDescription LIKE '%HOUSING ASS%'
						OR LegalBriefDescription LIKE '%ASSESSOR%'
						OR LegalBriefDescription LIKE '%NURSING%'
						)
					)
				OR (
					(
						(
							AssesseeName LIKE 'CONDO[^NRT]%'
							OR AssesseeName LIKE '% CONDO[^NRT]%'--surname
							OR AssesseeName LIKE '% CONDO'
							OR AssesseeName LIKE '% CONDO %'
							OR AssesseeName LIKE 'CONDO %'
							)
						OR AssesseeName LIKE '%[T ]OWN% ASS%'
						OR AssesseeName LIKE 'OWN% ASS%'
						--OR AssesseeName LIKE '%OWN% ASS%'
						OR AssesseeName LIKE '%HOME%ASS%'
						OR AssesseeName LIKE '%PLAN%UNIT%DEV%'
						OR (
							AssesseeName LIKE '% PUD %'
							OR AssesseeName LIKE 'PUD %'
							OR AssesseeName LIKE '% PUD'
							)
						OR (
							AssesseeName LIKE '% [CHP]OA %'
							OR AssesseeName LIKE '[CHP]OA %'
							OR AssesseeName LIKE '% [CHP]OA'
							)
						OR AssesseeName LIKE '%TWNH[SM]%'
						)
					AND NOT (
						AssesseeName LIKE '%COMMERCIAL%'
						OR AssesseeName LIKE '%INDUSTRIAL%'
						OR (
							AssesseeName LIKE '% INDST %'
							OR AssesseeName LIKE 'INDST %'
							OR AssesseeName LIKE '% INDST'
							--AND (
							--	AssesseeName NOT LIKE '%[A-Z]INDST%'
							--	AND AssesseeName NOT LIKE '%INDST[A-Z]%'
							--	)
							)
						OR AssesseeName LIKE '%MEDICAL%'
						OR AssesseeName LIKE '%OFFICE%'
						OR AssesseeName LIKE '%BUSINESS%'
						OR AssesseeName LIKE '%HOUSING ASS%'
						OR AssesseeName LIKE '%ASSESSOR%'
						OR AssesseeName LIKE '%NURSING%'
						OR AssesseeName LIKE '%CITY OF %'
						OR AssesseeName LIKE '%COUNTY OF %'
						OR AssesseeName LIKE '%STATE OF %'
						)
					AND (
						AssesseeVestingIDCode = 'CO'
						OR AssesseeNameType = 'B'
						)
					)
				AND AssesseeName2 IS NULL
				AND OwnerOccupiedSFRCondo IS NULL
				AND CalifHomeownerExemption IS NULL
				AND TaxExemptionCode IS NULL
				)
			) THEN 1 ELSE 0 END as AssrScrub
FROM ADB.dbo.MD_Assessment a








