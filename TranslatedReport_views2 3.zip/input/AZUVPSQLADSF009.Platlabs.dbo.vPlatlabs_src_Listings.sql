SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Platlabs].[dbo].[vPlatlabs_src_Listings]
AS

	SELECT NULL as srcListingID
		,l.[mls_id] as srcMLSID
		,l.[mls_listing_id] as srcMLSListingID
		,CASE WHEN [is_shortsale] = '1' THEN 4
		WHEN [is_foreclosure] = '1' THEN 3
		ELSE 1 END as SrcListingTypeID
		,l.[address] as StreetAddress
		,l.[city] as City
		,l.[state] as State
		,l.[zip] as Zip
		,[price] as ListingAmt
		,[mls_list_date] as ListDate
		,case when pa.[mlskey] is NULL then la.agent_id ELSE pa.[mlskey] End as srcAgentID
		,CASE WHEN pa.dp_member_id is NULL then la.agent_id ELSE pa.dp_member_id End as srcMLSAgentID
		,CASE WHEN pa.[first_name] is NULL THEN la.agent_FirstName ELSE pa.[first_name] END as AgentFirstName
		,CASE WHEN pa.[last_name] is NULL THEN la.agent_LastName ELSE pa.[last_name] END as AgentLastName
		,CASE WHEN pa.[preferred_phone_number] is NULL THEN la.agent_Phone ELSE pa.[preferred_phone_number] END as AgentPhone
		,lo.[mlskey] as srcOfficeID
		,CASE WHEN pa.[dp_office_id] is NULL THEN la.office_id ELSE pa.[dp_office_id] END as srcMLSOfficeID
		,lo.[full_name] as OfficeName
		,lo.[address] as OfficeAddress
		,lo.[city] as OfficeCity
		,lo.[state] as OfficeState
		,lo.[zip] as OfficeZip
		,[created_date] as DateCreated
		,l.[status] as srcListingStatusID
		,[close_date] as closedDate
		,[status_change_date] as DateStatusChange
		,CASE WHEN l.[status] in('closed','sold') Then 1 ELSE 0 END as isClosed
		,NULL as isIgnored
		,[unit_number] as AddressUnit
		,so.dp_office_id as SellOfficeID
		,so.[full_name] as SellOfficeName
		,so.[address] as SellOfficeStreetName1
		,so.[city] as SellOfficeCity
		,so.[zip] as SellOfficeZip
		,so.[state] as SellOfficeState
		,modified_date as LastModifiedDate
		,Null as isDuplicate
		,NULL as isDuplicateModifiedDate
		,l.mls_id
		,l.REF_ID
		,l.PropertyID
		FROM src_PlatLabs.listing.ListingsRaw l with(NOLOCK)
						LEFT OUTER JOIN src_Platlabs.agent.Platlabs_Agents pa with(NOLOCK) on l.[listing_agent_uid] = pa.[uid]
						LEFT OUTER JOIN src_Platlabs.agent.ListAgents la with(NOLOCK) on l.[mls_id] = la.[mls_id] and l.[mls_listing_id] = la.[mls_listing_id]
						LEFT OUTER JOIN src_Platlabs.agent.CoAgent ca with(NOLOCK) on l.[mls_id] = ca.[mls_id] and l.[mls_listing_id] = ca.[mls_listing_id]
						LEFT OUTER JOIN src_Platlabs.agent.SellingAgents sa with(NOLOCK) on l.[mls_id] = sa.[mls_id] and l.[mls_listing_id] = sa.[mls_listing_id]
						LEFT OUTER JOIN src_Platlabs.agent.CoSellingAgents sca with(NOLOCK) on l.[mls_id] = sca.[mls_id] and l.[mls_listing_id] = sca.[mls_listing_id]
						LEFT OUTER JOIN src_Platlabs.Office.Platlabs_Offices lo with(NOLOCK) on l.mls_id = lo.mls_id and l.[listing_office_uid] = lo.[uid]
						LEFT OUTER JOIN src_Platlabs.Office.Platlabs_Offices so with(NOLOCK) on l.mls_id = so.mls_id and l.[listing_office_uid] = so.[uid]

				 

