SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vSMR_RAW]
AS

SELECT  *, FIPS_Code as FIPS from  Data.dbo.SMR with(NOLOCK)
	


GRANT SELECT ON [dbo].[vSMR_RAW] TO [CORP\cbrady] AS [dbo]
