SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [HOA].[OA].[AssrScrub]
AS
SELECT 
      [FIPS]
      ,[REF_ID]
	  ,[UNFORMATTED_APN]
      ,[SUBDIV_TRACT_NBR]
      ,[SUBDIV_PLAT_BOOK]
      ,[SUBDIV_PLAT_PAGE]
      ,[SUBDIV_NAME]
	  ,[BLOCK_NBR]
      ,[SITUS_CITY]
      ,[SITUS_ZIP_CODE]
      ,[Land_Use]
	  , SITUS_HOUSE_NBR 
	  , SITUS_STREET_NAME
	  , SITUS_DIRECTION
	  , SITUS_QUADRANT
	  , SITUS_MODE
	  , SITUS_UNIT_NBR
, (Select count(distinct oap.OwnerAssociationId) from Staging.OwnerAssociationProperty oap inner join Staging.OwnerAssociation o on o.Id = oap.OwnerAssociationId where oap.REF_ID = a.REF_ID and oap.SourceId = 1 and oap.StatusId NOT IN (3, 6)) As FAST
, (Select count(distinct oap.OwnerAssociationId) from Staging.OwnerAssociationProperty oap inner join Staging.OwnerAssociation o on o.Id = oap.OwnerAssociationId where oap.REF_ID = a.REF_ID and oap.SourceId = 12 and oap.StatusId NOT IN (3, 6)) As FASTPhrase
, (Select count(distinct oap.OwnerAssociationId) from Staging.OwnerAssociationProperty oap where oap.REF_ID = a.REF_ID and oap.SourceId IN (4, 10)) As PreForeclosure
, (Select count(1) from Staging.OwnerAssociationProperty oap where oap.REF_ID = a.REF_ID and oap.SourceId IN (7,8) and COA = 1 and oap.StatusId NOT IN (3, 6)) As CondoRider
, (Select count(1) from Staging.OwnerAssociationProperty oap where oap.REF_ID = a.REF_ID and oap.SourceId IN (7,8) and PUD = 1 and oap.StatusId NOT IN (3, 6)) As PUDRider
, (Select count(1) from Staging.OwnerAssociationFee oaf where oaf.REF_ID = a.REF_ID and oaf.FIPS = a.FIPS and oaf.SourceId = 5) As FAMLSFees
, (Select count(1) from Staging.OwnerAssociationFee oaf where oaf.REF_ID = a.REF_ID and oaf.FIPS = a.FIPS and oaf.SourceId = 6) As ACIWebFees
, (Select count(distinct oap.OwnerAssociationId) from Staging.OwnerAssociationProperty oap inner join Staging.OwnerAssociation o on o.Id = oap.OwnerAssociationId where oap.REF_ID = a.REF_ID and oap.SourceId IN  (9, 13, 14, 15) and oap.StatusId NOT IN (3, 6)) As SecondPassOA
, (Select count(1) from Staging.OwnerAssociationProperty oap where oap.REF_ID = a.REF_ID and oap.SourceId = 2 and oap.StatusId NOT IN (3, 6)) as AssrScrub
, (Select count(distinct oap.OwnerAssociationId) from Staging.OwnerAssociationProperty oap inner join Staging.OwnerAssociation o on o.Id = oap.OwnerAssociationId where oap.REF_ID = a.REF_ID and oap.SourceId = 11 and oap.StatusId NOT IN (3, 6)) As Mastered
FROM Assr.dbo.Assr a
Where REF_ID > 0

