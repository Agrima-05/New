SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [DigitalMap].[dbo].[BldgFtPrint]
AS
SELECT [PropertyId]
,Convert(geometry,[BuildingCombineGeometry4269]) as BuildingCombineGeometry4269
,[fips]
,[FARooftopLatitude]
,[FARooftopLongitude]
,[BuildingEstFootprintSqFt]
,[NumberofBuildings]
FROM            dbo.BuildingFootprint

