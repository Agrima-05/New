SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
/****** Script for SelectTopNRows command from SSMS  ******/
create view [zCust_Exxon].[dbo].[vTicket_7218_Data_Parcel]
as 
SELECT [FIPS]
      ,[PropertyID]
      ,[APN]
      ,[SitusFullStreetAddress]
      ,[SitusCity]
      ,[SitusState]
      ,[SitusZIP5]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusGeoStatusCode]
      ,[PropertyClassID]
      ,[LandUseCode]
      ,[Owner1CorpInd]
      ,[OwnerNAME1FULL]
      ,[OwnerOccupied]
      ,[AssdTotalValue]
      ,[Procision Direct] as [ProcisionDirect]
      ,[FATimeStamp]
      ,[FARecordType]
     -- ,[Parcel]
      ,[Parcel] as Geom
  FROM [zCust_Exxon].[dbo].[Ticket_7218_Data]
