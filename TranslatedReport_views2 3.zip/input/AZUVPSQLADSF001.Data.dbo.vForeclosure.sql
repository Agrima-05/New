SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE VIEW [Data].[dbo].[vForeclosure]
AS
		SELECT a.FIPS
			, a.ForeclosureUniqueID
			, a.TransactionId
			, a.RecordingDt
			, a.DocumentYear
			, a.DocNbrSrce
			, a.BookSrce
			, a.PageSrce
			, a.YearDocNbrFrmt
			, a.DocNbrFrmt
			, a.BkPgFrmt
			, a.YearBkPgFrmt
			, a.APN
			, a.APNSrce
			, a.MultiAPNCode
			, a.MatchSrce
			, a.TaxAccountNbr
			, a.DocumentType
			, a.LoanNumber
			, a.CaseNumber
			, a.ContractDate
			, a.DefaultDate
			, a.CurrentBeneficiary
			, a.CurrentBenCodeLenderType
			, a.LoanRecordingDt
			, a.LoanDocumentNbr
			, a.LoanBook
			, a.LoanPage
			, a.UnpaidBalance
			, a.PastDueAmount
			, a.PaymentDueDt
			, a.TitleCompany
			, a.MERSIndicator
			, a.NODLegalSubdivision
			, a.NODLegalBlock
			, a.NODLegalBriefDescr
			, a.NODLegalLot
			, a.NODRecordingExpiryDate
			, a.NODRecordingSEQNbr
			, a.AuctionDate
			, a.AuctionTime
			, a.AuctionLocation
			, a.AuctionCity
			, a.AuctionMinBidAmt
			, a.OrigBenCodeLenderType
			, a.OrigBeneficiaryLender
			, a.OrigLoanAmt
			, a.OrigNODRecordingDt
			, a.OrigNODDocumentNbr
			, a.OrigNODBook
			, a.OrigNODPage
			, a.OrigNODExpiryDate
			, a.SitusStdFullStreetAddress
			, a.SitusStdHouseNbr
			, a.SitusStdHouseNbr2
			, a.SitusStdHouseNbrSuffix
			, a.SitusStdDirectionLeft
			, a.SitusStdStreet
			, a.SitusStdMode
			, a.SitusStdDirectionRight
			, a.SitusStdUnitNbr
			, a.SitusStdCity
			, a.SitusStdState
			, a.SitusStdZIP5
			, a.SitusStdZIP4
			, a.SitusStdLatitude
			, a.SitusStdLongitude
			, a.SitusStdCarrierCode
			, a.SitusStdCensusTractBlock
			, a.SitusStdUnitType
			, a.SitusStdMatchCode
			, a.ContactFullName
			, a.ContactInputFirstMiddleName
			, a.ContactInputLastNameOrCorp
			, a.ContactCompanyName
			, a.ContactCorpType
			, a.ContactFirstname
			, a.ContactLastName
			, a.ContactMiddlename
			, a.ContactNoParsInd
			, a.ContactPrefix
			, a.MailAttentionTo
			, a.MailingFullStreetAddress
			, a.MailingHouseNbr
			, a.MailingHouseNbr2
			, a.MailingHouseNbrSuffix
			, a.MailingDirectionLeft
			, a.MailingStreet
			, a.MailingMode
			, a.MailingDirectionRight
			, a.MailingUnitNbr
			, a.MailingCity
			, a.MailingState
			, a.MailingZIP5
			, a.MailingZIP4
			, a.MailingCarrierCode
			, a.MailingUnitType
			, a.MailingMatchCode
			, a.TrusteePhone
			, a.TrusteeFullAddress
			, a.TrusteeAptNumber
			, a.TrusteeCity
			, a.TrusteeState
			, a.TrusteeZip5
			, a.TrusteeZip4
			, a.TrusteeFirstNameMiddleInitial
			, a.TrusteeLastNameorCorp
			, a.TrusteeMailCareOfName
			, a.TrusteeSalesNumber
			, a.TrustorBorrowerFullName
			, a.TrustOrBorrower1FirstNameMi
			, a.TrustOrBorrower1LastNameOrCorp
			, a.TrustOrBorrower1IdCode
			, a.TrustOrBorrower2FirstNameMi
			, a.TrustOrBorrower2LlstNameOrCorp
			, a.TrustOrBorrower2IdCode
			, a.TrustOrBorrower1CompanyName
			, a.TrustOrBorrower1CorpType
			, a.TrustOrBorrower1FirstName
			, a.TrustOrBorrower1LastName
			, a.TrustOrBorrower1MiddleInitial
			, a.TrustOrBorrower1NoParsInd
			, a.TrustOrBorrower2CompanyName
			, a.TrustOrBorrower2CorpType
			, a.TrustOrBorrower2FirstName
			, a.TrustOrBorrower2LastName
			, a.TrustOrBorrower2MiddleInitial
			, a.TrustOrBorrower2NoParsInd
			, a.VendorMatchInd
			, a.VendorPID
			, a.VendorDeedPID
			, a.VendorSAMPID
			, a.FAActiveInd
			, a.FAInactiveDate
			, a.FAMatchInd
			, a.FAPropertyId
			, a.FADeedId
			, a.FASAMId
			, a.FASourceInd
			, a.FATimestamp
			, a.FAUserId
			, a.FACreateDt
			, a.FAMatchDt
			, a.FAUCIDFlag
			, a.FAActiveDt
			, a.ChronoKey
			, a.MatchCode
			, a.FADeleteFlag
			, a.FADeleteFlagDate
			, a.FADateReceived
			, a.FAAddressParsedMailing
			, a.FAAddressParsedSitus
			, a.FAAddressParsedTrustee
			, a.LoanContractDt
			, a.MailForeignAddrInd
			, a.TrusteeForeignAddrInd
			, a.SitusCensusBlock
			, a.SitusCensusTract
			, a.SitusDPCheckCode
			, a.SitusDPCheckDigit
			, a.SitusDPVCount
			, a.SitusDPVFootnote
			, a.SitusGeoCodeResults
			, a.SitusGeoErrorCode
			, a.SitusGeoStatusCode
			, a.SitusLACS
			, a.SitusLACSLinkInd
			, a.MailingCensusBlock
			, a.MailingCensusTract
			, a.MailingDPCheckCode
			, a.MailingDPCheckDigit
			, a.MailingDPVCount
			, a.MailingDPVFootnote
			, a.MailingGeoCodeResults
			, a.MailingGeoErrorCode
			, a.MailingGeoStatusCode
			, a.MailingLACS
			, a.MailingLACSLinkInd
			, a.TrusteeHouseNbr
			, a.TrusteeHouseNbrSuffix
			, a.TrusteeHouseNbr2
			, a.TrusteeDirectionLeft
			, a.TrusteeStreet
			, a.TrusteeMode
			, a.TrusteeDirectionRight
			, a.TrusteeUnitType
			, a.TrusteeCensusBlock
			, a.TrusteeCensusTract
			, a.TrusteeDPCheckCode
			, a.TrusteeDPCheckDigit
			, a.TrusteeDPVCount
			, a.TrusteeDPVFootnote
			, a.TrusteeGeoCodeResults
			, a.TrusteeGeoErrorCode
			, a.TrusteeGeoStatusCode
			, a.TrusteeLACS
			, a.TrusteeLACSLinkInd
			, a.TrusteeCarrierCode
			, a.TrusteeMatchCode
			, a.BestDateSrc
			, a.FADataArchiveDate
			, b.StdLandUseCode
			, l.BKFSCode as DocumentTypeTransactionCode
			,Case when DocumentType = '74' then 'CO'
				when DocumentType in ('76','75','85') then 'FJ'
				when  DocumentType in ('79','86') then 'LP'
				when  documenttype in ('77','78','84','J') then 'ND'
				when documenttype = '81' then 'NF'
				when  documenttype in ('89','92') then 'NS'
				when  DocumentType in ('82','90') then 'NT'
				when  documenttype in ('73','80','91','88','87','83') then 'RL'
			end as PFCType
			,B.PropertyClassID as PropertyClassID

			-----Added 20180730 for Connected Investors----
			,G.[County Name] as CountyName

			------Added 20180918 for B of A-----
			,A.TrustorBorrowerFullName2 

			,a.SitusStdFullStreetAddress as [SitusFullStreetAddress]

			-----ADDED 20190131 KL
			,B.[SumResidentialUnits]

			-----ADDED 20191119 MAS
			,a.[CMTID]
			,a.[CMTIDInstNbr]

			,A.[OrigLoanCMTID]
			,A.[OrigLoanCMTIDInstNbr]

			,A.OrigNODCMTID
			,A.OrigNODCMTIDInstNbr

			-----20200317 - Added per BR
			,A.ReleaseReason as ReleaseReason
			,A.ReleaseTransactionId as ReleaseTransactionID
			,A.ReleaseRecordingDt as ReleaseRecordingDate

			------Added 20201028 per BR--
	
			,B.[FASubdivisionNameID]
			,B.[FASubdivisionName]
			,B.[FAComplexNbrUnits]

			-----Added 20201113 per BR
			,B.[FASubdivisionPhase] 
			----Added 20210503
			,B.DTDB_Ref_ID

			,B.DTDB_FORMATTED_APN
			,B.DTDB_UNFORMATTED_APN 

			-----Added 20220721 for Costar
			,B.CS_FORMATTED_APN
			,B.CS_UNFORMATTED_APN
			,a.TrustOrBorrower1NoParsInd as TrustOrBorrower1CorpInd
			,a.TrustOrBorrower2NoParsInd as TrustOrBorrower2CorpInd
			,b.[MailingOptOut]

			--For Xome 20260910
			,case when A.FIPS = '24003' then Coalesce(B.FormattedAPN,case when right(left(A.APN,2) ,1) like '-' then '0' + A.APN else A.APN end) else A.APN end as PropAPN

FROM            dbo.Foreclosure a with(NOLOCK) 
					LEFT OUTER JOIN dbo.Property b  with(NOLOCK)
							ON a.FIPS = b.FIPS AND a.FAPropertyId = b.PropertyID
					LEFT OUTER JOIN  Global.dbo.county as G with(NOLOCK) 
							ON A.FIPS = G.FIPSCODE
					LEFT OUTER JOIN Global.dbo.lkup_Doc_Type_N l  with(NOLOCK)
							ON a.DocumentType = l.DocTypeID















GRANT SELECT ON [dbo].[vForeclosure] TO [CORP\cbrady] AS [dbo]
