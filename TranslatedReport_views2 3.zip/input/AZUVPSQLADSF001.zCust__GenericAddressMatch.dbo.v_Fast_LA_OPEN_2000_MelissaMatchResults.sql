SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [zCust__GenericAddressMatch].[dbo].[v_Fast_LA_OPEN_2000_MelissaMatchResults]
AS
SELECT        a.MatchCode, a.GeoStatusCode, a.AddressMatchResults, b.FASTFileId, b.FileNbr, b.RgnNm, b.OpenDt, b.EstCloseDt, b.OrdrCloseDt, b.OrdrCloseForRptDt, 
                         b.TxnTypDesc, b.BusSgmntDesc, b.OrdrServTypDesc, b.Buyer, b.Seller, b.OrdrSalePrcAmt, b.OrdrSalePrcLbltyAmt, b.LoanAmt, b.LoanLiability, b.BusSrcNm, 
                         b.BusSrcCntctNm, b.BusSrcRoleDesc, b.FASTDirById, b.DirByRoleDesc, b.EscrwOwnOffcNm, b.EscrwOffcrNm, b.TtlOwnOffcNm, b.TtlOffcrNm, b.Address, b.City, 
                         b.County, b.STATE, b.Zip, b.LoanTerm, b.CD_AmountFinanced, b.CD_LoanTermYear, b.CD_InterestRate, b.Count_Lender_Payoffs, b.Sum_Lender_Payoffs, 
                         b.PolicyYear, b.FC_Task, b.FC_TaskStatus, b.SR_Task, b.SR_TaskStatus, b.UniqueID
FROM            dbo.FAST_LA_open_since2000_MelissaMatch AS a INNER JOIN
                         dbo.FAST_LA_open_since2000 AS b ON a.RAW_ID = b.UniqueID


