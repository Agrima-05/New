SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [xEBader].[dbo].[weeklyOC2] AS SELECT
	CAST(SourceID as int) AS QueryOID,
	   [FIPS]
      ,[LotSqFt]
      ,[Shell]
      ,[Multi]
      ,[Parcel]
      ,[Latitude]
      ,[Longitude]
      ,[SourceId]
      ,[SourceGeoCodeId]
      ,[FAGeoCodeId]
      ,[ProcessDate]
      ,[CurrencyDate]
      ,[Stacked]
      ,[created]
      ,[Precision]
      ,[InsertFrom]
      ,[ExtractDate]
FROM [xEBader].[dbo].[DtDotCom20260419] WHERE FIPS = '6059'
