SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [prod_AVM_History].[dbo].[AVM_History_2020_USE_I]
AS
Select c.FIPS
,c.PropertyID
,c.FormattedAPN as APN
,c.SitusStdFullStreetAddress as SitusFullStreetAddress
,c.SitusStdHouseNbr as SitusHouseNbr
,c.SitusStdHouseNbrSuffix as SitusHouseNbrSuffix
,c.SitusStdDirectionLeft as SitusDirectionLeft
,c.SitusStdStreet as SitusStreet
,c.SitusStdMode as SitusMode
,c.SitusStdDirectionRight as SitusDirectionRight
,c.SitusStdUnitType as SitusUnitType
,c.SitusStdUnitNbr as SitusUnitNbr
,c.SitusStdCity as SitusCity
,c.SitusStdState as SitusState
,c.SitusStdZIP5 as SitusZIP5
,c.SitusStdZIP4 as SitusZIP4
,c.SitusStdCarrierCode as SitusCarrierCode
,a.[final_value] as FinalValue
,a.[high] as HighValue
,a.[low] as LowValue
,a.[score] as ConfidenceScore
,a.[stdev] as StandardDeviation
,convert(datetime,Convert(Varchar(10),a.[VALUATION_DATE],120)) as ValuationDate
,c.StdLandUseCode
From [dbo].[AVM_History_2020_USE] a with(NOLOCK)
JOIN dbo.[Property] c with(NOLOCK) 
on a.FIPS = c.FIPS and a.PropertyID = c.PropertyID
--on a.PropertyID = a.PropertyID




