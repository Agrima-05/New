SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




 CREATE view [src_PlatLabs].[dbo].[vPhotoLinksCI_V2] 
 as
 ---- PHOTO LINKS WITH REF_ID

	 Select b.[FIPS]
	   ,b.[REF_ID]
	   ,a.[uid]
	   ,a.[mls_id]
	   ,a.[mls_listing_id]
	   ,a.[photo_count]
	   ,a.[photo_date]
	   ,a.[sequence_number]

		,'https://platlab.s3.us-east-2.amazonaws.com/images-all/' 
			+ cast(a.mls_id as varchar) 
				+ '/' + a.mls_listing_id 
					+ '/' + cast(a.mls_id as varchar) + '-' 
						+ a.mls_listing_id + '-' 
							+ cast(sequence_number as varchar) 
								+ '.webp'
		as source_url

      ,a.[modified_date]
      ,a.[LoadDate] 
	 from [src_PlatLabs].[photos].[RawPhotoLinks] a with(NOLOCK) JOIN listing.ListingsRaw b  with(NOLOCK)
		on a.mls_id = b.mls_id 
		and a.mls_listing_id = b.mls_listing_id
		JOIN Reports.dbo.SentToCI_photos s on a.mls_id = s.mls_id
		where (b.mls_id in(Select mls_id from platlabs_update_config where code like '%_39' and active = '1' and mls_id not in('2651','2877'))
			OR (b.mls_id in(Select mls_id from platlabs_update_config where code like '%_39' and active = '1' and mls_id in('2651','2877'))
				and b.status in('Active','Pending','Contingent','Backup')))
		and a.LoadDate >= DateSentUpdates
		and a.mls_id != 2926 

UNION ALL

	 Select b.[FIPS]
	   ,b.[REF_ID]
	   ,a.[uid]
	   ,a.[mls_id]
	   ,a.[mls_listing_id]
	   ,a.[photo_count]
	   ,a.[photo_date]
	   ,a.[sequence_number]

		,'https://platlab.s3.us-east-2.amazonaws.com/images-all/' 
			+ cast(a.mls_id as varchar) 
				+ '/' + a.mls_listing_id 
					+ '/' + cast(a.mls_id as varchar) + '-' 
						+ a.mls_listing_id + '-' 
							+ cast(sequence_number as varchar) 
								+ '.webp'
		as source_url

      ,a.[modified_date]
      ,a.[LoadDate] 
	 from [src_PlatLabs].[photos].[RawPhotoLinks] a with(NOLOCK) JOIN listing.ListingsRaw b  with(NOLOCK)
		on a.mls_id = b.mls_id 
		and a.mls_listing_id = b.mls_listing_id
		JOIN Reports.dbo.SentToCI_photos s on a.mls_id = s.mls_id
		where b.mls_id in('2651','2877') and sequence_number = 1 and b.status in('sold','closed','OffMarket','Expired')
				and a.LoadDate >= DateSentUpdates
		and a.mls_id NOT IN(2926,2797)



