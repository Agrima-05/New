SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
/****** Script for SelectTopNRows command from SSMS  ******/

CREATE view [zCust_Exxon].[dbo].[vTicket_7216_Data_Point]
AS
SELECT  [FIPS]
      ,[PropertyID]
      ,[APN]
      ,[SitusFullStreetAddress]
      ,[SitusHouseNbr]
      ,[SitusHouseNbrSuffix]
      ,[SitusDirectionLeft]
      ,[SitusStreet]
      ,[SitusMode]
      ,[SitusDirectionRight]
      ,[SitusUnitType]
      ,[SitusUnitNbr]
      ,[SitusCity]
      ,[SitusState]
      ,[SitusZIP5]
      ,[SitusZIP4]
      ,[SitusCarrierCode]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusGeoStatusCode]
      ,[PropertyClassID]
      ,[LandUseCode]
      ,case when [Active Pace Lien] = 'Y' then 'Y' else 'N' end as ActivePaceLien
      ,[House Facing Direction] as HouseFacingDirection
      ,[Point] as Geom
  FROM [zCust_Exxon].[dbo].[Ticket_7216_Data]
