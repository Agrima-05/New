SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [MarketShare].[dbo].[AgentDataLink]
AS

Select CASE WHEN a.FIPS is NULL THEN b.FIPS ELSE a.FIPS END as FIPS
,CASE WHEN a.REF_ID is NULL THEN b.REF_ID ELSE a.REF_ID END as REF_ID
,CASE WHEN a.DeedID is NULL THEN b.DeedID ELSE a.DeedID END as DeedID
,CASE WHEN a.PropertyID is null THEN b.PropertyID ELSE a.PropertyID END as PropertyID
,CASE WHEN a.mls_id is NULL THEN b.mls_id ELSE a.mls_id END as mls_id
,CASE WHEN a.mls_listing_id is NULL THEN b.mls_listing_id ELSE a.mls_listing_id END as mls_listing_id
,CASE WHEN a.mls_list_date is NULL THEN b.mls_list_date ELSE a.mls_list_date END as mls_list_date
,CASE WHEN a.sold_date is NULL THEN b.sold_date ELSE a.sold_date END as sold_date
,CASE WHEN a.sold_price is NULL THEN b.sold_price ELSE a.sold_price END as sold_price
,CASE WHEN a.LoadDate is NULL THEN b.LoadDate ELSE a.LoadDate END as LoadDate
 from dbo.MarketshareBuyAgentData a FULL OUTER JOIN dbo.MarketshareSaleAgentData b 
on a.mls_id = b.mls_id
and a.mls_listing_id = b.mls_listing_id
WHERE CASE WHEN a.sold_price is NULL THEN b.sold_price ELSE a.sold_price END > CASE WHEN a.FIPS Between 06000 and 06999 THEN 25000 ELSE 10000 END
and CASE WHEN a.mls_id is NULL THEN b.mls_id ELSE a.mls_id END > 2600


