SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vHPI_CBSA]
AS
SELECT        b.[FIPSCode], b.[State], b.[County Name] as CountyName, b.[CBSACode], b.[CBSAName], a.[MONTH], a.[INDEX], a.[ERROR], a.LoadDate
FROM            Holocron.dbo.INDEX_VALUE_MODEL_CBSA AS a INNER JOIN
                         Global.dbo.County AS b ON a.CBSA = b.CBSACode


GRANT SELECT ON [dbo].[vHPI_CBSA] TO [CORP\cbrady] AS [dbo]
