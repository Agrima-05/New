SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [MarketShare].[dbo].[20180621_DenverCO_042018_Sample]
AS
SELECT        FIPS, [Zip Code], County, State, [Title Company], [Title Company Clean], [Transaction Type], [Property Type], date, [Sales Price], [Loan Amount], Lender, 
                         [Lender Cleaned], Builder, LoanType, Residential, Corporate, Attorney, City, RunDate, ParentTitleCo
FROM            dbo.Sample_20180621

