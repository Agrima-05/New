SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vAVM_ProcisionRental]
AS

SELECT b.[Fips],
b.[PropertyID],
b.[FormattedAPN] as [APN],
b.[SitusStdFullStreetAddress] as [SitusFullStreetAddress],
b.[SitusStdHouseNbr] as [SitusHouseNbr],
b.[SitusStdHouseNbrSuffix] as [SitusHouseNbrSuffix],
b.[SitusStdDirectionLeft] as [SitusDirectionLeft],
b.[SitusStdStreet] as [SitusStreet],
b.[SitusStdMode] as [SitusMode],
b.[SitusStdDirectionRight] as [SitusDirectionRight],
b.[SitusStdUnitType] as [SitusUnitType],
b.[SitusStdUnitNbr] as [SitusUnitNbr],
b.[SitusStdCity] as [SitusCity],
b.[SitusStdState] as [SitusState],
b.[SitusStdZIP5] as [SitusZIP5],
b.[SitusStdZIP4] as [SitusZIP4],
b.[SitusStdCarrierCode] as [SitusCarrierCode],
b.[PropertyClassID],
b.[StdLandUseCode] as [LandUseCode],
a.[RENTAL_FINAL_VALUE] as FinalValue,
a.[RENTAL_HIGH_VALUE] as HighValue,
a.[RENTAL_LOW_VALUE] as LowValue,
a.[RENTAL_CONFIDENCE] as ConfidenceScore,
a.[VALUE_AS_OF] as ValuationDate
FROM [Holocron].[dbo].[ProcisionRentalAVM] a with(NOLOCK) JOIN [Data].[dbo].[Property] b with(NOLOCK)
ON a.FIPS = b.FIPS and a.REF_ID = b.DTDB_REF_ID
where [RENTAL_FINAL_VALUE] > 0
and b.FAUCIDFlag not like 'D'














