SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Platlabs].[dbo].[vPlatlabs_Listings]
AS
	Select l.FIPS,p.[PropertyID] as LicensingPropertyID
	,p.[DTDB_REF_ID]
	,p.[FormattedAPN] as APN
	,l.mls_id as platlabs_mls_id
	,m.[MLSID] as [mlsSid]
	,l.[listing_agent_id] as [listAgentId]
	,la.[agent_FirstName] as [listAgentFirstName]
	,la.[agent_LastName] as [listAgentLastName]
	,la.[agent_Phone] as [listAgentPhone1]
	,cla.[agentID] as [coListAgentId]
	,cla.[FirstName] as [coListAgentFirstName]
	,cla.[LastName] as [coListAgentLastName]
	,cla.[AgentPhone] as [coListAgentPhone1]
	,sa.[agent_id] as [sellAgentId]
	,sa.[agent_FirstName] as [sellAgentFirstName]
	,sa.[agent_LastName] as [sellAgentLastName]
	,sa.[agent_Phone] as [sellAgentPhone1]
	,csa.[coSellAgent_UID] as [coSellAgentId]
	,csa.[FirstName] as [coSellAgentFirstName]
	,csa.[LastName] as [coSellAgentLastName]
	,csa.[CoSellAgentPhone] as [coSellAgentPhone1]
	,CASE WHEN l.[mls_status] not in('Sold','Closed') THEN DATEDIFF(DD,list_date,GetDate()) ELSE DATEDIFF(DD,list_date,status_change_date) END as [dom]
	,p.[SitusStdCity] as [city]
	,FORMAT([mls_list_date],'MM-dd-yyyy') as [listDate]
	,l.[price] as [listPrice]
	,p.[SitusStdState] as [state]
	,p.[SitusStdFullStreetAddress] as [address]
	,p.[SitusStdUnitNbr] as [addressUnit]
	,0 as [bank]
	,[STATUSNAMESKEY] as [statusCode]
	,FORMAT(l.[status_change_date],'MM-dd-yyyy') as [dateStatusChange]
	,p.[SitusStdZIP5] as [zipCode]
	,l.[mls_listing_id] as [listingId]
	,la.office_id as [listOfficeId]
	,lo.full_name as [listOfficeName]
	,lo.[address] as [listOfficeStreetName1]
	,lo.[city] as [listOfficeCity]
	,lo.[zip] as [listOfficeZip]
	,lo.[state] as [listOfficeState]
	,sa.[office_id] as [sellOfficeId]
	,so.[full_name] as [sellOfficeName]
	,so.[address] as [sellOfficeStreetName1]
	,so.[city] as [sellOfficeCity]
	,so.[zip] as [sellOfficeZip]
	,so.[state] as [sellOfficeState]
	,l.loaddate
	FROM [src_PlatLabs].[listing].[ListingsRaw] l  with(NOLOCK)
	JOIN [dbo].[LookupMLSs] m with(NOLOCK) ON l.mls_id = m.[mls_id]
		JOIN dbo.lookupMLSStatus s with(NOLOCK) on l.mls_status = s.[mls_status]
		LEFT OUTER JOIN [zCust_ADS__00_SharedProcs].[dbo].[Property] p with(NOLOCK)
			ON l.PropertyID = p.PropertyID
		LEFT OUTER JOIN src_Platlabs.agent.ListAgents la with(NOLOCK)
			ON l.mls_id = la.mls_id
				and l.mls_listing_id = la.mls_listing_id
		LEFT OUTER JOIN src_PlatLabs.agent.CoAgent cla with(NOLOCK)
			ON l.mls_id = cla.mls_id
				and l.mls_listing_id = cla.mls_listing_id
		LEFT OUTER JOIN src_PlatLabs.agent.SellingAgents sa with(NOLOCK)
			ON l.mls_id = sa.mls_id
				and l.mls_listing_id = sa.mls_listing_id
		LEFT OUTER JOIN src_platlabs.agent.CoSellingAgents csa with(NOLOCK)
			ON l.mls_id = csa.mls_id
				and l.mls_listing_id = csa.mls_listing_id
		LEFT OUTER JOIN src_Platlabs.office.Platlabs_Offices lo with(NOLOCK)
			ON la.office_uid = lo.uid
		LEFT OUTER JOIN src_Platlabs.office.Platlabs_Offices so with(NOLOCK)
			ON sa.office_uid = so.uid
		Where l.mls_id in(Select mls_id from src_platlabs.dbo.platlabs_update_config with(NOLOCK) where active = '1' and code like '%39')
		and l.LoadDate > (Select max(LoadDate)-1 from Platlabs.dbo.Platlabs_Src_Listings with(NOLOCK))
				 

