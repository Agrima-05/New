SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Boundaries].[dbo].[vFASpot_a]
AS

	SELECT * FROM [Boundaries].[dbo].[FASpot_a]
	UNION ALL
	SELECT * FROM [Boundaries].[dbo].[FASpot_Generated_a]


