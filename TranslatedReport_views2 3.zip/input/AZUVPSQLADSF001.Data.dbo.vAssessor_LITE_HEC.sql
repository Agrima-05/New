SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vAssessor_LITE_HEC]
AS
SELECT       
A.[FIPS] as 'FIPS'
,A.[PropertyID] as 'PropertyID'
,A.[FormattedAPN] as 'FormattedAPN'
,A.[APNSeqNbr] as 'APNSeqNbr'
,A.[OldAPN] as 'OldAPN'
,A.[TaxAccountNumber] as 'TaxAccountNumber'
,A.[SitusStdFullStreetAddress] as 'SitusStdFullStreetAddress'
,A.[SitusStdHouseNbr] as 'SitusStdHouseNbr'
,A.[SitusStdHouseNbrSuffix] as 'SitusStdHouseNbrSuffix'
,A.[SitusStdDirectionLeft] as 'SitusStdDirectionLeft'
,A.[SitusStdStreet] as 'SitusStdStreet'
,A.[SitusStdMode] as 'SitusStdMode'
,A.[SitusStdDirectionRight] as 'SitusStdDirectionRight'
,A.[SitusStdUnitType] as 'SitusStdUnitType'
,A.[SitusStdUnitNbr] as 'SitusStdUnitNbr'
,A.[SitusStdCity] as 'SitusStdCity'
,A.[SitusStdState] as 'SitusStdState'
,A.[SitusStdZIP5] as 'SitusStdZIP5'
,A.[SitusStdZIP4] as 'SitusStdZIP4'
,A.[SitusStdCarrierCode] as 'SitusStdCarrierCode'
,A.[SitusLatitude] as 'SitusLatitude'
,A.[SitusLongitude] as 'SitusLongitude'
,A.[SitusGeoStatusCode] as 'SitusGeoStatusCode'
,A.[PropertyClassID] as 'PropertyClassID'
,A.[StdLandUseCode] as 'StdLandUseCode'
,A.[StateLandUseCode] as 'StateLandUseCode'
,A.[CountyLandUseCode] as 'CountyLandUseCode'
,A.[Zoning] as 'Zoning'
,A.[SitusCensusTract] as 'SitusCensusTract'
,A.[MobileHomeInd] as 'MobileHomeInd'
,A.[TimeshareCode] as 'TimeshareCode'
,A.[SchoolDistrictName] as 'SchoolDistrictName'
,A.[LotSizeFrontageFeet] as 'LotSizeFrontageFeet'
,A.[LotSizeDepthFeet] as 'LotSizeDepthFeet'
,A.[LotSizeAcres] as 'LotSizeAcres'
,A.[LotSizeSqFt] as 'LotSizeSqFt'
,A.[OwnerStd1CorpInd] as 'OwnerStd1CorpInd'
,A.[OwnerStd1LastName] as 'OwnerStd1LastName'
,A.[OwnerStd1FirstName] as 'OwnerStd1FirstName'
,A.[OwnerStd1MiddleName] as 'OwnerStd1MiddleName'
,A.[OwnerStd1Suffix] as 'OwnerStd1Suffix'
,A.[OwnerStd2CorpInd] as 'OwnerStd2CorpInd'
,A.[OwnerStd2LastName] as 'OwnerStd2LastName'
,A.[OwnerStd2FirstName] as 'OwnerStd2FirstName'
,A.[OwnerStd2MiddleName] as 'OwnerStd2MiddleName'
,A.[OwnerStd2Suffix] as 'OwnerStd2Suffix'
,A.[OwnerStdNAME1FULL] as 'OwnerStdNAME1FULL'
,A.[OwnerStdNAME2FULL] as 'OwnerStdNAME2FULL'
,A.[OwnerOccupied] as 'OwnerOccupied'
,A.[OwnerStd1OwnershipRights] as 'OwnerStd1OwnershipRights'
,A.[MailingStdFullStreetAddress] as 'MailingStdFullStreetAddress'
,A.[MailingStdHouseNbr] as 'MailingStdHouseNbr'
,A.[MailingStdHouseNbrSuffix] as 'MailingStdHouseNbrSuffix'
,A.[MailingStdDirectionLeft] as 'MailingStdDirectionLeft'
,A.[MailingStdStreet] as 'MailingStdStreet'
,A.[MailingStdMode] as 'MailingStdMode'
,A.[MailingStdDirectionRight] as 'MailingStdDirectionRight'
,A.[MailingStdUnitType] as 'MailingStdUnitType'
,A.[MailingStdUnitNbr] as 'MailingStdUnitNbr'
,A.[MailingStdCity] as 'MailingStdCity'
,A.[MailingStdState] as 'MailingStdState'
,A.[MailingStdZIP5] as 'MailingStdZIP5'
,A.[MailingStdZIP4] as 'MailingStdZIP4'
,A.[MailingStdCarrierCode] as 'MailingStdCarrierCode'
,A.[MailingOptOut] as 'MailingOptOut'
,A.[AssdTotalValue] as 'AssdTotalValue'
,A.[AssdLandValue] as 'AssdLandValue'
,A.[AssdImprovementValue] as 'AssdImprovementValue'
,A.[MarketTotalValue] as 'MarketTotalValue'
,A.[MarketValueLand] as 'MarketValueLand'
,A.[MarketValueImprovement] as 'MarketValueImprovement'
,CASE WHEN A.[DBSTaxYear] > A.[TaxYear] THEN A.[DBSTaxAmount] ELSE A.[TaxAmount] END as 'TaxAmount'
,CASE WHEN A.[DBSTaxYear] > A.[TaxYear] THEN A.[DBSTaxYear] ELSE A.[TaxYear] END as 'TaxYear'
,A.[TaxDeliquentYear1] as 'TaxDeliquentYear1'
,A.[AssdYear] as 'AssdYear'
,A.[TaxRateCodeArea] as 'TaxRateCodeArea'
,A.[SchoolTaxDistrict1Code] as 'SchoolTaxDistrict1Code'
,A.[SchoolTaxDistrict2Code] as 'SchoolTaxDistrict2Code'
,A.[SchoolTaxDistrict3Code] as 'SchoolTaxDistrict3Code'
,A.[HomesteadInd] as 'HomesteadInd'
,A.[VeteranInd] as 'VeteranInd'
,A.[DisabledInd] as 'DisabledInd'
,A.[WidowInd] as 'WidowInd'
,A.[SeniorInd] as 'SeniorInd'
,A.[SchoolCollegeInd] as 'SchoolCollegeInd'
,A.[ReligiousInd] as 'ReligiousInd'
,A.[WelfareInd] as 'WelfareInd'
,A.[PublicUtilityInd] as 'PublicUtilityInd'
,A.[CemeteryInd] as 'CemeteryInd'
,A.[HospitalInd] as 'HospitalInd'
,A.[LibraryInd] as 'LibraryInd'
,A.[BuildingArea] as 'BuildingArea'
,A.[BuildingAreaInd] as 'BuildingAreaInd'
,A.[SumBuildingSqFt] as 'SumBuildingSqFt'
,A.[SumLivingAreaSqFt] as 'SumLivingAreaSqFt'
,A.[SumGrossAreaSqFt] as 'SumGrossAreaSqFt'
,A.[SumAdjAreaSqFt] as 'SumAdjAreaSqFt'
,A.[SumBasementSqFt] as 'SumBasementSqFt'
,A.[SumGarageSqFt] as 'SumGarageSqFt'
,A.[YearBuilt] as 'YearBuilt'
,A.[EffectiveYearBuilt] as 'EffectiveYearBuilt'
,A.[Bedrooms] as 'Bedrooms'
,A.[TotalRooms] as 'TotalRooms'
,A.[BathTotalCalc] as 'BathTotalCalc'
,A.[BathFull] as 'BathFull'
,A.[BathsParcialNbr] as 'BathsParcialNbr'
,A.[BathFixturesNbr] as 'BathFixturesNbr'
,A.[AirConditioningCode] as 'AirConditioningCode'
,A.[BasementCode] as 'BasementCode'
,A.[BuildingClassCode] as 'BuildingClassCode'
,A.[BuildingConditionCode] as 'BuildingConditionCode'
,A.[ConstructionTypeCode] as 'ConstructionTypeCode'
,A.[ExteriorWallsCode] as 'ExteriorWallsCode'
,A.[InteriorWallsCode] as 'InteriorWallsCode'
,A.[FireplaceCode] as 'FireplaceCode'
,A.[FloorCoverCode] as 'FloorCoverCode'
,A.[Garage] as 'Garage'
,A.[HeatCode] as 'HeatCode'
,A.[HeatingFuelTypeCode] as 'HeatingFuelTypeCode'
,A.[SiteInfluenceCode] as 'SiteInfluenceCode'
,A.[GarageParkingNbr] as 'GarageParkingNbr'
,A.[DrivewayCode] as 'DrivewayCode'
,A.[PatioCode] as 'PatioCode'
,A.[PoolCode] as 'PoolCode'
,A.[PorchCode] as 'PorchCode'
,A.[BuildingQualityCode] as 'BuildingQualityCode'
,A.[RoofCoverCode] as 'RoofCoverCode'
,A.[RoofTypeCode] as 'RoofTypeCode'
,A.[SewerCode] as 'SewerCode'
,A.[StoriesNbrCode] as 'StoriesNbrCode'
,A.[StyleCode] as 'StyleCode'
,A.[SumResidentialUnits] as 'SumResidentialUnits'
,A.[SumBuildingsNbr] as 'SumBuildingsNbr'
,A.[SumCommercialUnits] as 'SumCommercialUnits'
,A.[WaterCode] as 'WaterCode'
,A.[LotCode] as 'LotCode'
,A.[LotNumber] as 'LotNumber'
,A.[LandLot] as 'LandLot'
,A.[Block] as 'Block'
,A.[Section] as 'Section'
,A.[District] as 'District'
,A.[LegalUnit] as 'LegalUnit'
,A.[Municipality] as 'Municipality'
,A.[SubdivisionName] as 'SubdivisionName'
,A.[SubdivisionPhaseNbr] as 'SubdivisionPhaseNbr'
,A.[SubdivisionTractNbr] as 'SubdivisionTractNbr'
,A.[Meridian] as 'Meridian'
,A.[AssessorsMapRef1] as 'AssessorsMapRef1'
,A.[LegalDescription] as 'LegalDescription'
,A.[FATimestamp] as 'FATimestamp'
,A.[FAUCIDFlag] as 'FAUCIDFlag'


------Added 20170802 for NextGen -KL---

,A.[CurrentSaleTransactionId] as CurrentSaleTransactionId,
A.[CurrSaleInputDocNbr] as CurrSaleInputDocNbr,
A.[CurrSaleInputBook] as CurrSaleInputBook,
A.[CurrSaleInputPage] as CurrSaleInputPage,
A.[CurrSaleRecordingDate] as CurrSaleRecordingDate,
A.[CurrSaleContractDate] as CurrSaleContractDate,
A.[CurrSaleDocumentType] as CurrSaleDocumentType,
A.[CurrSalesPrice] as CurrSalesPrice,
A.[CurrSaleBuyer1FullName] as CurrSaleBuyer1FullName,
A.[CurrSaleBuyer2FullName] as CurrSaleBuyer2FullName,
A.[CurrSaleSeller1FullName] as CurrSaleSeller1FullName,
A.[CurrSaleSeller2FullName] as CurrSaleSeller2FullName,
A.[CurrSalesPriceCode] as CurrSalesPriceCode,
B.[County Name] as CountyName




FROM            Data.dbo.Property_HEC_2014_Assd_OUT as A WITH (nolock)
join Global.dbo.County as B with(NOLOCK)
on A.FIPS = B.FIPSCODE




GRANT SELECT ON [dbo].[vAssessor_LITE_HEC] TO [CORP\cbrady] AS [dbo]
