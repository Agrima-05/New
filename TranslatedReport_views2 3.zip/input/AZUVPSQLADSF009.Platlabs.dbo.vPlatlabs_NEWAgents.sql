SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Platlabs].[dbo].[vPlatlabs_NEWAgents]
AS

		Select m.srcMLSID as mlsSid
		,a.dp_member_id as agentId
		,[first_name] as firstName
		,[last_name] as lastName
		,a.[email] as agentEmail
		,[preferred_phone_number] as agentPhone1
		,GETDATE() as [dateFirstAppeared]
		,a.[dp_office_id] as officeId
		,b.full_name as officeName
		,b.address as officeAddress
		,b.city as officeCity
		,b.state as officeState
		,b.zip as officeZip
		 from dbo.NEW_AGENTS a 
			JOIN dbo.Platlabs_Src_MLS m ON a.mls_id = m.MLSID
			LEFT OUTER JOIN [src_PlatLabs].[Office].[Platlabs_Offices] b
				on a.[office_uid] = b.[uid]






