SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

 CREATE view [Extracts].[dbo].[HW_NewAgents_Refresh] 
 as
		SELECT [SrcAgentID]
			  ,[SrcOfficeID]
			  ,[SrcMLSID]
			  ,[SrcMLSAgentID]
			  ,[FirstName]
			  ,[LastName]
			  ,[AgentEmail]
			  ,[AgentPhone1]
			  ,[DateFirstAppeared]
			  ,[SrcMLSOfficeID]
			  ,[SrcOfficeName]
			  ,[SrcOfficeAddress]
			  ,[SrcOfficeCity]
			  ,[SrcOfficeState]
			  ,[SrcOfficeZip]
			  ,[DateCreated]
			  ,[LastModifiedDate]
			  ,[ID]
			  ,[Platlabs_uid]
			  ,[Platlabs_mls_id]
			  ,[LoadDate]
		  FROM [Platlabs].[dbo].[Platlabs_Src_NewAgents] l with(NOLOCK)
			WHERE l.[SrcMLSID] in(Select mls_id from src_platlabs.dbo.platlabs_update_config with(NOLOCK) where code like '%_39' and active = '1')
		  

