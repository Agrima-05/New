SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE View [HOA].[dbo].[SubdivProfileFacetSummary] AS

WITH Summary
AS (
	SELECT FIPS
		,SourceId
		,AssessorFacetId
		,SUM(CASE 
				WHEN NOA <= 10
					THEN Units
				ELSE 0
				END) AS OABoundUnits
		,SUM(Units) AS TotalUnits
		,SUM(CASE 
				WHEN NOA <= 10
					THEN Condo
				ELSE 0
				END) AS OABoundCondo
		,SUM(Condo) AS TotalCondos
		,SUM(CASE 
				WHEN NOA <= 10
					THEN PUD
				ELSE 0
				END) AS OABoundPUD
		,SUM(PUD) AS TotalPUD
		,SUM(CASE 
				WHEN NOA <= 10
					THEN SFR
				ELSE 0
				END) AS OABoundSFR
		,SUM(SFR) AS TotalSFR
		,SUM(CASE 
				WHEN NOA <= 10
					THEN Townhouse
				ELSE 0
				END) AS OABoundTownhouse
		,SUM(Townhouse) AS TotalTownHouse
		,SUM(CASE 
				WHEN NOA <= 10
					THEN CommonArea
				ELSE 0
				END) AS OABoundCommonArea
		,SUM(CommonArea) AS TotalCommonArea
		,SUM(CASE 
				WHEN NOA <= 10
					THEN OtherResidential
				ELSE 0
				END) AS OABoundOtherResidential
		,SUM(OtherResidential) AS TotalOtherResidential
	FROM OA.SubdivProfile sp
	WHERE NOT (Facet1 IS NULL AND Facet2 IS NULL and Facet3 IS NULL)
	GROUP BY FIPS
		,SourceId
		,AssessorFacetId
	)
SELECT s.NAME
	,af.Description
	,r.*
FROM Summary r
INNER JOIN Oa.Source s(FORCESEEK) ON s.Id = r.SourceId
INNER JOIN Oa.AssessorFacet af(FORCESEEK) ON af.Id = r.AssessorFacetId

