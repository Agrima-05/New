SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [zCust_ProperTI_PROD].[dbo].[v_PROPERTI_USE_FOR_EPR_PULL]
AS



Select FIPS, PropertyID from (

Select distinct FIPS, PropertyID
From [zCust_ProperTI_PROD].[dbo].[INPUT_MONITOR] as A with (nolock)
where PropertyID is not null and ISNULL(PropertyID,'') not like '' and PropertyID not like '0'

UNION ALL 

Select distinct FIPS, PropertyID
From [zCust_ProperTI].[dbo].[INPUT_MONITOR] as A with (nolock)
where PropertyID is not null and ISNULL(PropertyID,'') not like '' and PropertyID not like '0'
)A











