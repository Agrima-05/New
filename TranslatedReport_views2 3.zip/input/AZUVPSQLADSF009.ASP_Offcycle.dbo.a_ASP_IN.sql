SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

 CREATE view [ASP_Offcycle].[dbo].[a_ASP_IN]
 as

SELECT [RecordId]
      ,[FullStreetAddress]
      ,[City]
      ,[State]
      ,[Zip]
      ,[raw_id]
      ,[Processed]
  FROM [dbo].[ASP_IN]


