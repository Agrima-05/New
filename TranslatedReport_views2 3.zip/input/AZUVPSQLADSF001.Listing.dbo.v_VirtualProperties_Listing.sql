SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Listing].[dbo].[v_VirtualProperties_Listing]
AS
			Select
			--[Property Address],
			--[Property City],
			--[Property State],
			--[Property Zip],
			--[Property Zip + 4],
			--CASE WHEN PM_APN is NULL then [Assessor's Parcel Identification Number] ELSE PM_APN END AS [Assessor's Parcel Identification Number],
			--[County FIPS],
			--PM_PropertyID AS [Internal FA Property Ref ID],
			--[Property Type],
			--[Property Sub-Type],
			--[Lot Size (Sq Ft)],
			--[Home Size (Sq Ft)],
			--[Home or Building Style],
			--[Heating Type],
			--[Heating Fuel Type],
			--[Cooling Type],
			--[Cooling Fuel Type],
			--[Number of Stories],
			--[Year Built],
			--[Roof Type],
			--[Exterior Construction],
			--[Number of Bedrooms],
			--[Number of Bathrooms],
			--[Number of Garages],
			--[Garage Type],
			--[Pool Features],
			--[View Features],
			--[Property Details],
			--[FA Calculated Days on Market],
			--[Current Original Listing Date],
			--[Listing Number],
			--[Status],
			--[Status Sub Type],
			--[Rental Ind],
			--[Current Listing Price],
			--[Sold Price],
			--[Sold Date],
			--[FA Adjusted Sold Price],
			--[FA Sold Price Range],
			--[Listing Agent License Number],
			--[Listing Agent Name],
			--[Listing Agent Address],
			--[Listing Agent Phone],
			--[Listing Agent Email],
			--[Office Name],
			--[Office Address],
			--[Office Phone],
			--[Office Email],
			--[Listing Tracking ID],
			--[FA Unique Listing Identifier - Ref ID],
			--[Update Timestamp],
			--[Add, Change, Delete Indicator]

REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property Address]),'|',''),'"','""') AS [Property Address],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property City]),'|',''),'"','""') AS [Property City],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property State]),'|',''),'"','""') AS [Property State],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property Zip]),'|',''),'"','""') AS [Property Zip],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property Zip + 4]),'|',''),'"','""') AS [Property Zip + 4],
CASE WHEN PM_APN is NULL then REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Assessor's Parcel Identification Number]),'|',''),'"','""') ELSE REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote](PM_APN),'|',''),'"','""') END AS [Assessor's Parcel Identification Number],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([County FIPS]),'|',''),'"','""') AS [County FIPS],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote](PM_PropertyID),'|',''),'"','""') AS [Internal FA Property Ref ID],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property Type]),'|',''),'"','""') AS [Property Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property Sub-Type]),'|',''),'"','""') AS [Property Sub-Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Lot Size (Sq Ft)]),'|',''),'"','""') AS [Lot Size (Sq Ft)],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Home Size (Sq Ft)]),'|',''),'"','""') AS [Home Size (Sq Ft)],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Home or Building Style]),'|',''),'"','""') AS [Home or Building Style],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Heating Type]),'|',''),'"','""') AS [Heating Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Heating Fuel Type]),'|',''),'"','""') AS [Heating Fuel Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Cooling Type]),'|',''),'"','""') AS [Cooling Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Cooling Fuel Type]),'|',''),'"','""') AS [Cooling Fuel Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Number of Stories]),'|',''),'"','""') AS [Number of Stories],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Year Built]),'|',''),'"','""') AS [Year Built],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Roof Type]),'|',''),'"','""') AS [Roof Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Exterior Construction]),'|',''),'"','""') AS [Exterior Construction],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Number of Bedrooms]),'|',''),'"','""') AS [Number of Bedrooms],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Number of Bathrooms]),'|',''),'"','""') AS [Number of Bathrooms],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Number of Garages]),'|',''),'"','""') AS [Number of Garages],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Garage Type]),'|',''),'"','""') AS [Garage Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Pool Features]),'|',''),'"','""') AS [Pool Features],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([View Features]),'|',''),'"','""') AS [View Features],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Property Details]),'|',''),'"','""') AS [Property Details],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([FA Calculated Days on Market]),'|',''),'"','""') AS [FA Calculated Days on Market],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Current Original Listing Date]),'|',''),'"','""') AS [Current Original Listing Date],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Listing Number]),'|',''),'"','""') AS [Listing Number],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Status]),'|',''),'"','""') AS [Status],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Status Sub Type]),'|',''),'"','""') AS [Status Sub Type],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Rental Ind]),'|',''),'"','""') AS [Rental Ind],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Current Listing Price]),'|',''),'"','""') AS [Current Listing Price],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Sold Price]),'|',''),'"','""') AS [Sold Price],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Sold Date]),'|',''),'"','""') AS [Sold Date],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([FA Adjusted Sold Price]),'|',''),'"','""') AS [FA Adjusted Sold Price],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([FA Sold Price Range]),'|',''),'"','""') AS [FA Sold Price Range],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Listing Agent License Number]),'|',''),'"','""') AS [Listing Agent License Number],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Listing Agent Name]),'|',''),'"','""') AS [Listing Agent Name],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Listing Agent Address]),'|',''),'"','""') AS [Listing Agent Address],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Listing Agent Phone]),'|',''),'"','""') AS [Listing Agent Phone],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Listing Agent Email]),'|',''),'"','""') AS [Listing Agent Email],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Office Name]),'|',''),'"','""') AS [Office Name],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Office Address]),'|',''),'"','""') AS [Office Address],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Office Phone]),'|',''),'"','""') AS [Office Phone],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Office Email]),'|',''),'"','""') AS [Office Email],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Listing Tracking ID]),'|',''),'"','""') AS [Listing Tracking ID],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([FA Unique Listing Identifier - Ref ID]),'|',''),'"','""') AS [FA Unique Listing Identifier - Ref ID],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Update Timestamp]),'|',''),'"','""') AS [Update Timestamp],
REPLACE(REPLACE([DATA].[dbo].[ClnDblQuote]([Add, Change, Delete Indicator]),'|',''),'"','""') AS [Add, Change, Delete Indicator]





	FROM     dbo.VirtualProperties_WORK









