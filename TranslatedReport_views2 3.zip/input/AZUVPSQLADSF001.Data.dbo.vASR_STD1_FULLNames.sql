SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vASR_STD1_FULLNames]
AS
SELECT      
[FIPS] as FIPS
,[FAPropertyId] as FAPropertyId
,[APN] as APN
,NULL as APNSeqNbr
,NULL as PreviousParcelNumber
,[TaxAccountNbr] as TaxAccountNbr
,[SitusStdHouseNbr] as SitusStdHouseNbr
,[SitusStdHouseNbr2] as SitusStdHouseNbr2
,[SitusStdHouseNbrSuffix] as SitusStdHouseNbrSuffix
,[SitusStdDirectionLeft] as SitusStdDirectionLeft
,[SitusStdStreet] as SitusStdStreet
,[SitusStdMode] as SitusStdMode
,[SitusStdDirectionRight] as SitusStdDirectionRight
,[SitusStdUnitType] as SitusStdUnitType
,[SitusStdUnitNbr] as SitusStdUnitNbr
,[SitusStdCity] as SitusStdCity
,[SitusStdState] as SitusStdState
,[SitusStdZIP5] as SitusStdZIP5
,[SitusStdZIP4] as SitusStdZIP4
,[SitusStdCarrierCode] as SitusStdCarrierCode
,[TransactionId] as FirstAmericanUniqueTransactionID
,[DocNbrSrce] as DocNbrSrce
,[BookSrce] as BookSrce
,[PageSrce] as PageSrce
,[RecordingDt] as RecordingDt
,[EffectiveDt] as EffectiveDt
,[DocumentType] as DocumentType
,[BorrowerFullName] as BorrowerFullName
,[Assignee] as NewLenderName
,[AssignorName] as OriginalLenderName
,[OrigDeedRecordingDt] as OrigDeedRecordingDt
,[OrigDeedDocNbr] as OrigDeedDocNbr
,[OrigDeedBook] as OrigDeedBook
,[OrigDeedPage] as OrigDeedPage
,[OrigLoanAmt] as OrigLoanAmt
,case when FADeedid is null then FASamID else FADeedID end as OriginalLoanTransactionID
,[FATimestamp] as UpdateTimeStamp
,[FAUCIDFlag] as FAUCIDFlag
,[FATimestamp] as FATimestamp


FROM            ASSIGNMENT  with(NOLOCK)
Where isDate(RecordingDt) = 1 and RecordingDt <= convert(varchar(8),GetDate(),112)

UNION ALL
/*-------------------------------------------------------------------------------------*/ 

SELECT 
[FIPS] as FIPS
,[FAPropertyId] as FAPropertyId
,[APN] as APN
,NULL as APNSeqNbr
,NULL as PreviousParcelNumber
,[TaxAccountNbr] as TaxAccountNbr
,[SitusHouseNbr] as SitusStdHouseNbr
,[SitusHouseNbr2] as SitusStdHouseNbr2
,[SitusHouseNbrSuffix] as SitusStdHouseNbrSuffix
,[SitusDirectionLeft] as SitusStdDirectionLeft
,[SitusStreet] as SitusStdStreet
,[SitusMode] as SitusStdMode
,[SitusDirectionRight] as SitusStdDirectionRight
,[SitusUnitType] as SitusStdUnitType
,[SitusUnitNbr] as SitusStdUnitNbr
,[SitusCity] as SitusStdCity
,[SitusState] as SitusStdState
,[SitusZIP5] as SitusStdZIP5
,[SitusZIP4] as SitusStdZIP4
,[SitusCarrierCode] as SitusStdCarrierCode
,[TransactionId] as FirstAmericanUniqueTransactionID
,[DocNbrSrce] as DocNbrSrce
,[BookSrce] as BookSrce
,[PageSrce] as PageSrce
,[RecordingDt] as RecordingDt
,[EffectiveDt] as EffectiveDt
,[DocumentType] as DocumentType
,[BorrowerFullName] as BorrowerFullName
,NULL as NewLenderName
,Replace(Replace([OrigLenderBen],',',''),'.','') as OriginalLenderName
,[OrigDeedRecordingDt] as OrigDeedRecordingDt
,[OrigDeedDocNbr] as OrigDeedDocNbr
,[OrigDeedBook] as OrigDeedBook
,[OrigDeedPage] as OrigDeedPage
,[OrigLoanAmt] as OrigLoanAmt
,case when FADeedid is null then FASamID else FADeedID end as OriginalLoanTransactionID
,[FATimestamp] as UpdateTimeStamp
,[FAUCIDFlag] as FAUCIDFlag
,[FATimestamp] as FATimestamp


FROM            RELEASE  with(NOLOCK)
Where isDate(RecordingDt) = 1 and RecordingDt <= convert(varchar(8),GetDate(),112)









GRANT SELECT ON [dbo].[vASR_STD1_FULLNames] TO [CORP\cbrady] AS [dbo]
