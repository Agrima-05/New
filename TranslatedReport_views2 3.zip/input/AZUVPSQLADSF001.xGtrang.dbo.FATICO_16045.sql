SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [xGtrang].[dbo].[FATICO_16045]
AS
select  [FIPS]
      ,[PropertyID]
      ,[FormattedAPN]
      ,[SitusStdFullStreetAddress]
      ,[SitusStdHouseNbr]
      ,[SitusStdHouseNbrSuffix]
      ,[SitusStdDirectionLeft]
      ,[SitusStdStreet]
      ,[SitusStdMode]
      ,[SitusStdDirectionRight]
      ,[SitusStdUnitType]
      ,[SitusStdUnitNbr]
      ,[SitusStdCity]
      ,[SitusStdState]
      ,[SitusStdZIP5]
      ,[SitusStdZIP4]
      ,[SitusStdCarrierCode]
      ,[GeomSpatial] from Data.dbo.vParcel_Spot where Fips = '16045' and faucidflag not like 'D'



