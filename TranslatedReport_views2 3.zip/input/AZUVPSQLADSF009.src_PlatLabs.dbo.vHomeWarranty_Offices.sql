SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

 Create view [src_PlatLabs].[dbo].[vHomeWarranty_Offices] 
 as

SELECT [SrcOfficeID]
      ,[SrcMLSID]
      ,[SrcMLSOfficeID]
      ,[SrcOfficeName]
      ,[Address1]
      ,[Address2]
      ,[City]
      ,[State]
      ,[CountyID]
      ,[Zip]
      ,[Phone]
      ,[Email]
      ,[DateCreated]
      ,[LastModifiedDate]
      ,[DW_TimeStamp]
      ,[Longitude]
      ,[Latitude]
      ,[FASTOfficeAddrBookID]
      ,[OfficeRank]
      ,[SourceAddress1]
      ,[SourceAddress2]
      ,[SourceCity]
      ,[SourceState]
      ,[SourceZip]
      ,[CassCertifiedAddress1]
      ,[CassCertifiedAddress2]
      ,[CassCertifiedCity]
      ,[CassCertifiedState]
      ,[CassCertifiedZip]
      ,[IsActive]
      ,[ID]
      ,[Platlabs_uid]
      ,[Platlabs_mls_id]
      ,[LoadDate]
  FROM [Platlabs].[dbo].[Platlabs_Src_Offices]




