SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [JobsStage].[dbo].[vTable]
AS
SELECT        TableID, TableName, TableDescription, SQLServer, DatabaseName, ServerDrive, UpdateTimeStamp
FROM            Global.dbo.[Table]

