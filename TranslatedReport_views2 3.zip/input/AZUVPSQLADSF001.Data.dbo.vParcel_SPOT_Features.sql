SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vParcel_SPOT_Features]
AS
SELECT d.FIPS
,p.PropertyID
,CASE WHEN p.FormattedAPN is NULL THEN d.[APN] ELSE p.FormattedAPN END as FormattedAPN
,SitusStdFullStreetAddress
,SitusStdHouseNbr
,SitusStdHouseNbrSuffix
,SitusStdDirectionLeft
,SitusStdStreet
,SitusStdMode
,SitusStdDirectionRight
,SitusStdUnitType
,SitusStdUnitNbr
,SitusStdCity
,SitusStdState
,SitusStdZIP5
,SitusStdZIP4
,SitusStdCarrierCode
,d.CentroidLatitude as FALatitude
,d.CentroidLongitude as FALongitude
,d.FAGeoStatusCode
,d.GeomWKT as Geom
,d.FATimestamp
,P.StdLandUseCode
,d.[ParcelGeometry3857] as GeomSpatial
------Added 20200529 per BR for Convex Labs
,d.[UCIDFlag] as FAUCIDFlag
,d.[FADigitalMapMasterId]  as FAPropertyBoundaryID

-----Added 20210127 per JE
,P.FARooftopLatitude
,P.FARooftopLongitude
,P.OldAPN
,P.OldApnIndicator
,P.TaxAccountNumber
,P.APNSeqNbr

----Added 20210503
,P.DTDB_REF_ID
,P.DTDB_FORMATTED_APN
,P.DTDB_UNFORMATTED_APN 

----Added 20210604
,P.LotsizeAcres

-----Added 20220721 for Costar
,P.CS_FORMATTED_APN
,P.CS_UNFORMATTED_APN
,d.FeatureType

---Adding for internal use 20250218
,D.EstLotSizeSqFt

FROM Boundaries.dbo.[FASpot]  d LEFT OUTER JOIN [Data].[dbo].[Property] p with(nolock)
  ON p.Fips = d.Fips and p.PropertyId = d.PropertyId 
  WHERE [GeoSource] = 'Parcels'
  and LEN(GeomWKT) < 10000000 

UNION ALL

SELECT d.FIPS
,p.PropertyID
,CASE WHEN p.FormattedAPN is NULL THEN d.[APN] ELSE p.FormattedAPN END as FormattedAPN
,SitusStdFullStreetAddress
,SitusStdHouseNbr
,SitusStdHouseNbrSuffix
,SitusStdDirectionLeft
,SitusStdStreet
,SitusStdMode
,SitusStdDirectionRight
,SitusStdUnitType
,SitusStdUnitNbr
,SitusStdCity
,SitusStdState
,SitusStdZIP5
,SitusStdZIP4
,SitusStdCarrierCode
,d.CentroidLatitude as FALatitude
,d.CentroidLongitude as FALongitude
,d.FAGeoStatusCode
,d.GeomWKT as Geom
,d.FATimestamp
,P.StdLandUseCode
,d.[ParcelGeometry3857] as GeomSpatial


------Added 20200529 per BR for Convex Labs
,d.[UCIDFlag] as FAUCIDFlag
,d.[FADigitalMapMasterId]  as FAPropertyBoundaryID

-----Added 20210127 per JE
,P.FARooftopLatitude
,P.FARooftopLongitude
,P.OldAPN
,P.OldApnIndicator
,P.TaxAccountNumber
,P.APNSeqNbr

----Added 20210503
,P.DTDB_REF_ID
,P.DTDB_FORMATTED_APN
,P.DTDB_UNFORMATTED_APN 

----Added 20210604
,P.LotsizeAcres

-----Added 20220721 for Costar
,P.CS_FORMATTED_APN
,P.CS_UNFORMATTED_APN
,d.FeatureType

---Adding for internal use 20250218
,D.EstLotSizeSqFt

FROM Boundaries.[dbo].[FASpot_Generated]  d LEFT OUTER JOIN [Data].[dbo].[Property] p with(nolock)
  ON p.Fips = d.Fips and p.PropertyId = d.PropertyId 
  WHERE [GeoSource] = 'Parcels'
  and LEN(GeomWKT) < 10000000 

UNION ALL

SELECT d.FIPS
,p.PropertyID
,CASE WHEN p.FormattedAPN is NULL THEN d.[APN] ELSE p.FormattedAPN END as FormattedAPN
,SitusStdFullStreetAddress
,SitusStdHouseNbr
,SitusStdHouseNbrSuffix
,SitusStdDirectionLeft
,SitusStdStreet
,SitusStdMode
,SitusStdDirectionRight
,SitusStdUnitType
,SitusStdUnitNbr
,SitusStdCity
,SitusStdState
,SitusStdZIP5
,SitusStdZIP4
,SitusStdCarrierCode
,d.CentroidLatitude as FALatitude
,d.CentroidLongitude as FALongitude
,d.FAGeoStatusCode
,d.GeomWKT as Geom
,d.FATimestamp
,P.StdLandUseCode
,d.[ParcelGeometry3857] as GeomSpatial


------Added 20200529 per BR for Convex Labs
,d.[UCIDFlag] as FAUCIDFlag
,d.[FADigitalMapMasterId]  as FAPropertyBoundaryID

-----Added 20210127 per JE
,P.FARooftopLatitude
,P.FARooftopLongitude
,P.OldAPN
,P.OldApnIndicator
,P.TaxAccountNumber
,P.APNSeqNbr

----Added 20210503
,P.DTDB_REF_ID
,P.DTDB_FORMATTED_APN
,P.DTDB_UNFORMATTED_APN 

----Added 20210604
,P.LotsizeAcres

-----Added 20220721 for Costar
,P.CS_FORMATTED_APN
,P.CS_UNFORMATTED_APN
,d.FeatureType

---Adding for internal use 20250218
,D.EstLotSizeSqFt

FROM Boundaries.dbo.[FASpot_a]  d LEFT OUTER JOIN [Data].[dbo].[Property] p with(nolock)
  ON p.Fips = d.Fips and p.PropertyId = d.PropertyId 
  WHERE [GeoSource] = 'Parcels'
  and LEN(GeomWKT) < 10000000 

UNION ALL

SELECT d.FIPS
,p.PropertyID
,CASE WHEN p.FormattedAPN is NULL THEN d.[APN] ELSE p.FormattedAPN END as FormattedAPN
,SitusStdFullStreetAddress
,SitusStdHouseNbr
,SitusStdHouseNbrSuffix
,SitusStdDirectionLeft
,SitusStdStreet
,SitusStdMode
,SitusStdDirectionRight
,SitusStdUnitType
,SitusStdUnitNbr
,SitusStdCity
,SitusStdState
,SitusStdZIP5
,SitusStdZIP4
,SitusStdCarrierCode
,d.CentroidLatitude as FALatitude
,d.CentroidLongitude as FALongitude
,d.FAGeoStatusCode
,d.GeomWKT as Geom
,d.FATimestamp
,P.StdLandUseCode
,d.[ParcelGeometry3857] as GeomSpatial


------Added 20200529 per BR for Convex Labs
,d.[UCIDFlag] as FAUCIDFlag
,d.[FADigitalMapMasterId]  as FAPropertyBoundaryID

-----Added 20210127 per JE
,P.FARooftopLatitude
,P.FARooftopLongitude
,P.OldAPN
,P.OldApnIndicator
,P.TaxAccountNumber
,P.APNSeqNbr

----Added 20210503
,P.DTDB_REF_ID
,P.DTDB_FORMATTED_APN
,P.DTDB_UNFORMATTED_APN 

----Added 20210604
,P.LotsizeAcres

-----Added 20220721 for Costar
,P.CS_FORMATTED_APN
,P.CS_UNFORMATTED_APN
,d.FeatureType

---Adding for internal use 20250218
,D.EstLotSizeSqFt

FROM Boundaries.[dbo].[FASpot_Generated_a]  d LEFT OUTER JOIN [Data].[dbo].[Property] p with(nolock)
  ON p.Fips = d.Fips and p.PropertyId = d.PropertyId 
  WHERE [GeoSource] = 'Parcels'
  and LEN(GeomWKT) < 10000000 




