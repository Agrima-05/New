SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [Data].[dbo].[vMarketShare_NMLS]
AS
Select Distinct Substring(cast(m.[Date] as varchar),1,7) as [YearMonth]
      ,m.[FIPSCode] as Fips
      ,[Zip Code]
      ,[County]
      ,[State]
      ,[Title Company]
      ,[Title Company Clean]
      ,[Transaction Type Clean]
      ,[Property Type]
	  ,case when [Property Type] In ('Single Family Residence', 'Duplex (Triplex, Quadplex)', 'Condominium') then 'Residential' else 'Other' end as [Property Type RES OTHER]
      ,m.[DATE]
      ,m.[Sales Price]
      ,[Loan Amount]
      ,[Lender]
      ,[Lender Clean] as [Lender Cleaned]
      ,[Builder]
      ,[Loan Type] as [LoanType]
      ,[Residential]
      ,[Corporate]
      ,[Attorney]
      ,[City]
      ,[RunDate]
      ,[Parent Title Co] as [ParentTitleCo]
      ,[FMT_DOC_NBR] as [SaleDocNbr]
      ,CASE WHEN isnull([FMT_DOC_NBR],'') like '' THEN [FMT_Book_Page] ELSE [FMT_DOC_NBR] END as [SaleDocNumBkPg]
      ,[FMT_Book_Page] as [SaleBookPage]
      ,[FMT_MTG1_DOC_NBR] as [MtgDocNbr]
      ,[FMT_MTG1_Book_Page] as [MtgBookPage]
      ,CASE WHEN isNULL([FMT_MTG1_DOC_NBR],'') like '' THEN [FMT_MTG1_Book_Page] ELSE [FMT_MTG1_DOC_NBR] END as [MtgDocNumBkPg]
      ,m.[DeedID]
      ,[Transaction Type]
      ,[Loan To Value]
      ,[Adjustable Rate]
      ,[Loan Type]
      ,[Reverse Mortgage]
      ,[Conforming]
      ,[Seller Name]
      ,[Buyer] as [Buyer Name]
      ,[Census Tract #]
      ,[MTG1_PRIVATE_PARTY_LENDER]
      ,[DeedSequence]
      ,[FORMATTED_APN] as [Parcel ID]
      ,[SITUS_Address] as [Address]
      ,[SITUS_CITY]
      ,[BrokerNMLSID] as [NMLSBrokerID]
      ,[BrokerName] as [NMLSBrokerName]
      ,[AgentNMLSID] as [NMLSAgentID]
      ,[AgentName] as [NMLSAgentName]
      ,[LenderNMLSID] as [NMLSLenderID]
      ,[LenderName] as [NMLSLenderName]
	  ,[TransactionID] 
	  ,m.[Ref_ID]
	  ,m.[PropertyID]
	  ,p.SubdivisionName
	  ,m.UpdateDate
	  ,p.[SitusStdHouseNbr]
	  ,p.[SitusStdHouseNbrSuffix]
	  ,p.[SitusStdDirectionLeft]
	  ,p.[SitusStdStreet]
	  ,p.[SitusStdMode]
	  ,p.[SitusStdDirectionRight]
	  ,p.[SitusStdUnitType]
	  ,p.[SitusStdUnitNbr]
	  ,m.[FATimestamp]
	  ,m.[FAUCIDFlag]
	  ,m.[MarketShare]
	  ,m.[LoanIntRate]
	  ,[Listing_Agent_Name]
	  ,[Listing_Agent_Address]
	  ,[Listing_Agent_Phone]
	  ,[Listing_Agent_Email]
	  ,[Office_Name]
	  ,[Office_Address]
	  ,[Office_Phone]
	  ,[Office_Email]	
	  --,a.[final_value] as AVMvalue
	  --,a.[VALUATION_DATE] as ValuationDate
	  ,P.StdLandUseCode
	  ,MTG_INTEREST_RATE_TYPE  as MtgInterestRateType
	  ,CASE WHEN ISNULL(p.FARooftopLatitude,0) = 0 THEN p.SitusLatitude ELSE p.FARooftopLatitude END as Cascaded_SitusLatitude
	  ,CASE WHEN ISNULL(p.FARooftopLongitude,0) = 0 THEN p.SitusLongitude ELSE p.FARooftopLongitude END as Cascaded_SitusLongitude
	  ,CASE WHEN ISNULL(p.FARooftopLatitude,0) != 0 then 'R' ELSE [SitusGeoStatusCode] END	as Cascaded_SitusGeoStatusCode
	  ,m.MULTI_APN
FROM [MarketShare].[dbo].[bulkMKSHR_ALL] m with(NOLOCK) 
	LEFT OUTER JOIN [Data].[dbo].[Property] p WITH(NOLOCK)
		ON m.[PropertyID] = p.[PropertyID]
	--LEFT OUTER JOIN (Select FIPS,[PropertyID],[final_value],[VALUATION_DATE] FROM Data.dbo.[AVM]  with(NOLOCK)) a 
	--	ON a.PropertyID = p.PropertyID
	WHERE m.DeedSequence = 1



