SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON





CREATE VIEW [Data].[dbo].[vESRI_LINKER]
AS

Select 
d.[FIPS]
,Propertyid
,[PRCLDMPID]
,[PROPDMPID]
from [DigitalMap].[dbo].[FADigitalMap_ESRI_Index] d with(NOLOCK)






GRANT SELECT ON [dbo].[vESRI_LINKER] TO [CORP\cbrady] AS [dbo]
