SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [src_DoOrDiE].[dbo].[SI_DEED_BUYER_DTDB_History]
AS
Select * from src_DoOrDiE.dbo.SI_DEED_BUYER 
WHERE RecordingDocumentNumber in(Select distinct DeedID from [dbo].[SI_DEED_DTDB_History])


