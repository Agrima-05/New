SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Data].[dbo].[vAssessor_INFUTOR_BLEND]
AS
SELECT       
	[PROP_FIPSCD] as FIPS									--INFUTOR
,I.[PropertyID] as PropertyID								--INFUTOR
,[PROP_APN] as FormattedAPN											--INFUTOR
,[PROP_APNSEQNBR] as APNSeqNbr								--INFUTOR
,NULL as OldAPN												--INFUTOR
,NULL as OldApnIndicator									--INFUTOR
,NULL as TaxAccountNumber									--INFUTOR
,[PROP_INPUT_ADDRESS] as SitusSTDFullStreetAddress				--INFUTOR
,[HOUSE] as SitusSTDHouseNbr									--INFUTOR
,NULL as SitusSTDHouseNbrSuffix								--INFUTOR
,[PREDIR] as SitusSTDDirectionLeft								--INFUTOR
,[STREET] as SitusSTDStreet									--INFUTOR
,[STRTYPE] as SitusSTDMode										--INFUTOR
,[POSTDIR] as SitusSTDDirectionRight							--INFUTOR
,[APTTYPE] as SitusSTDUnitType									--INFUTOR
,[APTNBR] as SitusSTDUnitNbr									--INFUTOR
,[CITY] as SitusSTDCity										--INFUTOR
,I.[STATE] as SitusSTDState									--INFUTOR
,[ZIP] as SitusSTDZIP5											--INFUTOR
,[Z4] as SitusSTDZIP4											--INFUTOR
,[CRTE] as SitusSTDCarrierCode									--INFUTOR
,[PROP_LATITUDE] as SitusLatitude							--INFUTOR
,[PROP_LONGITUDE] as SitusLongitude							--INFUTOR
,NULL as SitusGeoStatusCode									--INFUTOR
,[PROP_IND] as PropertyClassID								--INFUTOR
,[PROP_LANDUSE] as STDLandUseCode								--INFUTOR
,NULL as StateLandUseCode									--INFUTOR
,NULL as CountyLandUseCode									--INFUTOR
,[PROP_ZONING] as Zoning									--INFUTOR
,[PROP_CENSUSTRACT] as SitusCensusTract						--INFUTOR
,NULL as SitusCensusBlock									--INFUTOR
,[PROP_MOBHOME] as MobileHomeInd							--INFUTOR
,NULL as TimeshareCode										--INFUTOR
,NULL as SchoolDistrictName									--INFUTOR
,[PROP_FRONTFT] as LotSizeFrontageFeet						--INFUTOR
,[PROP_DEPTHFT] as LotSizeDepthFeet							--INFUTOR
,[PROP_ACRES] as LotSizeAcres								--INFUTOR
,[PROP_LANDSQFT] as LotSizeSqFt								--INFUTOR
,CASE WHEN p.Propertyid is NULL then CASE WHEN [BUSNAME] NOT LIKE '' THEN 1 ELSE NULL END ELSE [OwnerStd1CorpInd] END as OwnerSTD1CorpInd			--BLENDED
,CASE WHEN p.Propertyid is NULL then [LNAME] ELSE [OwnerStd1LastName] END as OwnerSTD1LastName														--BLENDED
,CASE WHEN p.Propertyid is NULL then [FNAME] ELSE [OwnerStd1FirstName] END as OwnerSTD1FirstName													--BLENDED
,CASE WHEN p.Propertyid is NULL then [MNAME] ELSE [OwnerStd1MiddleName] END as OwnerSTD1MiddleName													--BLENDED
,CASE WHEN p.Propertyid is NULL then [SUFFIX] ELSE [OwnerStd1Suffix] END as OwnerSTD1Suffix														--BLENDED
,CASE WHEN p.Propertyid is NULL then NULL ELSE [OwnerStd2CorpInd] END as OwnerSTD2CorpInd															--BLENDED
,CASE WHEN p.Propertyid is NULL then [LNAME2] ELSE [OwnerStd2LastName] END as OwnerSTD2LastName													--BLENDED
,CASE WHEN p.Propertyid is NULL then [FNAME2] ELSE [OwnerStd2FirstName] END as OwnerSTD2FirstName													--BLENDED
,CASE WHEN p.Propertyid is NULL then [MNAME2] ELSE [OwnerStd2MiddleName] END as OwnerSTD2MiddleName												--BLENDED
,CASE WHEN p.Propertyid is NULL then [SUFFIX2] ELSE [OwnerStd2Suffix] END as OwnerSTD2Suffix														--BLENDED
,CASE WHEN p.Propertyid is NULL then rtrim(rtrim(rtrim(ltrim(rtrim([BUSNAME] + ' ' + [LNAME])) + ' ' + [FNAME]) + ' ' + [MNAME]) + ' ' + [SUFFIX]) ELSE [OwnerStdNAME1FULL] END as OwnerSTDNAME1FULL		--BLENDED
,CASE WHEN p.Propertyid is NULL then rtrim(rtrim(rtrim(ltrim(rtrim([LNAME2])) + ' ' + [FNAME2]) + ' ' + [MNAME2]) + ' ' + [SUFFIX2])  ELSE [OwnerStdNAME2FULL] END as OwnerSTDNAME2FULL					--BLENDED
,CASE WHEN p.Propertyid is NULL then [PROP_OWNEROCC] ELSE [OwnerOccupied] END as OwnerOccupied													--BLENDED
,CASE WHEN p.Propertyid is NULL then NULL ELSE [OwnerStd1OwnershipRights] END as OwnerSTD1OwnershipRights											--BLENDED
,CASE WHEN p.Propertyid is NULL then [HOUSE2] ELSE [MailingStdFullStreetAddress] END as MailingSTDFullStreetAddress		--BLENDED
,CASE WHEN p.Propertyid is NULL then NULL ELSE [MailingStdHouseNbr] END as MailingSTDHouseNbr								--BLENDED
,CASE WHEN p.Propertyid is NULL then NULL ELSE [MailingStdHouseNbrSuffix] END as MailingSTDHouseNbrSuffix					--BLENDED
,CASE WHEN p.Propertyid is NULL then [PREDIR2] ELSE [MailingStdDirectionLeft] END as MailingSTDDirectionLeft				--BLENDED
,CASE WHEN p.Propertyid is NULL then [STREET2] ELSE [MailingStdStreet] END as MailingSTDStreet								--BLENDED
,CASE WHEN p.Propertyid is NULL then [STRTYPE2] ELSE [MailingStdMode] END as MailingSTDMode								--BLENDED
,CASE WHEN p.Propertyid is NULL then [POSTDIR2] ELSE [MailingStdDirectionRight] END as MailingSTDDirectionRight			--BLENDED
,CASE WHEN p.Propertyid is NULL then [APTTYPE2] ELSE [MailingStdUnitType] END as MailingSTDUnitType						--BLENDED
,CASE WHEN p.Propertyid is NULL then [APTNBR2] ELSE [MailingStdUnitNbr] END as MailingSTDUnitNbr							--BLENDED
,CASE WHEN p.Propertyid is NULL then [CITY2] ELSE [MailingStdCity] END as MailingSTDCity									--BLENDED
,CASE WHEN p.Propertyid is NULL then [STATE2] ELSE [MailingStdState] END as MailingSTDState								--BLENDED
,CASE WHEN p.Propertyid is NULL then [ZIP2] ELSE [MailingStdZIP5] END as MailingSTDZIP5									--BLENDED
,CASE WHEN p.Propertyid is NULL then [Z42] ELSE [MailingStdZIP4] END as MailingSTDZIP4										--BLENDED
,CASE WHEN p.Propertyid is NULL then [CRTE2] ELSE [MailingStdCarrierCode] END as MailingSTDCarrierCode						--BLENDED
,CASE WHEN p.Propertyid is NULL then NULL ELSE [MailingOptOut] END as MailingOptOut										--BLENDED
,CASE WHEN p.Propertyid is NULL then NULL ELSE [MailingCareOfName] END as MailingCareOfName									--BLENDED
,CASE WHEN p.Propertyid is NULL then NULL ELSE [MailForeignAddrInd] END as MailForeignAddrInd						--BLENDED
,[PROP_ASSED_VAL] as AssdTotalValue							--INFUTOR
,[PROP_ASSED_LANDVAL] as AssdLandValue						--INFUTOR
,[PROP_ASSED_IMPVAL] as AssdImprovementValue				--INFUTOR
,[PROP_MRKTVAL] as MarketTotalValue							--INFUTOR
,[PROP_MRKT_LANDVAL] as MarketValueLand						--INFUTOR
,[PROP_MRKT_IMPVAL] as MarketValueImprovement				--INFUTOR
,[PROP_TAXAMT] as TaxAmount									--INFUTOR
,[PROP_TAXYR] as TaxYear									--INFUTOR
,[TaxDeliquentYear1] as TaxDeliquentYear1					--INFUTOR
,NULL as MarketValueYear											--INFUTOR
,[PROP_ASMTYR] as AssdYear									--INFUTOR
,NULL as TaxRateCodeArea									--INFUTOR			
,[SchoolTaxDistrict1Code] as SchoolTaxDistrict1Code				--PROPERTY
,[SchoolTaxDistrict2Code] as SchoolTaxDistrict2Code				--PROPERTY
,[SchoolTaxDistrict3Code] as SchoolTaxDistrict3Code				--PROPERTY
,[PROP_HOMESTEAD] as HomesteadInd							--INFUTOR
,[PROP_XMTVET] as VeteranInd								--INFUTOR
,[PROP_XMT_DISABLED] as DisabledInd							--INFUTOR
,NULL as WidowInd			
,NULL as SeniorInd			
,NULL as SchoolCollegeInd			
,NULL as ReligiousInd			
,NULL as WelfareInd			
,NULL as PublicUtilityInd			
,NULL as CemeteryInd			
,NULL as HospitalInd			
,NULL as LibraryInd			
,[PROP_UNVBLDSQFT] as BuildingArea							--INFUTOR
,[PROP_BLDSQFTIND] as BuildingAreaInd						--INFUTOR
,[PROP_BLDSQFT] as SumBuildingSqFt							--INFUTOR
,[PROP_LIVINGSQFT] as SumLivingAreaSqFt						--INFUTOR
,[PROP_GRDFLRSQFT] as SumGroundFloorSqFt					--INFUTOR
,[PROP_GROSSSQFT] as SumGrossAreaSqFt						--INFUTOR
,[PROP_ADJGROSSSQFT] as SumAdjAreaSqFt						--INFUTOR
,NULL as AtticSqFt											--INFUTOR
,NULL as AtticUnfinSqFt								--INFUTOR
,NULL as AtticFinishSqFt									--INFUTOR
,[PROP_BSMTSQFT] as SumBasementSqFt							--INFUTOR
,NULL as BasementUnfinSqFt								--INFUTOR
,NULL as BasementFinishSqFt								--INFUTOR
,[PROP_PRKGSQ_FT] as SumGarageSqFt							--INFUTOR
,NULL as GarageUnFinSqFt								--INFUTOR
,NULL as GarageFinishSqFt									--INFUTOR
,[PROP_YRBLD] as YearBuilt									--INFUTOR
,[PROP_EFFYRBLD] as EffectiveYearBuilt						--INFUTOR
,[PROP_BEDRMS] as Bedrooms									--INFUTOR
,[PROP_RMS] as TotalRooms									--INFUTOR
,[PROP_BATHSCALC] as BathTotalCalc							--INFUTOR
,[PROP_FULLBATHS] as BathFull								--INFUTOR
,[PROP_HALFBATHS] as BathsParcialNbr						--INFUTOR
,CASE WHEN isNULL([PROP_BATHFIXS],'') Like '' THEN 0  ELSE convert(int,[PROP_BATHFIXS]) END 
	+ CASE WHEN isNULL([PROP_1QTRBATHS],'') Like '' THEN 0  ELSE convert(int,[PROP_1QTRBATHS]) END
		+ CASE WHEN isNULL([PROP_3QTRBATHS],'') LIKE '' THEN 0 ELSE convert(int,[PROP_3QTRBATHS]) END as BathFixturesNbr			--INFUTOR
,NULL as Amenities											--INFUTOR
,[PROP_AC] as AirConditioningCode							--INFUTOR
,[PROP_BSMTF] as BasementCode								--INFUTOR
,NULL as BuildingClassCode									--INFUTOR
,[PROP_COND] as BuildingConditionCode						--INFUTOR
,[PROP_CNSTRTYPE] as ConstructionTypeCode					--INFUTOR
,NULL as DeckCode											--INFUTOR
,NULL as ExteriorWallsCode									--INFUTOR
,NULL as InteriorWallsCode									--INFUTOR
,[PROP_FRPLTYPE] as FireplaceCode							--INFUTOR
,[PROP_FLR] as FloorCoverCode								--INFUTOR
,[PROP_GAR] as Garage										--INFUTOR
,[PROP_HEAT] as HeatCode									--INFUTOR
,[PROP_FUEL] as HeatingFuelTypeCode							--INFUTOR
,[PROP_VIEW] as SiteInfluenceCode							--INFUTOR
,[PROP_PRKGSPACES] as GarageParkingNbr						--INFUTOR
,NULL as DrivewayCode										--INFUTOR
,NULL as OtherRooms											--INFUTOR
,NULL as PatioCode											--INFUTOR
,[PROP_POOLCD] as PoolCode									--INFUTOR
,NULL as PorchCode											--INFUTOR
,[PROP_QLTY] as BuildingQualityCode							--INFUTOR
,[PROP_ROOFCOVER] as RoofCoverCode							--INFUTOR
,[PROP_ROOFTYPE] as RoofTypeCode							--INFUTOR
,[PROP_SEWER] as SewerCode									--INFUTOR
,[PROP_STORIESCD] as StoriesNbrCode							--INFUTOR
,[PROP_STYLE] as StyleCode									--INFUTOR
,[SumResidentialUnits] as SumResidentialUnits					--PROPERTY
,[SumBuildingsNbr] as SumBuildingsNbr							--PROPERTY
,[SumCommercialUnits] as SumCommercialUnits						--PROPERTY
,NULL as TopographyCode										--INFUTOR
,[PROP_WATER] as WaterCode									--INFUTOR
,NULL as LotCode											--INFUTOR
,NULL as LotNumber												--INFUTOR
,NULL as LandLot											--INFUTOR
,NULL as Block												--INFUTOR
,[PROP_SECTION] as Section									--INFUTOR
,NULL as District											--INFUTOR
,[PROP_APTNBR] as LegalUnit									--INFUTOR
,[PROP_MUNINAME] as Municipality							--INFUTOR
,[PROP_SUBDIVISION] as SubdivisionName						--INFUTOR
,NULL as SubdivisionPhaseNbr								--INFUTOR
,NULL as SubdivisionTractNbr								--INFUTOR
,NULL as Meridian											--INFUTOR
,NULL as AssessorsMapRef1									--INFUTOR
,NULL as LegalDescription									--INFUTOR
,[CurrentSaleTransactionId] as CurrentSaleTransactionId			--PROPERTY
,[CurrSaleFormatDocNbr] as CurrSaleInputDocNbr					--PROPERTY
,[CurrSaleFormatBook] as CurrSaleInputBook						--PROPERTY
,[CurrSaleFormatPage] as CurrSaleInputPage						--PROPERTY
,[CurrSaleRecordingDate] as CurrSaleRecordingDate			--PROPERTY
,[CurrSaleContractDate] as CurrSaleContractDate				--PROPERTY
,[CurrSaleDocumentType] as CurrSaleDocumentType				--PROPERTY
,[CurrSalesPrice] as CurrSalesPrice							--PROPERTY
,[CurrSalesPriceCode] as CurrSalesPriceCode					--PROPERTY
,[CurrSaleBuyer1FullName] as CurrSaleBuyer1FullName			--PROPERTY
,[CurrSaleBuyer2FullName] as CurrSaleBuyer2FullName			--PROPERTY
,[CurrSaleBuyer3FullName] as CurrSaleSeller1FullName			--PROPERTY
,[CurrSaleBuyer4FullName] as CurrSaleSeller2FullName			--PROPERTY
,[ConCurrMtg1FormatDocNbr] as ConCurrMtg1InputDocNbr				--PROPERTY
,[ConCurrMtg1FormatBook] as ConCurrMtg1InputBook					--PROPERTY
,[ConCurrMtg1FormatPage] as ConCurrMtg1InputPage					--PROPERTY
,[ConCurrMtg1RecordingDt] as [ConCurrMtg1RecordingDt]		--PROPERTY
,[ConCurrMtg1LoanAmt] as [ConCurrMtg1LoanAmt]					--PROPERTY
,[ConCurrMtg1Lender] as [ConCurrMtg1Lender]					--PROPERTY
,[ConCurrMtg1Term] as [ConCurrMtg1Term]						--PROPERTY
,[ConCurrMtg1InterestRate] as [ConCurrMtg1InterestRate]		--PROPERTY
,[ConCurrMtg1LoanDueDt] as [ConCurrMtg1LoanDueDt]			--PROPERTY
,[ConCurrMtg1AdjOrFix] as [ConCurrMtg1AdjOrFix]				--PROPERTY
,[ConCurrMtg1LoanType] as [ConCurrMtg1LoanType]				--PROPERTY
,[ConCurrMtg1Typefinancing] as [ConCurrMtg1Typefinancing]		--PROPERTY
,[ConCurrMtg2FormatDocNbr] as ConCurrMtg2InputDocNbr				--PROPERTY
,[ConCurrMtg2FormatBook] as ConCurrMtg2InputBook					--PROPERTY
,[ConCurrMtg2FormatPage] as ConCurrMtg2InputPage					--PROPERTY
,[ConCurrMtg2RecordingDt] as [ConCurrMtg2RecordingDt]		--PROPERTY
,[ConCurrMtg2LoanAmt] as [ConCurrMtg2LoanAmt]					--PROPERTY
,[ConCurrMtg2Lender] as [ConCurrMtg2Lender]					--PROPERTY
,[ConCurrMtg2Term] as [ConCurrMtg2Term]						--PROPERTY
,[ConCurrMtg2InterestRate] as [ConCurrMtg2InterestRate]		--PROPERTY
,[ConCurrMtg2LoanDueDt] as [ConCurrMtg2LoanDueDt]			--PROPERTY
,[ConCurrMtg2AdjOrFix] as [ConCurrMtg2AdjOrFix]				--PROPERTY
,[ConCurrMtg2LoanType] as [ConCurrMtg2LoanType]				--PROPERTY
,[ConCurrMtg2Typefinancing] as [ConCurrMtg2Typefinancing]		--PROPERTY
,[PrevSaleTransactionId] as [PrevSaleTransactionId]				--PROPERTY
,[PrevSaleFormatDocNbr] as PrevSaleInputDocNbr						--PROPERTY
,[PrevSaleFormatBook] as PrevSaleInputBook							--PROPERTY
,[PrevSaleFormatPage] as PrevSaleInputPage							--PROPERTY
,[PrevSaleRecordingDate] as PrevSaleRecordingDate				--PROPERTY
,[PrevSaleContractDate] as PrevSaleContractDate					--PROPERTY
,[PrevSaleDocumentType] as PrevSaleDocumentType					--PROPERTY
,[PrevSalesPrice] as PrevSalesPrice								--PROPERTY
,[PrevSalesPriceCode] as PrevSalesPriceCode						--PROPERTY
,[PrevSaleBuyer1FullName] as PrevSaleBuyer1FullName				--PROPERTY
,[PrevSaleBuyer2FullName] as PrevSaleBuyer2FullName				--PROPERTY
,[PrevSaleSeller1FullName] as PrevSaleSeller1FullName			--PROPERTY
,[PrevSaleSeller2FullName] as PrevSaleSeller2FullName			--PROPERTY
,[PrevMtg1FormatDocNbr] as PrevMtg1InputDocNbr						--PROPERTY
,[PrevMtg1FormatBook] as PrevMtg1InputBook							--PROPERTY
,[PrevMtg1FormatPage] as PrevMtg1InputPage							--PROPERTY
,[PrevMtg1RecordingDt] as PrevMtg1RecordingDt					--PROPERTY
,[PrevMtg1LoanAmt] as PrevMtg1LoanAmt							--PROPERTY
,[PrevMtg1Lender] as PrevMtg1Lender								--PROPERTY
,[PrevMtg1Term] as PrevMtg1Term									--PROPERTY
,[PrevMtg1InterestRate] as PrevMtg1InterestRate					--PROPERTY
,[PrevMtg1LoanDueDt] as PrevMtg1LoanDueDt						--PROPERTY
,[PrevMtg1AdjRider] as PrevMtg1AdjRider							--PROPERTY
,[PrevMtg1LoanType] as PrevMtg1LoanType							--PROPERTY
,[PrevMtg1Typefinancing] as PrevMtg1TypeFinancing				--PROPERTY
,p.[FATimestamp] as FATimeStamp									--PROPERTY
,p.[FAUCIDFlag] as FAUCIDFlag									--PROPERTY

FROM src_InfoTR.dbo.Assessment i with(NOLOCK) 
	JOIN Data.dbo.Property p with(NOLOCK) 
		on I.PropertyID = p.PropertyID	
	join Global.dbo.county as G with(NOLOCK) 
		on I.PROP_FIPSCD = G.FIPSCODE




GRANT SELECT ON [dbo].[vAssessor_INFUTOR_BLEND] TO [CORP\cbrady] AS [dbo]
