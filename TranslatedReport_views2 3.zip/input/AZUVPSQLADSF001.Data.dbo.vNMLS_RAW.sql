SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [Data].[dbo].[vNMLS_RAW]
AS
	SELECT [FipsCode]
      ,n.[State]
      ,n.[County]
      ,n.[SitusZip]
      ,n.[PropertyID]
      ,n.[TransactionID]
      ,CONVERT(varchar(8),[RECORDING_DATE],112) as[RecordingDate]
      ,n.[documentnumber]
      ,n.[SALE_AMOUNT] as [SalePrice]
      ,n.MTG_AMT as [LoanAmount]
      ,n.[LenderName]
      ,n.[TitleCompany]
      ,n.[TransactionType]
      ,n.[PropertyType]
      ,n.[RecordingBook]
      ,n.[RecordingPage]
      ,n.[VendorPID]
      ,n.[VendorSourceCode]
      ,CASE WHEN (isNULL([NMLSLenderName],'') not like '' or isNULL([NMLSLenderID],'') not like '') then 'Y' Else NULL END as [LenderFlag]
      ,[NMLSLenderID]
      ,[NMLSLenderName]
      ,CASE WHEN (isNULL([NMLSAgentName],'') not like '' or isNULL([NMLSAgentID],'') not like '') then 'Y' Else NULL END as [AgentFlag]
      ,[NMLSAgentID]
      ,[NMLSAgentName]
      ,CASE WHEN (isNULL([NMLSBrokerName],'') not like '' or isNULL([NMLSBrokerID],'') not like '') then 'Y' Else NULL END as [BrokerFlag]
      ,[NMLSBrokerID]
      ,[NMLSBrokerName]
      ,n.[FATimestamp]
      ,n.[FAUCIDFlag]
      ,NULL as [L_MAtch_type]
      ,NULL as [l_Name_Id_MAtch]
      ,NULL as [a_MAtch_type]
      ,NULL as [a_Name_Id_MAtch]
      ,NULL as [b_MAtch_type]
      ,NULL as [b_Name_Id_MAtch]
      ,NULL as [MtgPos]
      ,NULL as [cnt]
      ,NULL as [Def_company_cnt]
      ,NULL as [Lender_cnt]
      ,NULL as [Agent_cnt]
      ,NULL as [Unknown_cnt]
      ,n.[Fips]
      ,n.[REF_ID]
      ,n.[DeedID]
      ,n.[RecordHold]
  FROM [Marketshare].[dbo].[NMLS_Data] n with(NOLOCK)
	JOIN Data.dbo.Property p with(NOLOCK) 
		ON n.propertyID = p.PropertyID

								









