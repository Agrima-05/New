SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vMarketEdge]
AS
Select Distinct Substring(cast(a.[Date] as varchar),1,7) as [YearMonth]
			,a.[FIPS]
			,a.[Zip Code]
			,a.[County]
			,a.[State]
			,a.[Title Company]
			,a.[Title Company Clean] 
			,a.[Transaction Type Clean] as [Transaction Type]
			,a.[Property Type]
			,a.[Date]
			,a.[Sales Price]
			,a.[Loan Amount]
			,a.[Lender]
			,a.[Lender Clean]
			,a.[Buyer] as [Buyer Name]
			,a.[Seller Name]
			,a.[Builder] 
			,a.[Loan Type]
			,case when a.[Property Type] In ('Single Family Residence', 'Duplex (Triplex, Quadplex)', 'Condominium') then 'Residential' else 'Other' end as Residential
			,a.[Corporate]
			,a.[Attorney]
			,a.[City]
			,CASE WHEN a.[UpdateDate] > a.[Rundate] THEN a.[UpdateDate] Else a.[Rundate] END as RunDate
			,a.[Parent Title Co] as [ParentTitleCo]
			--,[SaleDocNumBkPg]
			--,[MtgDocNumBkPg]
			,a.MarketShare
			,isNULL(a.[SITUS_Address],'')  as [Situs Address]

	/**** NEW Portion ****/

			,a.[DeedID] as [TransactionID]
			,a.[Ref_ID] as [Property_ID] 
			,a.[CENSUS TRACT #] as [CensusTract]
			,CASE WHEN a.[TRANSACTION TYPE] in('REFINANCE','HOME EQUITY') THEN '' ELSE isNULL(a.[FMT_DOC_NBR],'') END as [FormattedSaleDocNumber]
			,CASE WHEN a.[TRANSACTION TYPE] in('REFINANCE','HOME EQUITY') THEN '' ELSE isNULL(a.[FMT_Book_Page],'') END as [FormattedSaleBookPage]
			,a.[FMT_MTG1_DOC_NBR]  as [FormattedDocNumberMortgage1]
			,a.[FMT_MTG1_Book_Page]  as [FormattedBookPageMortgage1]
			,b.[FMT_MTG1_DOC_NBR] as [FormattedDocNumberMortgage2]
			,b.[FMT_MTG1_Book_Page] as [FormattedBookPageMortgage2]
			,CASE WHEN a.[LOAN TO VALUE] like 'NO DATA' THEN '' ELSE a.[LOAN TO VALUE] END as [LoanToValue]
			,1 as [LoanPosition]
			,a.[Adjustable Rate] as [AdjustableRate]
			,a.[Conforming]
			,CASE WHEN isNULL(a.[MTG1_PRIVATE_PARTY_LENDER],'') LIKE '' THEN 'NO' ELSE a.[MTG1_PRIVATE_PARTY_LENDER] END  as [PrivatePartyLender]
			,a.[Reverse Mortgage] as [ReverseMortgage]
			,isNULL(l.[listing_agent_name],'') as [ListingAgent]
			,isNULL(l.[listing_agent_first_name],'') as ListingAgentFirstName
			,isNULL(l.[listing_agent_last_name],'') as ListingAgentLastName
			,isNULL(l.[listing_office_name],'') as [ListingOffice]
			,isNULL(a.[AgentNMLSID],'') as [OfficerNMLSID]
			,isNULL(a.[AgentName],'') as [OfficerName]
			,isNULL(a.[LenderNMLSID],'') as [LenderNMLSID]
			,isNULL(a.[LenderName],'') as [LenderName]
			,isNULL(a.[BrokerNMLSID],'') as [BrokerNMLSID]
			,isNULL(a.[BrokerName],'') as [BrokerName]

			,CASE WHEN l.[listing_agent_phone] Is NULL THEN [List_Agent_Prefer] ELSE l.[listing_agent_phone] END as [ListingAgentPhone]
			,l.[list_agent_license_number] as [ListingAgentLicenseNumber]
			,CASE WHEN l.[listing_agent_email] Is NULL THEN l.list_agent_email ELSE l.[listing_agent_email] END as [ListingAgentEmail]

			--,l.[listing_office_name] as [ListingOfficeName]
			,ltrim(rtrim(rtrim(rtrim(l.[listingOfficeAddress] + ' ' + [listingOfficeCity]) + ' ' + [listingOfficeState]) + ' ' + [listingOfficeZip])) as [ListingOfficeAddress]
			,l.[listing_office_phone] as [ListingOfficePhone]
			,l.[listingOfficeEmail] as ListingOfficeEmail
			,l.[listingOfficeWebsite] as listingOfficeWebsite
			,l.[listingOfficeLicenseNumber] as listingOfficeLicenseNumber

			,s.[BuyAgentName] as [BuyerAgentName]
			,s.[BuyAgentFirstName] as [BuyerAgentFirstName]
			,s.[BuyAgentLastName] as [BuyerAgentLastName]
			,s.[BuyAgentPhone] as [BuyerAgentPhone]
			,s.[BuyAgentLicenseNumber] as [BuyerAgentLicenseNumber]
			,s.[BuyAgentEmail] as [BuyerAgentEmail]
			,s.[BuyAgentOfficeName] as [BuyerOfficeName]
			,ltrim(rtrim(rtrim(rtrim(s.[BuyAgentOfficeAddress] + ' ' + BuyAgentOfficeCity) + ' ' + [BuyAgentOfficeState]) + ' ' + [BuyAgentOfficeZip])) as [BuyerOfficeAddress]
			,s.[BuyAgentOfficePhone] as [BuyerOfficePhone]
			,s.[BuyAgentOfficeEmail] as [BuyerOfficeEmail]
			,s.[BuyAgentOfficeWebsite] as [BuyerOfficeWebsite]
			,s.[BuyAgentOfficeLicenseNumber] as [BuyerOfficeLicenseNumber]
			,a.PropertyID
			,a.DeedID
			,a.[Parent Title Co] as [Parent Title Company]
			,a.[Lender Clean] [ParentLender]
			,CASE WHEN c.FormattedAPN is NULL Then a.[FORMATTED_APN] ELSE c.FormattedAPN END as FormattedAPN
			From MarketShare.dbo.[MarketShare_DeedSeq1] a  with(NOLOCK)
				LEFT OUTER JOIN MarketShare.dbo.[MarketShare_DeedSeq2] b with(NOLOCK) ON a.FIPS = b.FIPS and a.DeedID = b.DeedID
					LEFT OUTER JOIN Data.dbo.Property c with(NOLOCK) on a.FIPSCode = c.fips and a.PropertyID = c.PropertyID
						LEFT OUTER JOIN MarketShare.[dbo].[MarketshareBuyAgentData] s with(NOLOCK) on a.Ref_ID = s.REF_ID and a.DeedID = s.DeedID
							LEFT OUTER JOIN MarketShare.dbo.MarketshareSaleAgentData l with(NOLOCK) on a.Ref_ID = l.REF_ID and a.DeedID = l.DeedID





