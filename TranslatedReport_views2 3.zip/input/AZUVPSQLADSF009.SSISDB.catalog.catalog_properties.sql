SET ANSI_NULLS OFF
SET QUOTED_IDENTIFIER OFF

CREATE VIEW [SSISDB].[catalog].[catalog_properties]
AS
SELECT     [property_name], 
           [property_value]
FROM       [internal].[catalog_properties]
UNION
SELECT     [property_name], 
           [property_value]
FROM       [internal].[master_properties]
WHERE      [property_name] = 'IS_SCALEOUT_ENABLED'

GRANT SELECT ON [catalog].[catalog_properties] TO [ModuleSigner] AS [dbo]
GRANT SELECT ON [catalog].[catalog_properties] TO [public] AS [dbo]
