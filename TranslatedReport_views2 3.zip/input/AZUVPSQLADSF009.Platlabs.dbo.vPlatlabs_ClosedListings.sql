SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [Platlabs].[dbo].[vPlatlabs_ClosedListings]
AS
	Select a.Fips
	,a.PropertyID
	,a.REF_ID as ReferenceID
	,p.FormattedAPN as APN
	,a.mls_id as Platlabs_mls_id
	,l.[MLSID] mlsSid
	,FORMAT(coalesce([sold_date],[close_date]),'MM-dd-yyyy') closeDate
	,a.[mls_listing_id] listingId
	,[parcel_number] taxId
	,p.SitusStdStreet streetName
	,p.SitusStdHouseNbr streetNumber
	,p.SitusStdZIP5 zipCode
	,a.[listing_office_id] listOfficeId
	,b.[office_id] sellOfficeId
	,a.[sold_price] salePrice
	,0 bank
	,[listing_agent_id] listAgentId
	,b.[agent_id] sellAgentId
	,a.[county] listingCounty
	,a.[state] listingState
	,[unit_number] listingUnitNumber
	,a.LoadDate as PlatlabsLoadDate
	from [src_PlatLabs].[listing].[ListingsRaw] a with(NOLOCK) 
		LEFT OUTER JOIN [src_PlatLabs].[agent].[SellingAgents] b
			ON a.mls_id = b.mls_id
				and a.mls_listing_id = b.mls_listing_id
		LEFT OUTER JOIN [zCust_ADS__00_SharedProcs].dbo.Property p on a.PropertyID = p.PropertyID
		LEFT OUTER JOIN [CREMS].[dbo].[LookupMLSs] l on l.mls_id = a.mls_id
	Where (mls_status = 'Sold' or (mls_status = 'Closed' and [sold_price] is not null))
	and a.LoadDate > (Select * from [dbo].[PlatlabsClosedListings_LoadDate])


