SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vParcel_BldgFootprint]
AS
SELECT d.FIPS
,CASE WHEN p.PropertyID is NULL THEN d.PropertyID ELSE p.PropertyID END PropertyID
,p.FormattedAPN 
,SitusStdFullStreetAddress
,SitusStdHouseNbr
,SitusStdHouseNbrSuffix
,SitusStdDirectionLeft
,SitusStdStreet
,SitusStdMode
,SitusStdDirectionRight
,SitusStdUnitType
,SitusStdUnitNbr
,SitusStdCity
,SitusStdState
,SitusStdZIP5
,SitusStdZIP4
,SitusStdCarrierCode
,[height]
,d.[StructureCalcSqFt] [sqfeet]
,d.[Geom] 	--- NOT Part of Standard
,[StructureWKT] [GeomWKT]
,[StructureCentroidLatitude] [Latitude]
,[StructureCentroidLongitude] [Longitude]
,P.[StdLandUseCode]	--- NOT Part of Standard
,P.[BuildingArea]	--- NOT Part of Standard
,P.[BuildingAreaInd]	--- NOT Part of Standard
,p.[SumBuildingSqFt]	--- NOT Part of Standard
,p.[BuildingEstFootprintSqFt]	--- NOT Part of Standard
,P.[DTDB_Ref_ID]		--- NOT Part of Standard
,P.[DTDB_FORMATTED_APN]		--- NOT Part of Standard
,P.[DTDB_UNFORMATTED_APN] 		--- NOT Part of Standard
,P.[CS_FORMATTED_APN]		--- NOT Part of Standard
,P.[CS_UNFORMATTED_APN]		--- NOT Part of Standard
,d.[FATimestamp]
,d.[FAUCIDFlag]

----Added 20231114---
,P.[APNSeqNbr]
,P.[OldAPN]
,P.[OLDAPNSeqNbr]
,P.OldApnIndicator
,P.TaxAccountNumber
,P.FARooftopLatitude as FARooftopLatitude
,P.FARooftopLongitude as FARooftopLongitude

,d.BldgSeq

FROM Boundaries.dbo.[FASPOT_Structures] d with(nolock) LEFT OUTER JOIN [Data].[dbo].[Property] p with(nolock)
  ON p.Fips = d.Fips and p.[PropertyID] = d.[PropertyID] 




GRANT SELECT ON [dbo].[vParcel_BldgFootprint] TO [CORP\cbrady] AS [dbo]
