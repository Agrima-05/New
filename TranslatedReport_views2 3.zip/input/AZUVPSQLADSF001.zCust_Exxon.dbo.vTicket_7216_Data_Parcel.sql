SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
/****** Script for SelectTopNRows command from SSMS  ******/

create view [zCust_Exxon].[dbo].[vTicket_7216_Data_Parcel]
AS
SELECT  [FIPS]
      ,[PropertyID]
      ,[APN]
      ,[SitusFullStreetAddress]
      ,[SitusHouseNbr]
      ,[SitusHouseNbrSuffix]
      ,[SitusDirectionLeft]
      ,[SitusStreet]
      ,[SitusMode]
      ,[SitusDirectionRight]
      ,[SitusUnitType]
      ,[SitusUnitNbr]
      ,[SitusCity]
      ,[SitusState]
      ,[SitusZIP5]
      ,[SitusZIP4]
      ,[SitusCarrierCode]
      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusGeoStatusCode]
      ,[PropertyClassID]
      ,[LandUseCode]
      ,[Active Pace Lien]
      ,[House Facing Direction]
      ,[Parcel] as Geom
  FROM [zCust_Exxon].[dbo].[Ticket_7216_Data]
