SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vAVM_History_2022]
AS

SELECT [FIPS]
      ,[PropertyID]
      ,[APN]
      ,[SitusFullStreetAddress]
      ,[SitusHouseNbr]
      ,[SitusHouseNbrSuffix]
      ,[SitusDirectionLeft]
      ,[SitusStreet]
      ,[SitusMode]
      ,[SitusDirectionRight]
      ,[SitusUnitType]
      ,[SitusUnitNbr]
      ,[SitusCity]
      ,[SitusState]
      ,[SitusZIP5]
      ,[SitusZIP4]
      ,[SitusCarrierCode]
      ,[FinalValue]
      ,[HighValue]
      ,[LowValue]
      ,[ConfidenceScore]
      ,[StandardDeviation]
      ,[ValuationDate]
      ,[StdLandUseCode]
      --,[DTDB_REF_ID]
      --,[DTDB_UNFORMATTED_APN]
      --,[DTDB_FORMATTED_APN]
	 FROM [AZUVPSQLADSF006.datatree.local].[prod_AVM_History].[dbo].[AVM_History_2022_USE_I]






GRANT SELECT ON [dbo].[vAVM_History_2022] TO [CORP\cbrady] AS [dbo]
