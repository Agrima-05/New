SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON






CREATE VIEW [Global].[dbo].[vCounty]
AS
select  cast(m.Fips as int) as Fips,
		cast(c.FIPSCode as int) as coverageFips,
		c.state,
		c.[County Name] as county_code,
		c.TaxrollActive,
		c.DeedActive,
		c.SAMActive,
		c.AssignmentActive,
		c.ReleaseActive,
		c.ForeclosureActive,
		c.TitleActive,
		c.ImageActive,
		c.MLSActive,
		c.FADeedActive,
 m.Geom4269,
 m.INTPTLAT as intptlat,
 m.INTPTLON as intptlon,
 c.[County Name] as name
FROM [DigitalMap].[dbo].[USCounty] m  with(nolock)  
inner join  Global.dbo.County c  with(nolock) on m.Fips = c.FIPSCode 



