SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON






Create VIEW [Data].[dbo].[zzz_Huntington_20181002]
AS
SELECT        FIPS as FIPS
, PropID as PropertyID
FROM            Jobs_Lkup.dbo.[Huntington_20181002] with (NOLOCK)







