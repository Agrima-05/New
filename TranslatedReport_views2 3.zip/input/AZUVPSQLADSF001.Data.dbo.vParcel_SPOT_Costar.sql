SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vParcel_SPOT_Costar]
AS
SELECT [FIPS]
      ,[PropertyID]
      ,[FormattedAPN] APN
      ,[SitusStdFullStreetAddress] SitusFullStreetAddress
      ,[SitusStdHouseNbr] SitusHouseNbr
      ,[SitusStdHouseNbrSuffix] SitusHouseNbrSuffix	
      ,[SitusStdDirectionLeft] SitusDirectionLeft
      ,[SitusStdStreet] SitusStreet
      ,[SitusStdMode] SitusMode
      ,[SitusStdDirectionRight] SitusDirectionRight
      ,[SitusStdUnitType] SitusUnitType
      ,[SitusStdUnitNbr] SitusUnitNbr
      ,[SitusStdCity] SitusCity
      ,[SitusStdState] SitusState
      ,[SitusStdZIP5] SitusZIP5
      ,[SitusStdZIP4] SitusZIP4
      ,[SitusStdCarrierCode] SitusCarrierCode      
      ,[GeomSpatial] as [Geom] 
      ,COALESCE(CS_FORMATTED_APN,DTDB_Formatted_APN) DTDB_FORMATTED_APN
	  ,COALESCE(CS_UNFORMATTED_APN,DTDB_UNFORMATTED_APN) DTDB_UNFORMATTED_APN
  FROM [Data].[dbo].[vParcel_SPOT] 


