SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[zzz_vPublix_20170823]
AS
SELECT        FIPS as FIPS
, PropertyID as PropertyID
FROM            Jobs_Lkup.dbo.Publix_20170823 with (NOLOCK)




