SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON








CREATE VIEW [Data].[dbo].[vNMLS_FirstRun--]
AS
	SELECT [Lic_FIPS] as [FIPS]
		, [Lic_TransactionID] AS [FAUniqueID]
		, [Lic_VendorPID] AS [PID]
		, [Lic_VendorSourceCode] AS [BKFSSourceCode] 
		, [Lic_RecordingDate] as [RecordingDate]
		, [Lic_DocumentNbr] AS [DocumentNumber]
		, [Lic_RecordingBook] AS [Book]
		, [Lic_RecordingPage] AS [Page]
		, [Lic_LenderName] AS [BKLenderName]
		, [_Lender] AS [LenderFlag]
		, [l_NMLSID] AS LenderNMLSID
		, [l_Name] AS [NMLSLenderName]
		, [_agent] AS [AgentFlag]
		, [a_NMLSID] AS AgentNMLSID
		, [a_Name] AS [NMLSAgentName]
		, [_broker] AS [BrokerFlag]
		, [b_NMLSID] AS BrokerNMLSID
		, [b_Name] AS [NMLSBrokerName]
		, [Lic_FAUCIDFlag] AS [FAUCIDFlag]
		, [Lic_FATimestamp] AS [FATimeStamp]
	FROM [MarketShare].[nmls].[NMLS_Roles_Combined_OUT]	with(NOLOCK)
	WHERE [Lic_VendorPID] is NOT NULL
		AND Lic_FAUCIDFlag != 'X'
								











GRANT SELECT ON [dbo].[vNMLS_FirstRun--] TO [CORP\cbrady] AS [dbo]
