SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Data].[dbo].[vHPI_FIPS]
AS
SELECT        b.FIPSCode, b.State, b.[County Name] as CountyName, a.MONTH, a.[INDEX], a.ERROR, a.LoadDate
FROM            Holocron.dbo.INDEX_VALUE_MODEL_FIPS AS a INNER JOIN
                         Global.dbo.County AS b ON a.FIPS = b.FIPSCode


GRANT SELECT ON [dbo].[vHPI_FIPS] TO [CORP\cbrady] AS [dbo]
