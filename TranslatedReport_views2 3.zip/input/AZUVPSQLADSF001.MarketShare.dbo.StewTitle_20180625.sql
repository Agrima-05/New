SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [MarketShare].[dbo].[StewTitle_20180625]
AS
SELECT        YearMonth, FIPS, [Zip Code], County, State, [Title Company], [Title Company Clean], [Transaction Type], [Property Type], date, [Sales Price], [Loan Amount], Lender, 
                         [Lender Cleaned], Builder, LoanType, Residential, Corporate, Attorney, City, RunDate, ParentTitleCo, [Buyer Name], [Seller Name]
FROM            dbo.StewTitle_20180625_ReRun

