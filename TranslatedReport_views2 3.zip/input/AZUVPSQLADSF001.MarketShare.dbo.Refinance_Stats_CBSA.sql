SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [MarketShare].[dbo].[Refinance_Stats_CBSA]
AS

SELECT *
  FROM [AZUVPSQLDTDB029.datatree.local].[Fulfillment].[dbo].[Refinance_Stats_CBSA]


