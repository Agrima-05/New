SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vParcel_SPOT_GeoCoordinates]
AS
 

	Select 
	  [FIPS]
      ,[PropertyID]
      ,[FormattedAPN] as [APN]
      ,Coalesce([CS_FORMATTED_APN],[DTDB_FORMATTED_APN]) as DTDBFormattedAPN
      ,Coalesce([CS_UNFORMATTED_APN],[DTDB_UNFORMATTED_APN]) as DTDBUnFormattedAPN

		,[SitusStdFullStreetAddress] as [SitusFullStreetAddress]
		,[SitusStdHouseNbr] as [SitusHouseNbr]
		,[SitusStdHouseNbrSuffix] as [SitusHouseNbrSuffix]
		,[SitusStdDirectionLeft] as [SitusDirectionLeft]
		,[SitusStdStreet] as [SitusStreet]
		,[SitusStdMode] as [SitusMode]
		,[SitusStdDirectionRight] as [SitusDirectionRight]
		,[SitusStdUnitType] as [SitusUnitType]
		,[SitusStdUnitNbr] as [SitusUnitNbr]
		,[SitusStdCity] as [SitusCity]
		,[SitusStdState] as [SitusState]
		,[SitusStdZIP5] as [SitusZIP5]
		,[SitusStdZIP4] as [SitusZIP4]
		,[SitusStdCarrierCode] as [SitusCarrierCode]

      ,[SitusLatitude]
      ,[SitusLongitude]
      ,[SitusGeoStatusCode]

      ,Coalesce([FANewRoofTopLatitude],[FARooftopLatitude]) as FARoofTopLatitude
      ,Coalesce([FANewRoofTopLongitude],[FARooftopLongitude]) as FARoofTopLongitude
      ,[FACentroidLatitude]
      ,[FACentroidLongitude]
      ,[FAEnhancedAddressPointLatitude]
      ,[FAEnhancedAddressPointLongitude]
      ,[FACascadeLatitude]
      ,[FACascadeLongitude]
      ,[FACascadeGeoStatusCode]
	  ,[FATimeStamp]
	  ,FAEnhancedAddressPointGeoStatusCode 

	  -----20250609 - Added for Licening STD layout
	  ,FAEnhancedAddressPointGeoStatusCode as [FAEnhancedAddressGeoStatusCode]
	  

	  --select [FACascadeGeoStatusCode], count([FACascadeGeoStatusCode]) as cnt
	FROM [Boundaries].[dbo].[FASpot_GeoCoordinates] with(NOLOCK)
	--group by [FACascadeGeoStatusCode]
	--order by [FACascadeGeoStatusCode]







