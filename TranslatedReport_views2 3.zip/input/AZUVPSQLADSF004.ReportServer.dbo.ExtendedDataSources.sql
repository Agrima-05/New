SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [ReportServer].[dbo].[ExtendedDataSources]
AS
SELECT
	DSID, ItemID, SubscriptionID, Name, Extension, Link,
	CredentialRetrieval, Prompt, ConnectionString,
	OriginalConnectionString, OriginalConnectStringExpressionBased,
	UserName, Password, Flags, Version
FROM DataSource
UNION ALL
SELECT
	DSID, ItemID, NULL as [SubscriptionID], Name, Extension, Link,
	CredentialRetrieval, Prompt, ConnectionString,
	OriginalConnectionString, OriginalConnectStringExpressionBased,
	UserName, Password, Flags, Version
FROM [ReportServerTempDB].dbo.TempDataSources

GRANT REFERENCES ON [dbo].[ExtendedDataSources] TO [RSExecRole] AS [dbo]
GRANT SELECT ON [dbo].[ExtendedDataSources] TO [RSExecRole] AS [dbo]
