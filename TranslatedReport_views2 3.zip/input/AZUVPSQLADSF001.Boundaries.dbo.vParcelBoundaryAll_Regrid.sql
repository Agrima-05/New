SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Boundaries].[dbo].[vParcelBoundaryAll_Regrid]
AS
SELECT        [FAMasterID], PropertyID, [APN], [FIPS], [Longitude], [Latitude], [ParcelGeography], [ParcelGeometry], [ParcelPointGeography], [ParcelPointGeometry], [EstLotSizeSqFt], [AddressScore], [GeoSource], 
                         [PARCELAPN], [FAGeoStatusCode], [LatLonGeometry], [DmDate], [MatchCode], [UpdateFlag], [RefId], [PRCLDMPID], [PROPDMPID], [ParcelGeometry4269], [ParcelPointGeometry4269], [Id], [FATimestamp], 
                         [GeomWKT], [UCIDFlag], [PointWKT]
FROM            [Boundaries].[dbo].[FAReGrid]
/*-[FADigitalMap_HJ]*/ WHERE [ParcelGeometry4269] IS NOT NULL
--UNION ALL
--SELECT        [FAMasterID], NULL AS PropertyID, [APN], [FIPS], [Longitude], [Latitude], [ParcelGeography], [ParcelGeometry], [ParcelPointGeography], [ParcelPointGeometry], [EstLotSizeSqFt], [AddressScore], 
--                         [GeoSource], [PARCELAPN], [FAGeoStatusCode], [LatLonGeometry], [DmDate], [MatchCode], [UpdateFlag], [RefId], [PRCLDMPID], [PROPDMPID], [ParcelGeometry4269], [ParcelPointGeometry4269], [Id], 
--                         [FATimestamp], [GeomWKT], [UCIDFlag], [PointWKT]
--FROM            [Boundaries].[dbo].[FAReGridUnMatched]


