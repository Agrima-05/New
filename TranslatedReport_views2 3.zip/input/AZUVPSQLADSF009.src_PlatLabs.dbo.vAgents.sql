SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



 Create view [src_PlatLabs].[dbo].[vAgents] 
 as
 ---- PHOTO LINKS WITH REF_ID

	 SELECT [uid]
      ,[office_uid]
      ,[dp_member_id]
      ,[dp_office_id]
      ,[originating_system_id]
      ,[originating_system_name]
      ,[subsystem_locale]
      ,[mls_id]
      ,[active]
      ,[last_update_date]
      ,[mls_create_date]
      ,[mls_update_date]
      ,[title]
      ,[photo_url]
      ,[address]
      ,[city]
      ,[zip]
      ,[state]
      ,[primary_association]
      ,[country_code]
      ,[designations]
      ,[preferred_phone_number]
      ,[cellphone_number]
      ,[email]
      ,[fax]
      ,[first_name]
      ,[last_name]
      ,[middle_name]
      ,[username]
      ,[full_name]
      ,[mlskey]
      ,[mo_key]
      ,[preferred_language]
      ,[nrds_id]
      ,[nickname]
      ,[office_number]
      ,[license_number]
      ,[license_state]
      ,[status]
      ,[toll_free_phone]
      ,[type]
      ,[blog_address]
      ,[facebook_url]
      ,[linked_in_url]
      ,[website]
      ,[mobile_carrier]
      ,[standardized_preferred_phone_number]
      ,[standardized_cellphone_number]
      ,[member_status_date]
      ,[LoadDate]
	 from agent.Platlabs_agents a with(NOLOCK) 
	 WHERE mls_id in(Select mls_id from platlabs_update_config where code like '%_39' and active = '1')



