SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [DTDBListings].[dbo].[vActiveHeatMap]
AS
SELECT        NormalizedAddress_Zip, COUNT(*) AS ActiveCount
FROM            dbo.Listings WITH (nolock)
WHERE        (status = 'active')
GROUP BY NormalizedAddress_Zip

