SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Enformion].[dbo].[EnformData] as (

SELECT a.[FIPS]
,a.[REF_ID]
--,a.[PropertyID]
,p.[PID]
,a.[FullStreetAddress] as StandardizedFullAddress
,a.[City] as StandardizedCity
,a.[State] as StandardizedState
,a.[Zip] as StandardizedZip
,a.[ZIP4] as StandardizedZip4
,a.[Latitude] as StandardizedLatitude
,a.[Longitude] as StandardizedLongitude
,p.[firstname] as PersonFirstName
,p.[middlename] as PersonMiddleName
,p.[lastname] as PersonLastName
,p.[suffix] as PersonSuffix
,p.[deceased] as PersonDeceased
,p.[age] as PersonAge
,k.[firstname] as AKAFirstName
,k.[middlename] as AKAPersonMiddleName
,k.[lastname] as AKAPersonLastName
,k.[suffix] as AKAPersonSuffix
,k.[first_reported] as AKAFirstReported
,k.[last_reported] as AKALasatReported
,k.[rank] as AKARank
,c.[rdid] as ConsumerRDID
,c.[estimatedincome] as ConsumerEstimatedIncome
,c.[numberofchildren] as ConsumerNumberOfChildrn
,c.[personmaritalstatus] as ConsumerPersonMaritalStatus
,c.[occupationgroup] as ConsumerOccupantionGroup
,c.[personoccupation] as ConsumerPersonOccupation
,c.[personeducation] as ConsumerPersonEducation
,c.[businessowner] as ConsumerBusinessOwner
,c.[gender] as ConsumerGender
,c.[networth] as ConsumerNetWorth
,c.[estimatedcurrenthomevalue] as ConsumerEstimatedCurrentHomeValue
,c.[ethnicity] as ConsumerEthnicity
,c.[language] as ConsumerLanguage
,CASE WHEN FIPS like '06%' THEN NULL ELSE e.[email] END as EmailsEmail
,CASE WHEN FIPS like '06%' THEN NULL ELSE e.[rank] END as EmailsRank
,CASE WHEN FIPS like '06%' THEN NULL ELSE ph.[phone] END as PhonesPhoneNumber
,CASE WHEN FIPS like '06%' THEN NULL ELSE ph.[phonetype] END as PhonesPhoneType
,CASE WHEN FIPS like '06%' THEN NULL ELSE ph.[first_reported] END as PhonesFirstReported
,CASE WHEN FIPS like '06%' THEN NULL ELSE ph.[last_reported] END as PhonesLastReported
,CASE WHEN FIPS like '06%' THEN NULL ELSE ph.[rank] END as PhonesRank
FROM [dbo].[person] p 
	JOIN [dbo].[StandardizedAddress] a ON p.PID = a.RAW_ID
	JOIN [dbo].[akas] k on p.PID = k.PID
	JOIN [dbo].[consumer] c on p.PID = c.PID
	JOIN [dbo].[emails] e on p.PID = e.PID
	JOIN [dbo].[phones] ph on p.PID = ph.PID
 )

