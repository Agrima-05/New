SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Platlabs].[dbo].[vPlatlabs_Offices]
AS

		Select distinct dp_office_id [SrcOfficeID]
			  ,m.MLSID [SrcMLSID]
			  ,dp_office_id [SrcMLSOfficeID]
			  ,full_name [SrcOfficeName]
			  ,LEFT([address],100) [Address1]
			  ,NULL [Address2]
			  ,city [City]
			  ,o.[state] [State]
			  ,NULL [CountyID]
			  ,o.zip [Zip]
			  ,o.phone [Phone]
			  ,o.email [Email]
			  ,[DateCreated]
			  ,[LastModifiedDate]
			  ,o.LoadDate [DW_TimeStamp]
			  ,NULL [Longitude]
			  ,NULL [Latitude]
			  ,NULL [FASTOfficeAddrBookID]
			  ,NULL [OfficeRank]
			  ,[address] [SourceAddress1]
			  ,NULL [SourceAddress2]
			  ,[city] [SourceCity]
			  ,o.[state] [SourceState]
			  ,o.zip [SourceZip]
			  ,NULL [CassCertifiedAddress1]
			  ,NULL [CassCertifiedAddress2]
			  ,NULL [CassCertifiedCity]
			  ,NULL [CassCertifiedState]
			  ,NULL [CassCertifiedZip]
			  ,case when o.active like 'true' then 1 else 0 end [IsActive]
			  ,o.mls_id Platlabs_mls_id
			  ,o.dp_office_id Platlabs_OfficeID

		 from [src_PlatLabs].[Office].[Platlabs_Offices] o 
			LEFT OUTER JOIN [dbo].[Platlabs_ActiveAgentsByMLSID] b
				on o.[mls_id] = b.mls_id
			LEFT OUTER JOIN [dbo].[LookupMLSs] m
				on o.mls_id = m.mls_id
		WHERE o.mls_id in(Select mls_id from src_Platlabs.dbo.platlabs_update_config with(NOLOCK) where active = '1' and code like '%39')

