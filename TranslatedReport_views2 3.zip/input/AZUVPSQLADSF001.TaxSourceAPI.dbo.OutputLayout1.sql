SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON












CREATE View [TaxSourceAPI].[dbo].[OutputLayout1] AS

SELECT   
	Id
	,BatchId
	,ExternalKey,
	JSON_VALUE([PostBack], '$.PropertyId') AS PropertyId,
	JSON_VALUE([PostBack], '$.ReportName') AS ReportName,

	JSON_VALUE([PostBack], '$.ReportStatus') AS ReportStatus,
	JSON_VALUE([PostBack], '$.ReferenceId') AS ReferenceId,
	JSON_VALUE([PostBack], '$.OrderItemId') AS OrderItemId,
	JSON_VALUE([PostBack], '$.Data.SubjectProperty.SitusAddress.StreetAddress') AS StreetAddress,
	JSON_VALUE([PostBack], '$.Data.SubjectProperty.SitusAddress.City') AS City,
	JSON_VALUE([PostBack], '$.Data.SubjectProperty.SitusAddress.State') AS State,
	JSON_VALUE([PostBack], '$.Data.SubjectProperty.SitusAddress.Zip9') AS Zip9,
	JSON_VALUE([PostBack], '$.Data.SubjectProperty.SitusAddress.County') AS County,
	--JSON_VALUE([PostBack], '$.Data.SubjectProperty.SitusAddress.SitusCarrierRoute') AS SitusCarrierRoute,
	JSON_VALUE([PostBack], '$.Data.SubjectProperty.SitusAddress.APN') AS APN,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.StateFips') AS StateFips,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.CountyFips') AS CountyFips,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.ReportAsOfDate')) AS ReportAsOfDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.AssessorsAlternateParcelIdentifier') AS AssessorsAlternateParcelIdentifier,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.ExtendedLegalDescription') AS ExtendedLegalDescription,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.LandUse') AS LandUse,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.TraCode') AS TraCode,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.TraName') AS TraName,
	--JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.SitusAddress.Zip5') AS Zip5,
	--JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.SitusAddress.ZipPlus4') AS ZipPlus4,
	--JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.SitusAddress.AddressString') AS AddressString,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.AssessorInformation.PropertyOwners[0].OwnerNames') AS OwnerNames,
	replace(replace(JSON_QUERY([PostBack], '$.Data.Errors'),'[',''),']','') AS Errors,
	--JSON_VALUE([PostBack], '$.Data.SearchRequestId') AS SearchRequestId,
	JSON_VALUE([PostBack], '$.Message') AS Message,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].MismoAgencyCode') AS Agency1_MismoAgencyCode,		
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].AgencyName') AS Agency1_Name,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].AgencyType') AS Agency1_AgencyType,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxCollectorUrl') AS Agency1_TaxCollectorUrl,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].PhoneNumber') AS Agency1_PhoneNumber,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].FaxNumber') AS Agency1_FaxNumber,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].Email') AS Agency1_Email,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].MakePayableTo') AS Agency1_MakePayableTo,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].StreetAddress') AS Agency1_StreetAddress,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].CityStateZip') AS Agency1_CityStateZip,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].MailingStreet') AS Agency1_MailingStreet,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].MailingCityStateZip') AS Agency1_MailingCityStateZip,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxYearType') AS Agency1_TaxYearType,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxYearDates') AS Agency1_TaxYearDates,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].CurrentTaxYear') AS Agency1_CurrentTaxYear,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].CollectsInArrears') AS Agency1_CollectsInArrears,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].DiscountAgency') AS Agency1_DiscountAgency,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].DuplicateBillRequired') AS Agency1_DuplicateBillRequired,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].DuplicateBillFee') AS Agency1_DuplicateBillFee,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].ExternalAgencyNotes') AS Agency1_ExternalAgencyNotes,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.AsOfDate')) AS TaxDetails_AsOfDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.SchoolDistrict') AS TaxDetails_SchoolDistrict,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxId') AS TaxDetails_TaxId,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.DelinquentTaxes') AS TaxDetails_DelinquentTaxes,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxReportStatus') AS TaxDetails_TaxReportStatus,
	--JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxYear') AS TaxDetails_TaxYear,


	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.DelinquencyTaxSaleYear') AS TaxDetails_DelinquencyTaxSaleYear,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.TaxYear') AS TaxYear,

	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.TaxType') AS TaxType,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.TaxSupplementalAPN') AS TaxSupplementalAPN,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.TotalTax') AS TotalTax,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.ImprovementValue') AS ImprovementValue,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.LandVal') AS LandVal,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.AssessedTotalValue') AS AssessedTotalValue,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.AssessedYear') AS AssessedYear,


	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.ExemptionType') AS ExemptionType,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.ExemptionAmount') AS ExemptionAmount,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.NetVal') AS NetVal,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.CertificateOfPurchase') AS CertificateOfPurchase,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.Message') AS TaxInstallmentsMessage,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.TaxBillNumber') AS TaxBillNumber,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].SequenceId') AS InstallmentDetail1_SequenceId,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].Amount') AS InstallmentDetail1_Amount,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].Status') AS InstallmentDetail1_Status,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].PaymentDate')) AS InstallmentDetail1_PaymentDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].AmountDue') AS InstallmentDetail1_AmountDue,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].PartialPayAmt') AS InstallmentDetail1_PartialPayAmt,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].DueDate')) AS InstallmentDetail1_DueDate,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].DelinquentDate')) AS InstallmentDetail1_DelinquentDate,
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].EstimatedAmountGoodThrough'))) AS InstallmentDetail1_EstimatedAmountGoodThrough,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].DiscountDate')) AS InstallmentDetail1_DiscountDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].Penalty') AS InstallmentDetail1_Penalty,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[0].Interest') AS InstallmentDetail1_Interest,
	
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].SequenceId') AS InstallmentDetail2_SequenceId,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].Amount') AS InstallmentDetail2_Amount,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].Status') AS InstallmentDetail2_Status,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].PaymentDate')) AS InstallmentDetail2_PaymentDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].AmountDue') AS InstallmentDetail2_AmountDue,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].PartialPayAmt') AS InstallmentDetail2_PartialPayAmt,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].DueDate')) AS InstallmentDetail2_DueDate,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].DelinquentDate')) AS InstallmentDetail2_DelinquentDate,
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].EstimatedAmountGoodThrough'))) AS InstallmentDetail2_EstimatedAmountGoodThrough,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].DiscountDate')) AS InstallmentDetail2_DiscountDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].Penalty') AS InstallmentDetail2_Penalty,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[1].Interest') AS InstallmentDetail2_Interest,

	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].SequenceId') AS InstallmentDetail3_SequenceId,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].Amount') AS InstallmentDetail3_Amount,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].Status') AS InstallmentDetail3_Status,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].PaymentDate')) AS InstallmentDetail3_PaymentDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].AmountDue') AS InstallmentDetail3_AmountDue,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].PartialPayAmt') AS InstallmentDetail3_PartialPayAmt,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].DueDate')) AS InstallmentDetail3_DueDate,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].DelinquentDate')) AS InstallmentDetail3_DelinquentDate,
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].EstimatedAmountGoodThrough'))) AS InstallmentDetail3_EstimatedAmountGoodThrough,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].DiscountDate')) AS InstallmentDetail3_DiscountDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].Penalty') AS InstallmentDetail3_Penalty,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[2].Interest') AS InstallmentDetail3_Interest,

	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].SequenceId') AS InstallmentDetail4_SequenceId,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].Amount') AS InstallmentDetail4_Amount,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].Status') AS InstallmentDetail4_Status,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].PaymentDate')) AS InstallmentDetail4_PaymentDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].AmountDue') AS InstallmentDetail4_AmountDue,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].PartialPayAmt') AS InstallmentDetail4_PartialPayAmt,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].DueDate')) AS InstallmentDetail4_DueDate,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].DelinquentDate')) AS InstallmentDetail4_DelinquentDate,
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].EstimatedAmountGoodThrough'))) AS InstallmentDetail4_EstimatedAmountGoodThrough,
	dbo.RemoveTimestamp(JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].DiscountDate')) AS InstallmentDetail4_DiscountDate,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].Penalty') AS InstallmentDetail4_Penalty,
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.TaxInstallments.InstallmentDetail[3].Interest') AS InstallmentDetail4_Interest,

	--JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails[0]') AS RedemptionDetails1_PaymentGoodThrough,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[0].TaxYear') as OtherTaxDetails1_TaxYear,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[0].TaxType') as OtherTaxDetails1_TaxType,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[0].TaxSupplementalAPN') as OtherTaxDetails1_TaxSupplementalAPN,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[0].TotalTax') as OtherTaxDetails1_TotalTax,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[0].CertificateOfPurchase') as OtherTaxDetails1_CertificateOfPurchase,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[0].TaxBillNumber') as OtherTaxDetails1_TaxBillNumber,

	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[1].TaxYear') as OtherTaxDetails2_TaxYear,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[1].TaxType') as OtherTaxDetails2_TaxType,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[1].TaxSupplementalAPN') as OtherTaxDetails2_TaxSupplementalAPN,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[1].TotalTax') as OtherTaxDetails2_TotalTax,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[1].CertificateOfPurchase') as OtherTaxDetails2_CertificateOfPurchase,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[1].TaxBillNumber') as OtherTaxDetails2_TaxBillNumber,

	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[2].TaxYear') as OtherTaxDetails3_TaxYear,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[2].TaxType') as OtherTaxDetails3_TaxType,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[2].TaxSupplementalAPN') as OtherTaxDetails3_TaxSupplementalAPN,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[2].TotalTax') as OtherTaxDetails3_TotalTax,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[2].CertificateOfPurchase') as OtherTaxDetails3_CertificateOfPurchase,
	JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[2].TaxBillNumber') as OtherTaxDetails3_TaxBillNumber,

	case when JSON_VALUE(dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')),  '$[3].TaxYear') is not null then 'Y' else 'N' end AS AdditionalOtherTaxDetails,
	--dbo.OtherTaxDetailsCustomJson(ISNULL(JSON_QUERY([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.OtherTaxDetails'),'')) as OtherTaxDetails0_TaxYear,

	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[0].Amount') AS RedemptionDetails1_Amount,
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](dbo.ChooseBestDate(
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[0].RedemptionDate'),
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[0].Year'),
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[0].Month') 
	)))                                                                                                              AS RedemptionDetails1_RedemptionDate,	
	
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[0].PaymentGoodThrough'))) AS RedemptionDetails1_PaymentGoodThrough,


	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[1].Amount') AS RedemptionDetails2_Amount,
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](dbo.ChooseBestDate(
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[1].RedemptionDate'),
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[1].Year'),
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[1].Month') 
	)))                                                                                                              AS RedemptionDetails2_RedemptionDate,	
	
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[1].PaymentGoodThrough'))) AS RedemptionDetails2_PaymentGoodThrough,


	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[2].Amount') AS RedemptionDetails3_Amount,
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](dbo.ChooseBestDate(
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[2].RedemptionDate'),
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[2].Year'),
	JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[2].Month') 
	)))                                                                                                                AS RedemptionDetails3_RedemptionDate,	
	dbo.RemoveTimestamp(dbo.[LastDayOfMonth](JSON_VALUE([PostBack], '$.Data.TaxStatus.Agencies[0].TaxDetails.RedemptionDetails[2].PaymentGoodThrough'))) AS RedemptionDetails3_PaymentGoodThrough
  FROM [TaxSourceAPI].[dbo].[Property]


