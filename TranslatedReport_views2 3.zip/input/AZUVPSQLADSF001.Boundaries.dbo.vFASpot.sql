SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON




CREATE VIEW [Boundaries].[dbo].[vFASpot]
AS

	SELECT * FROM [Boundaries].[dbo].[FASpot]
	UNION ALL
	SELECT * FROM [Boundaries].[dbo].[FASpot_Generated]


