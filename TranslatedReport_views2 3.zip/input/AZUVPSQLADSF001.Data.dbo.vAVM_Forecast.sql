SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [Data].[dbo].[vAVM_Forecast]
AS
SELECT b.[Fips],
		b.[PropertyID],
		b.[FormattedAPN] as [APN],
		b.[SitusStdFullStreetAddress] as [SitusFullStreetAddress],
		b.[SitusStdHouseNbr] as [SitusHouseNbr],
		b.[SitusStdHouseNbrSuffix] as [SitusHouseNbrSuffix],
		b.[SitusStdDirectionLeft] as [SitusDirectionLeft],
		b.[SitusStdStreet] as [SitusStreet],
		b.[SitusStdMode] as [SitusMode],
		b.[SitusStdDirectionRight] as [SitusDirectionRight],
		b.[SitusStdUnitType] as [SitusUnitType],
		b.[SitusStdUnitNbr] as [SitusUnitNbr],
		b.[SitusStdCity] as [SitusCity],
		b.[SitusStdState] as [SitusState],
		b.[SitusStdZIP5] as [SitusZIP5],
		b.[SitusStdZIP4] as [SitusZIP4],
		b.[SitusStdCarrierCode] as [SitusCarrierCode],
		a.[POWER_FINAL_VALUE] as FinalValue,
		a.[POWER_HIGH_VALUE] as HighValue,
		a.[POWER_LOW_VALUE] as LowValue,
		a.[POWER_CONFIDENCE_SCORE] as [ConfidenceScore],
		a.[POWER_FORECAST_STANDARD_DEVIATION] as [StandardDeviation],
		convert(varchar(8),convert(date,a.[VALUE_AS_OF]),112) as [ValuationDate],
		COALESCE(CS_UNFORMATTED_APN,DTDB_UNFORMATTED_APN) DTDB_UNFORMATTED_APN,
		c.[MONTH],
		c.[INDEX], 
		ROUND(((d.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth1Value,
		ROUND(((e.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth2Value,
		ROUND(((f.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth3Value,
		ROUND(((g.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth4Value,
		ROUND(((h.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth5Value,
		ROUND(((i.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth6Value,
		ROUND(((j.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth7Value,
		ROUND(((k.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth8Value,
		ROUND(((l.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth9Value,
		ROUND(((m.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth10Value,
		ROUND(((n.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth11Value,
		ROUND(((o.[INDEX] - c.[INDEX]) * a.POWER_FINAL_VALUE) +  a.POWER_FINAL_VALUE,-3) as ForeCastMonth12Value
	 from Holocron.dbo.Holocron a with(NOLOCK) JOIN data.dbo.property b with(NOLOCK)
		on a.Fipscode = b.FIPS
		and a.PropertyID = b.PropertyID
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2024-12') c
		on b.SitusStdZIP5 = c.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-01') d
		on b.SitusStdZIP5 = d.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-02') e
		on b.SitusStdZIP5 = e.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-03') f
		on b.SitusStdZIP5 = f.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-04') g
		on b.SitusStdZIP5 = g.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-05') h
		on b.SitusStdZIP5 = h.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-06') i
		on b.SitusStdZIP5 = i.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-07') j
		on b.SitusStdZIP5 = j.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-08') k
		on b.SitusStdZIP5 = k.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-09') l
		on b.SitusStdZIP5 = l.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-10') m
		on b.SitusStdZIP5 = m.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-11') n
		on b.SitusStdZIP5 = n.ZIP
		JOIN (Select * FROM Holocron.dbo.INDEX_VALUE_MODEL_ZIP with(NOLOCK) WHERE MONTH = '2025-12') o
		on b.SitusStdZIP5 = o.ZIP
	WHERE a.[POWER_FINAL_VALUE] > 0



