SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

create VIEW [Data].[dbo].[Ditech]
AS
SELECT        PropertyID
FROM            Jobs_Lkup.dbo.Ditech_20170912


