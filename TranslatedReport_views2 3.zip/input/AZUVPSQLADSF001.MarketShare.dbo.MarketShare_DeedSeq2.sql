SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON

CREATE VIEW [MarketShare].[dbo].[MarketShare_DeedSeq2]
AS
SELECT        DeedID, [Transaction Type], [Transaction Type Clean], Lender, [Title Company], Attorney, [Sale Document number], [MGT Document number], [Book/Page], [Sales Price], [Loan Amount], [Loan To Value], DATE, [Adjustable Rate], 
                         [Loan Type], [Reverse Mortgage], Conforming, Builder, [Seller Name], Buyer, Residential, Corporate, City, County, STATE, [Zip Code], FIPS, [Census Tract #], [Property Type], MTG1_PRIVATE_PARTY_LENDER, DeedSequence, 
                         Rundate, FMT_DOC_NBR, FMT_Book_Page, FMT_MTG1_DOC_NBR, FMT_MTG1_Book_Page, Ref_ID, UpdateDate, [Title Company Clean], [Lender Clean], [Parent Title Co], SITUS_Address, SITUS_CITY, SITUS_STATE, 
                         SITUS_ZIP_CODE, FORMATTED_APN, LenderAddress, LenderCity, LenderState, LenderZip, ROW4, UseRecord, PropertyID, FIPSCode, TransactionID, BrokerName, BrokerNMLSID, AgentName, AgentNMLSID, LenderName, 
                         LenderNMLSID, FATimestamp, FAUCIDFlag, MarketShare, LoanIntRate, Listing_Agent_Name, Listing_Agent_Address, Listing_Agent_Phone, Listing_Agent_Email, Office_Name, Office_Address, Office_Phone, Office_Email
FROM            dbo.bulkMKSHR_ALL with(NOLOCK)
WHERE        (DeedSequence = 2)
--and isNULL(FAUCIDFlag,'') != 'D'


