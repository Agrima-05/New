SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


 CREATE view [Extracts].[dbo].[HW_Agents_V2] 
 as
		SELECT [SrcAgentID]
			  ,[SrcOfficeID]
			  ,[SrcMLSID]
			  ,[SrcMLSAgentID]
			  ,[FirstName]
			  ,[MiddleInitial]
			  ,[LastName]
			  ,[Email]
			  ,[Phone1]
			  ,[PhoneType1]
			  ,[Phone2]
			  ,[PhoneType2]
			  ,[Phone3]
			  ,[PhoneType3]
			  ,[Fax]
			  ,[LastModifiedDate]
			  ,[DW_TimeStamp]
			  ,[DateCreated]
			  ,[FASTContactAddrBookID]
			  ,[FormerOfficeID]
			  ,[OfficeChangedDate]
			  ,[Website]
			  ,[IsActive]
			  ,[LicenseNumber]
			  ,[ID]
			  ,l.[LoadDate]
			  ,[Platlabs_uid]
			  ,[Platlabs_mls_id]
			  ,[SrcMLSOfficeID]
			  ,a.FullStreetAddress as StandardizedFullStreetAddress
			  ,a.StreetNumber as StandardizedHouseNbr
			  ,a.PreDir  as StandardizedLeftDirection
			  ,a.StreetName as StandardizedStreet
			  ,a.StreetType as StandardizedMode
			  ,a.PostDir as StandardizedRightDirection
			  ,a.SuiteType as StandardizedUnitType
			  ,a.Suite as StandardizedUnitNumber
			  ,a.[City] as StandardizedCity
			  ,a.[State] as StandardizedState
			  ,a.[Zip] as StandardizedZip
		  FROM [Platlabs].[dbo].[Platlabs_src_agents] l with(NOLOCK)
			 JOIN Reports.dbo.SentToHW_Listings b on l.[SrcMLSID] = b.mls_id
			 JOIN [ASP_Offcycle].addr.StandardizedAddress_Agent a on l.SrcMLSID = a.mls_id and l.SrcMLSAgentID = a.dp_member_id
			WHERE l.[SrcMLSID] in(Select mls_id from src_platlabs.dbo.platlabs_update_config with(NOLOCK) where code like '%_39' and active = '1')
				and l.[LoadDate] > b.[DateSentUpdates]

				--Select * from Reports.dbo.SentToHW_Listings

