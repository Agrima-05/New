SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON



CREATE VIEW [Boundaries].[dbo].[vFASpot_Xfer_Missing]
AS

SELECT DISTINCT * FROM 
	(SELECT [FADigitalMapMasterId]
	  ,[UniqueGuid]
      ,RefId [PropertyID]
      ,[FIPS]
      ,[GeomWKT]
	  ,[PointWKT]
  FROM [dbo].[FASpot] with(NOLOCK)
  WHERE PointGeometry3857 is NULL


  UNION ALL

  SELECT [FADigitalMapMasterId]
	  ,[UniqueGuid]
      ,RefId [PropertyID]
      ,[FIPS]
      ,[GeomWKT]
	  ,[PointWKT]
  FROM [dbo].[FASpot_a] with(NOLOCK)
  WHERE PointGeometry3857 is NULL


  --UNION ALL

  --SELECT [FADigitalMapMasterId]
 	--  ,[UniqueGuid]
  --   ,RefId [PropertyID]
  --    ,[FIPS]
  --    ,[GeomWKT]
	 -- ,[PointWKT]
  --FROM [dbo].[FASpot_Generated] with(NOLOCK)

  --UNION ALL

  --SELECT [FADigitalMapMasterId]
	 -- ,[UniqueGuid]
  --    ,RefId [PropertyID]
  --    ,[FIPS]
  --    ,[GeomWKT]
	 -- ,[PointWKT]
  --FROM [dbo].[FASpot_Generated_a] with(NOLOCK)
  ) XFER
  WHERE ([UniqueGuid] is not null or [PropertyID] is not null)  


