SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [src_SHIP].[dbo].[IN_SalesFile]
AS
SELECT        b.FIPS, a.SDF_ID, a.SalesPrice, a.SaleDate, a.TransferDate AS RecordingDate, a.ParcelNumber, a.PropertyClassCode, a.ParcelAcreage, a.TaxDistrict, a.PreparerCompany, a.PreparerAddress, a.SellerName, a.BuyerName, 
                         a.C5_Other, PARSENAME(REPLACE(a.ParcelAddress, ',', '.'), 4) AS 'SitusADDR', PARSENAME(REPLACE(a.ParcelAddress, ',', '.'), 3) AS 'SitusCITY', PARSENAME(REPLACE(a.ParcelAddress, ',', '.'), 2) AS 'SitusSTATE', 
                         PARSENAME(REPLACE(a.ParcelAddress, ',', '.'), 1) AS 'SitusZIP', PARSENAME(REPLACE(a.BuyerAddress, ',', '.'), 4) AS 'BuyerADDR', PARSENAME(REPLACE(a.BuyerAddress, ',', '.'), 3) AS 'BuyerCITY', 
                         PARSENAME(REPLACE(a.BuyerAddress, ',', '.'), 2) AS 'BuyerSTATE', PARSENAME(REPLACE(a.BuyerAddress, ',', '.'), 1) AS 'BuyerZIP', PARSENAME(REPLACE(a.SellerAddress, ',', '.'), 4) AS 'SellerADDR', 
                         PARSENAME(REPLACE(a.SellerAddress, ',', '.'), 3) AS 'SellerCITY', PARSENAME(REPLACE(a.SellerAddress, ',', '.'), 2) AS 'SellerSTATE', PARSENAME(REPLACE(a.SellerAddress, ',', '.'), 1) AS 'SellerZIP'
FROM            dbo.SHIP_Work_IN_SDF_NEW AS a INNER JOIN
                         dbo.IN_FIPSLkup AS b ON RIGHT(LEFT(a.SDF_ID, 3), 2) = b.COUNTYID

