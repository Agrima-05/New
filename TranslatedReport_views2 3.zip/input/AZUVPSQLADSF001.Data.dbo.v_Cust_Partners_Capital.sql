SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[v_Cust_Partners_Capital]
AS
SELECT DISTINCT 
                         TOP (100) PERCENT dbo.Property.FIPS, dbo.Property.PropertyID, dbo.Property.FormattedAPN, dbo.Property.APNSeqNbr, dbo.Property.OldAPN, dbo.Property.TaxAccountNumber, dbo.Property.SitusStdHouseNbr, 
                         dbo.Property.SitusStdHouseNbr2, dbo.Property.SitusStdHouseNbrSuffix, dbo.Property.SitusStdDirectionLeft, dbo.Property.SitusStdStreet, dbo.Property.SitusStdMode, dbo.Property.SitusStdDirectionRight, 
                         dbo.Property.SitusStdUnitType, dbo.Property.SitusStdUnitNbr, dbo.Property.SitusStdCity, dbo.Property.SitusStdState, dbo.Property.SitusStdZIP5, dbo.Property.SitusStdZIP4, dbo.Property.SitusStdCarrierCode, 
                         CASE WHEN StdLandUseCode BETWEEN '1000' AND '1999' THEN 'R' WHEN StdLandUseCode BETWEEN '2000' AND '2999' THEN 'C' WHEN StdLandUseCode BETWEEN '3000' AND 
                         '3999' THEN 'O' WHEN StdLandUseCode BETWEEN '4000' AND '4999' THEN 'F' WHEN StdLandUseCode BETWEEN '5000' AND '6099' THEN 'I' WHEN StdLandUseCode BETWEEN '6500' AND 
                         '6599' THEN 'T' WHEN StdLandUseCode BETWEEN '7000' AND '7999' THEN 'A' WHEN StdLandUseCode BETWEEN '8000' AND '8999' THEN 'V' WHEN StdLandUseCode BETWEEN '9000' AND 
                         '9999' THEN 'E' ELSE NULL END AS PropertyClassID, dbo.Property.StdLandUseCode, dbo.Property.StateLandUseCode, dbo.Property.CountyLandUseCode, dbo.Property.Zoning, dbo.Property.SitusCensusTract, 
                         dbo.Property.MobileHomeInd, dbo.Property.TimeshareCode, dbo.Property.LotSizeFrontageFeet, dbo.Property.LotSizeDepthFeet, dbo.Property.LotSizeAcres, dbo.Property.LotSizeSqFt, dbo.Property.LotIrregularInd,
                          dbo.Property.OwnerStd1CorpInd, dbo.Property.OwnerStd1LastName, dbo.Property.OwnerStd1FirstName, dbo.Property.OwnerStd1MiddleName, dbo.Property.OwnerStd1Suffix, dbo.Property.OwnerStd2CorpInd, 
                         dbo.Property.OwnerStd2LastName, dbo.Property.OwnerStd2FirstName, dbo.Property.OwnerStd2MiddleName, dbo.Property.OwnerStd2Suffix, dbo.Property.OwnerStdNAME1FULL, 
                         dbo.Property.OwnerStdNAME2FULL, dbo.Property.OwnerOccupied, dbo.Property.OwnerStd2OwnershipRights, dbo.Property.OwnerStd2RelationshipType, dbo.Property.MailingStdHouseNbr, 
                         dbo.Property.MailingStdHouseNbr2, dbo.Property.MailingStdHouseNbrSuffix, dbo.Property.MailingStdDirectionLeft, dbo.Property.MailingStdStreet, dbo.Property.MailingStdMode, 
                         dbo.Property.MailingStdDirectionRight, dbo.Property.MailingStdUnitType, dbo.Property.MailingStdUnitNbr, dbo.Property.MailingStdCity, dbo.Property.MailingStdState, dbo.Property.MailingStdZIP5, 
                         dbo.Property.MailingStdZIP4, dbo.Property.MailingStdCarrierCode, dbo.Property.MailingOptOut, dbo.Property.AssdTotalValue, dbo.Property.AssdLandValue, dbo.Property.AssdImprovementValue, 
                         dbo.Property.MarketTotalValue, dbo.Property.MarketValueLand, dbo.Property.MarketValueImprovement
						,CASE WHEN ([DBSTaxYear] > [TaxYear] and [DBSTaxAmount] is not null) THEN [DBSTaxAmount] ELSE [TaxAmount] END as 'TaxAmount'
						,CASE WHEN ([DBSTaxYear] > [TaxYear] and [DBSTaxAmount] is not null) THEN [DBSTaxYear] ELSE [TaxYear] END as 'TaxYear'
						 , dbo.Property.TaxDeliquentYear1, dbo.Property.AssdYear, 
                         dbo.Property.TaxRateCodeArea, dbo.Property.SchoolTaxDistrict1Code, dbo.Property.SchoolTaxDistrict2Code, dbo.Property.SchoolTaxDistrict3Code, dbo.Property.HomesteadInd, dbo.Property.VeteranInd, 
                         dbo.Property.DisabledInd, dbo.Property.WidowInd, dbo.Property.SeniorInd, dbo.Property.SchoolCollegeInd, dbo.Property.ReligiousInd, dbo.Property.WelfareInd, dbo.Property.PublicUtilityInd, 
                         dbo.Property.CemeteryInd, dbo.Property.HospitalInd, dbo.Property.LibraryInd, dbo.Property.BuildingArea, dbo.Property.BuildingAreaInd, dbo.Property.SumBuildingSqFt, dbo.Property.SumLivingAreaSqFt, 
                         dbo.Property.SumGroundFloorSqFt, dbo.Property.SumGrossAreaSqFt, dbo.Property.SumAdjAreaSqFt, dbo.Property.SumBasementSqFt, dbo.Property.SumGarageSqFt, dbo.Property.YearBuilt, 
                         dbo.Property.EffectiveYearBuilt, dbo.Property.Bedrooms, dbo.Property.TotalRooms, dbo.Property.BathTotalCalc, dbo.Property.BathFull, dbo.Property.BathsParcialNbr, dbo.Property.BathFixturesNbr, 
                         dbo.Property.AirConditioningCode, dbo.Property.BasementCode, dbo.Property.BuildingClassCode, dbo.Property.BuildingConditionCode, dbo.Property.ConstructionTypeCode, dbo.Property.ElectricityCode, 
                         dbo.Property.FireplaceCode, dbo.Property.FloorTypeCode, dbo.Property.Garage, dbo.Property.HeatCode, dbo.Property.SiteInfluenceCode, dbo.Property.GarageParkingNbr, dbo.Property.DrivewayCode, 
                         dbo.Property.PatioCode, dbo.Property.PoolCode, dbo.Property.PorchCode, dbo.Property.BuildingQualityCode, dbo.Property.RoofCoverCode, dbo.Property.RoofTypeCode, dbo.Property.SewerCode, 
                         dbo.Property.StoriesNbrCode, dbo.Property.StyleCode, dbo.Property.SumResidentialUnits, dbo.Property.SumBuildingsNbr, dbo.Property.SumCommercialUnits, dbo.Property.WaterCode, dbo.Property.LotCode, 
                         dbo.Property.LotNumber, dbo.Property.LandLot, dbo.Property.Block, dbo.Property.Section, dbo.Property.District, dbo.Property.LegalUnit, dbo.Property.Municipality, dbo.Property.SubdivisionName, 
                         dbo.Property.SubdivisionPhaseNbr, dbo.Property.SubdivisionTractNbr, dbo.Property.Meridian, dbo.Property.AssessorsMapRef1, dbo.Property.LegalDescription, dbo.Property.CurrentSaleTransactionId, 
                         dbo.Property.CurrSaleInputDocNbr, dbo.Property.CurrSaleInputBook, dbo.Property.CurrSaleInputPage, dbo.Property.CurrSaleRecordingDate, dbo.Property.CurrSaleContractDate, 
                         dbo.Property.CurrSaleDocumentType, dbo.Property.CurrSalesPrice, dbo.Property.CurrSaleBuyer1FullName, dbo.Property.CurrSaleBuyer2FullName, dbo.Property.CurrSaleSeller1FullName, 
                         dbo.Property.CurrSaleSeller2FullName, dbo.Property.ConCurrMtg1InputDocNbr, dbo.Property.ConCurrMtg1InputBook, dbo.Property.ConCurrMtg1InputPage, dbo.Property.ConCurrMtg1RecordingDt, 
                         dbo.Property.ConCurrMtg1LoanAmt, dbo.Property.ConCurrMtg1Lender, dbo.Property.ConCurrMtg1PrivateLender, dbo.Property.ConCurrMtg1Term, dbo.Property.ConCurrMtg1LoanDueDt, 
                         dbo.Property.ConCurrMtg1AdjOrFix, dbo.Property.ConCurrMtg1LoanType, dbo.Property.ConCurrMtg1Typefinancing, dbo.Property.ConCurrMtg2InputDocNbr, dbo.Property.ConCurrMtg2InputBook, 
                         dbo.Property.ConCurrMtg2InputPage, dbo.Property.ConCurrMtg2RecordingDt, dbo.Property.ConCurrMtg2LoanAmt, dbo.Property.ConCurrMtg2Lender, dbo.Property.ConCurrMtg2PrivateLender, 
                         dbo.Property.ConCurrMtg2Term, dbo.Property.ConCurrMtg2LoanDueDt, dbo.Property.ConCurrMtg2AdjOrFix, dbo.Property.ConCurrMtg2LoanType, dbo.Property.ConCurrMtg2Typefinancing, 
                         dbo.Property.PrevSaleTransactionId, dbo.Property.PrevSaleInputDocNbr, dbo.Property.PrevSaleInputBook, dbo.Property.PrevSaleInputPage, dbo.Property.PrevSaleRecordingDate, 
                         dbo.Property.PrevSaleContractDate, dbo.Property.PrevSaleDocumentType, dbo.Property.PrevSalesPrice, dbo.Property.PrevSaleBuyer1FullName, dbo.Property.PrevSaleBuyer2FullName, 
                         dbo.Property.PrevSaleSeller1FullName, dbo.Property.PrevSaleSeller2FullName, dbo.Property.PrevMtg1InputDocNbr, dbo.Property.PrevMtg1InputBook, dbo.Property.PrevMtg1InputPage, 
                         dbo.Property.PrevMtg1RecordingDt, dbo.Property.PrevMtg1LoanAmt, dbo.Property.PrevMtg1Lender, dbo.Property.PrevMtg1PrivateLender, dbo.Property.PrevMtg1Term, dbo.Property.PrevMtg1LoanDueDt, 
                         dbo.Property.PrevMtg1AdjRider, dbo.Property.PrevMtg1LoanType, dbo.Property.PrevMtg1Typefinancing, dbo.Property.Bath3QTR, dbo.Property.Bath3QTR AS Expr1, dbo.Property.Bath3QTR AS Expr2, 
                         dbo.Property.Bath3QTR AS Expr3, dbo.Property.Bath3QTR AS Expr4, dbo.Property.Bath3QTR AS Expr5, dbo.Property.Bath3QTR AS Expr6, dbo.Property.Bath3QTR AS Expr7, dbo.Property.Bath3QTR AS Expr8, 
                         dbo.Property.Bath3QTR AS Expr9, dbo.Property.Bath3QTR AS Expr10, dbo.Property.Bath3QTR AS Expr11, dbo.Property.FATimestamp, dbo.Property.FAUCIDFlag, 
                         dbo.Deed.DeedUniqueID AS NominalTransactionID, dbo.Deed.DocNbrSrce AS NominalDocumentNumber, dbo.Deed.BookSrce AS NominalRecordersBook, dbo.Deed.PageSrce AS NominalRecordersPage, 
                         dbo.Deed.RecordingDt AS NominalRecordingDate, dbo.Deed.Saledate AS NominalSaleDate, dbo.Deed.DocumentTypeCode AS NominalDocumentTypeCode, dbo.Deed.SalesPrice AS NominalSalesAmount, 
                         dbo.Deed.Buyer1FullName AS NominalBuyer1FullName, dbo.Deed.Buyer2FullName AS NominalBuyer2FullName, SUBSTRING(LTRIM(RTRIM(LTRIM(RTRIM(CASE WHEN [Seller1LastNameOrCorpName] IS NULL 
                         THEN '' ELSE [Seller1LastNameOrCorpName] END)) + ' ' + LTRIM(RTRIM(CASE WHEN [Seller1FirstNameMiddlename] IS NULL THEN '' ELSE [Seller1FirstNameMiddlename] END)))), 1, 60) 
                         AS NominalSeller1FullName, SUBSTRING(LTRIM(RTRIM(LTRIM(RTRIM(CASE WHEN [Seller2LastNameOrCorpName] IS NULL THEN '' ELSE [Seller2LastNameOrCorpName] END)) 
                         + ' ' + LTRIM(RTRIM(CASE WHEN [Seller2FirstNameMiddlename] IS NULL THEN '' ELSE [Seller2FirstNameMiddlename] END)))), 1, 60) AS NominalSeller2FullName, 
                         dbo.Deed.Loan1Document AS NominalLoanDocumentNumber, dbo.Deed.Loan1Book AS NominalLoanRecordersBook, dbo.Deed.Loan1Page AS NominalLoanRecordersPage, 
                         dbo.Deed.Loan1RecordingDt AS NominalLoanRecordingDate, dbo.Deed.Loan1Amount AS NominalLoanAmount, dbo.Deed.Loan1LenderName AS NominalLoanLenderName, 
                         CASE WHEN [Loan1LenderCode] = 'P' THEN 'Y' ELSE NULL END AS NominalPrivatePartyIndicator, dbo.Deed.Loan1TermMonths AS NominalLoanTermMonths, dbo.Deed.Loan1DueDate AS NominalLoanDueDate, 
                         CASE WHEN [Loan1TypeFinance] = 'AD' THEN 'ADJ' WHEN [Loan1TypeFinance] = 'FI' THEN 'FIX' WHEN [Loan1TypeFinance] = 'MU' THEN 'MUL' WHEN [Loan1TypeFinance] = 'OT' THEN 'OTH' WHEN [Loan1TypeFinance]
                          = 'ST' THEN 'STP' WHEN [Loan1TypeFinance] = 'UN' THEN 'UNK' WHEN [Loan1TypeFinance] = 'VA' THEN 'VAR' ELSE [Loan1TypeFinance] END AS NominalAdjOrFix, 
                         dbo.Deed.Loan1TransType AS NominalLoanTransactionType
FROM            dbo.Property WITH(nolock) INNER JOIN
                         dbo.Deed WITH(NoLock) ON dbo.Property.PropertyID = dbo.Deed.FAPropertyId
WHERE        (dbo.Property.FIPS = '06037') 
						AND (dbo.Property.SitusStdZIP5 IN ('90404', '90405', '90025', '90034', '90232', '90016', '90035', '90048', '90036', '90038', '90027', '90039', '90026', '90029', '90018', '90291', 
                         '90292', '90066', '90266', '90245', '90019', '90046', '91604', '91602', '91601', '90077', '90210', '91790', '91706', '91801', '90503', '90505', '90277', '92805', '90605', '90604', '92503', '92504', '92506', '92507', 
                         '92627', '90265', '90211', '90067')) 
							AND (dbo.Deed.RecordingDt BETWEEN '20150615' AND '20150930') 
								AND (dbo.Property.StdLandUseCode IN ('1100', '1104', '1106', '1107', '1110', '1112', '2000', '2001', '2002', 
								 '2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2025', '2029', '2031', '2035', '2036', '2042', '2043', '2044', '2045', '2053', '3000', '3001', '3002', 
								'3003', '3004', '3005', '3006', '3007', '3010', '5000', '5002', '5003', '5013', '5018', '8002', '8007')) 
									AND (dbo.Deed.NonArmslength = 1) 
										AND (dbo.Property.MailingStdZIP5 IS NULL) 
						 OR
                         (dbo.Property.FIPS = '06037') 
							AND (dbo.Property.SitusStdZIP5 IN ('90404', '90405', '90025', '90034', '90232', '90016', '90035', '90048', '90036', '90038', '90027', '90039', '90026', '90029', '90018', '90291', 
							 '90292', '90066', '90266', '90245', '90019', '90046', '91604', '91602', '91601', '90077', '90210', '91790', '91706', '91801', '90503', '90505', '90277', '92805', '90605', '90604', '92503', '92504', '92506', '92507', 
							 '92627', '90265', '90211', '90067')) 
								AND (dbo.Deed.RecordingDt BETWEEN '20150615' AND '20150930') 
									AND (dbo.Property.StdLandUseCode IN ('1100', '1104', '1106', '1107', '1110', '1112', '2000', '2001', '2002', 
									'2003', '2004', '2005', '2006', '2007', '2008', '2009', '2010', '2012', '2013', '2014', '2015', '2016', '2017', '2018', '2025', '2029', '2031', '2035', '2036', '2042', '2043', '2044', '2045', '2053', '3000', '3001', '3002', 
									'3003', '3004', '3005', '3006', '3007', '3010', '5000', '5002', '5003', '5013', '5018', '8002', '8007')) 
										AND (dbo.Deed.NonArmslength = 1) 
						 ---AND (dbo.Deed.Loan1Document != '36') --- / Removed the code after discussion with Jennifer SVH 10/2/2015 
									AND (LEN(dbo.Property.MailingStdZIP5) > 4)
--ORDER BY dbo.Property.PropertyID



GRANT SELECT ON [dbo].[v_Cust_Partners_Capital] TO [CORP\cbrady] AS [dbo]
