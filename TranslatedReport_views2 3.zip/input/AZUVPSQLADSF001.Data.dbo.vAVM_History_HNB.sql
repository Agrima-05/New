SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


CREATE VIEW [Data].[dbo].[vAVM_History_HNB]
AS
SELECT P.Fips
	, P.PropertyID
	, P.FormattedAPN AS APN
	, P.SitusStdHouseNbr
	, P.SitusStdHouseNbr2
	, P.SitusStdHouseNbrSuffix
	, P.SitusStdDirectionLeft
	, P.SitusStdStreet
	, P.SitusStdMode
	, P.SitusStdDirectionRight
	, P.SitusStdUnitType
	, P.SitusStdUnitNbr
	, P.SitusStdCity
	, P.SitusStdState
	, P.SitusStdZIP5
	, P.SitusStdZIP4
	, P.SitusStdCarrierCode
	, A.Final_Value
	, A.low as Low_Value
	, A.high as High_Value
	, Null as  ConfidenceScore
	, A.[stDev] as StandardDeviation
	, A.VALUATION_DATE
FROM  Data.[dbo].[HIST_2018AVM_OUT] A With(NOLOCK) JOIN Data.dbo.Property P With(NOLOCK)
	ON a.FIPS = P.FIPS
		AND a.PropertyID = P.PropertyID



GRANT SELECT ON [dbo].[vAVM_History_HNB] TO [CORP\cbrady] AS [dbo]
