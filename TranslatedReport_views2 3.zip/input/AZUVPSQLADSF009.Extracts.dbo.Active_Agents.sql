SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON


 CREATE view [Extracts].[dbo].[Active_Agents] 
 as
SELECT distinct a.[mls_id],a.[dp_member_id] as AgentID,[dp_office_id] as OfficeID,[full_name]
,case when s.[FullStreetAddress] is null then a.[Address] Else s.[FullStreetAddress] END as [Address]
,case when s.[city] is null then a.city else s.city end [City]
,case when s.[state] is null then a.[state] else s.[State] end [State]
,case when s.[Zip] is null then a.[zip] else s.[Zip] end [Zip]
,[preferred_phone_number],[cellphone_number],[email],[license_number],[license_state],[type],c.[status] ListingStatus
from src_PlatLabs.agent.Platlabs_agents a with(NOLOCK) JOIN (
	SELECT mls_id,dp_member_id, row_number() OVER (PARTITION BY mls_id ORDER BY NewID()) as rn
	FROM src_PlatLabs.agent.Platlabs_agents with(NOLOCK)
	) b
on a.mls_id = b.mls_id
and a.dp_member_id = b.dp_member_id
JOIN src_PlatLabs.listing.ListingsRaw c with(NOLOCK)
	on a.mls_id = c.mls_id 
		and a.dp_member_id = c.listing_agent_id
LEFT OUTER JOIN ASP_Offcycle.addr.StandardizedAddress_Agent s
	on a.mls_id = s.mls_id
		and a.dp_member_id = s.dp_member_id
Where b.rn < 11
and a.license_number is not null
and a.address is not null
and preferred_phone_number is not null
and c.status in('active','pending')




