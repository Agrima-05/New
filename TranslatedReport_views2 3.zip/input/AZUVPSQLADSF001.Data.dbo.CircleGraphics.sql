SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE VIEW [Data].[dbo].[CircleGraphics]
AS
SELECT        FIPS, FAPropertyID
FROM            Jobs_Lkup.dbo.CircleGraphics

